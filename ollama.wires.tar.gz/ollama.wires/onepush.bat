@echo off
setlocal
set "ROOT=%~dp0."

"%ROOT%\bin\buttons.exe" "%ROOT%\.build\build.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ROOT%\bin\buttons.exe" "%ROOT%\.install\install.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ROOT%\bin\buttons.exe" "%ROOT%\.test\test.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ROOT%\bin\buttons.exe" "%ROOT%\.document\document.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

exit /b %ERRORLEVEL%
