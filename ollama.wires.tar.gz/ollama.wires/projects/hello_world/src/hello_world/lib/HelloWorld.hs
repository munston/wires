module HelloWorld where

message :: String
message = "hello world"

go :: IO ()
go = putStrLn message
