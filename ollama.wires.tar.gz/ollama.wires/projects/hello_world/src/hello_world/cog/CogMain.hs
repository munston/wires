module Main where

import System.Exit
import qualified HelloWorld

main :: IO ()
main =
  if HelloWorld.message == "hello world"
    then exitSuccess
    else die ("unexpected hello_world message: " ++ show HelloWorld.message)
