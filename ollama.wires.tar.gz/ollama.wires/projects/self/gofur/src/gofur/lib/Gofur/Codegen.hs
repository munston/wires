module Gofur.Codegen where

import Data.List
import Folders.Routes
import System.FilePath

renderGoMain :: String -> Bool -> String
renderGoMain goModuleName useAlive =
  let aliveImport = ["import Gofur.Alive" | useAlive]
      dispatchLine =
        if useAlive
          then "dispatch (option : args) = withAliveRuntime option (" ++ goModuleName ++ ".go option args >>= print >> return ())"
          else "dispatch (option : args) = " ++ goModuleName ++ ".go option args >>= print >> return ()"
  in
  unlines
    ( [ "-- generated-by: gofur codegen 0.1"
      , "module Main where"
      , ""
      , "import System.Environment"
      ]
    ++ aliveImport
    ++ [ "import qualified " ++ goModuleName
       , ""
       , "main :: IO ()"
       , "main = getArgs >>= dispatch . normalizeArgs"
       , ""
       , "normalizeArgs :: [String] -> [String]"
       , "normalizeArgs [single] = words single"
       , "normalizeArgs args = args"
       , ""
       , "dispatch :: [String] -> IO ()"
       , dispatchLine
       , "dispatch [] = fail \"missing gofur option\""
       ]
    )

renderCogMain :: String -> [String] -> [VerifiedRoute] -> String
renderCogMain executableName rootOptions routes =
  -- If no explicit routes were provided, emit a minimal cog main that
  -- avoids importing System.Directory/FilePath/Process. This keeps
  -- generated test-sources from forcing those build-depends when the
  -- package hasn't declared any runtime routes.
  if null routes
    then unlines
      [ "-- generated-by: gofur codegen 0.1"
      , "module Main where"
      , ""
      , "import System.Exit"
      , ""
      , "main :: IO ()"
      , "main = return ()"
      ]
    else
      let effectiveRoutes = routes
      in unlines
        ( [ "-- generated-by: gofur codegen 0.1"
          , "module Main where"
          , ""
          ]
        ++ dataListImport effectiveRoutes
        ++ [ "import System.Directory"
          , "import System.Exit"
          , "import System.FilePath"
          , "import System.Process"
          , ""
          , "main :: IO ()"
          , "main = do"
          , "  root <- findProjectRoot"
          , "  project <- getCurrentDirectory"
          ]
        ++ concatMap renderCogCase effectiveRoutes
        ++ [ "  return ()"
           , ""
           , "findProjectRoot :: IO FilePath"
           , "findProjectRoot = do"
           , "  current <- getCurrentDirectory"
           , "  return (normalise (current </> \"..\" </> \"..\" </> \"..\"))"
           , ""
           , "runCase :: FilePath -> FilePath -> String -> [String] -> (String -> Bool) -> IO ()"
           , "runCase _root project option extraArgs predicate = do"
           , "  let exe = project </> \"bin\" </> " ++ show (executableName <.> "exe")
           , "      args = option : extraArgs"
           , "  output <- readProcess exe args \"\""
           , "  let value = read output :: String"
           , "  if predicate value"
           , "    then return ()"
           , "    else do"
           , "      putStrLn (\"cog failed for \" ++ option ++ \": \" ++ value)"
           , "      exitFailure"
           , ""
           , "rootArgument :: String -> FilePath -> [String]"
           , "rootArgument option root"
           , "  | option `elem` rootOptions = [root]"
           , "  | otherwise = []"
           , ""
           , "rootOptions :: [String]"
           , "rootOptions = " ++ show rootOptions
          ] )

nullListRoute :: VerifiedRoute
nullListRoute =
  VerifiedRoute
    { routeOption = "--list"
    , routeArgs = []
    , routePrecog = "\\s -> \"--list\" `isInfixOf` s"
    }

dataListImport :: [VerifiedRoute] -> [String]
dataListImport routes =
  ["import Data.List" | any (isInfixOf "isInfixOf" . routePrecog) routes]

renderCogCase :: VerifiedRoute -> [String]
renderCogCase entry =
  [ "  runCase root project " ++ show option ++ " (" ++ show args ++ " ++ rootArgument " ++ show option ++ " root) (" ++ body ++ ")"
  ]
  where
    option = routeOption entry
    args = routeArgs entry
    body = routePrecog entry
