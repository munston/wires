{-|
Module: Wires.Cast

Description:
  The "casting" stage of the Wires toolchain. This module is
  responsible for taking the parsed project model (`WiresObject`) and
  materialising filesystem artefacts that Cabal understands: the
  top-level `cabal.project` and per-package `.cabal` files, plus the
  small generated sources used to run package entry points and the
  cog test harnesses.

Rationale and role in the UI flow:
  - The `install.bat` canonical flow calls into the wires runner, and
    `Wires.Cast` is the piece that converts the abstract project
    description into on-disk Haskell packages.  The output of this
    module is what Cabal (or the build system) consumes to produce
    binaries and run tests.
  - Functions in this module prefer idempotence: generated directories
    are reset and previously-generated `.cabal` files are removed to
    avoid stale state confusing subsequent runs.

Implementation notes:
  - The module emits both the library/executable/test-suite sections
    for each package and produces small generated `Main.hs` and
    `CogMain.hs` sources. Those generated sources wire the package
    runtime into the `go` dispatcher of each package.

  - Where reasonable, functions here return concise status strings
    consumed by the `buttons` flow so that the UI can present short
    human-readable outcomes (for example: "cast ok\npackages: 3").

Design perspective:
  Think of `Wires.Cast` as an adapter between the domain model (the
  `wire.project` specification) and the concrete Haskell packaging
  world. The comments on each function explain not just what the
  function does, but how it fits into that adapter role.
 -}
module Wires.Cast where

import Data.List
import Control.Monad
import Control.Exception
import qualified Gofur.Codegen as Gofur
import System.Directory
import System.FilePath
import Wires.Object

-- | Compile stage for the whole wires root.
--
-- Reads the parsed `WiresObject` from disk and writes the generated
-- source files for every package. This is used by the buttons flow as
-- a fast verification/compile step that produces the generated source
-- tree (but does not emit Cabal manifests). Returns a short human
-- readable status string suitable for logging in the installer UI.
compileWiresRoot :: FilePath -> IO String
compileWiresRoot root = do
  objectResult <- readWiresObject root
  case objectResult of
    Left errors -> error (unlines ("compile failed while reading Wires object:" : errors))
    Right object -> do
      mapM_ (writeGeneratedPackageSources object) (wiresPackages object)
      return ("wires compile ok\npackages: " ++ show (length (wiresPackages object)))

-- | Compile stage for a single package.
--
-- Similar to `compileWiresRoot` but targets a single package path
-- (relative to the wires root). Useful when the buttons flow only
-- needs to re-generate sources for one package instead of the whole
-- tree.
compileWiresProject :: FilePath -> FilePath -> IO String
compileWiresProject root packageRelative = do
  object <- readWiresObjectOrFail "compile" root
  package <- findWiresPackageOrFail object packageRelative
  writeGeneratedPackageSources object package
  return ("wires compile ok\npackage: " ++ wiresPackagePath package)

-- | The "cast" stage for the entire wires root.
--
-- This emits a top-level `cabal.project` and a `.cabal` file for every
-- package. After `cast` completes, the repository is ready for the
-- package manager (Cabal) to consume and build the packages.
castWiresRoot :: FilePath -> IO String
castWiresRoot root = do
  objectResult <- readWiresObject root
  case objectResult of
    Left errors -> error (unlines ("cast failed while reading Wires object:" : errors))
    Right object -> do
      writeCabalProject object
      mapM_ (writeCabalPackage object) (wiresPackages object)
      return ("cast ok\npackages: " ++ show (length (wiresPackages object)))

-- | Cast stage for a single package. Writes the top-level `cabal.project`
-- (to keep Cabal aware of all packages) and then writes the single
-- package `.cabal` file. Useful for focused casts during development.
castWiresProject :: FilePath -> FilePath -> IO String
castWiresProject root packageRelative = do
  object <- readWiresObjectOrFail "cast" root
  package <- findWiresPackageOrFail object packageRelative
  writeCabalProject object
  writeCabalPackage object package
  return ("cast ok\npackage: " ++ wiresPackagePath package)

-- | Helper: read the `WiresObject` or fail with an action-specific
-- message. Many top-level operations call this to provide a clear
-- failure cause early in the buttons flow.
readWiresObjectOrFail :: String -> FilePath -> IO WiresObject
readWiresObjectOrFail action root = do
  objectResult <- readWiresObject root
  case objectResult of
    Left errors -> error (unlines ((action ++ " failed while reading Wires object:") : errors))
    Right object -> return object

-- | Lookup a package by its relative path recorded in `wire.project`.
-- Fails with a clear error message if not found. The package path is
-- normalised to make the lookup resilient to trivial path differences.
findWiresPackageOrFail :: WiresObject -> FilePath -> IO WiresPackage
findWiresPackageOrFail object packageRelative =
  case filter ((== normalise packageRelative) . normalise . wiresPackagePath) (wiresPackages object) of
    package:_ -> return package
    [] -> error ("package not found in wire.project: " ++ packageRelative)

-- | Emit the top-level `cabal.project` file which lists packages to be
-- built by Cabal. This file is regenerated each cast to keep the
-- package list in sync with the `wire.project` model. The function
-- intentionally overwrites any previous file.
writeCabalProject :: WiresObject -> IO ()
writeCabalProject object = do
  let path = wiresRoot object </> "projects" </> "cabal.project"
      packagePaths = wireProjectPackages (wiresProject object) ++ wireProjectBootstrapPackages (wiresProject object)
      body =
        unlines
          ( [ "-- generated-by: wires cast 0.1"
            , "packages:"
            ]
          ++ map ("  " ++) packagePaths
          )
  -- Always overwrite the authoritative `projects/cabal.project` to keep
  -- the cast operation bijective with the wire.project canonicalisation
  -- behaviour. Caller should ensure backups if needed.
  createDirectoryIfMissing True (takeDirectory path)
  writeFile path body

-- | Write the `.cabal` file for a single package. Before writing the
-- manifest we remove previously-generated `.cabal` files so that the
-- emitted file represents the current state of the `WiresPackage`.
writeCabalPackage :: WiresObject -> WiresPackage -> IO ()
writeCabalPackage object package = do
  let dir = packageDirectory object package
      name = wiresPackageName package
  -- If the package directory already contains a non-generated .cabal,
  -- avoid overwriting it. We only overwrite when no .cabal exists or
  -- when existing .cabal files are generator-produced (contain marker).
  entries <- listDirectory dir
  let cabalCandidates = filter ((== ".cabal") . takeExtension) entries
  if null cabalCandidates
    then do
      writeFile (dir </> cabalPackageName name <.> "cabal") (renderCabalPackage package [] [])
    else do
      eres <- mapM (\c -> try (readFileStrict (dir </> c)) :: IO (Either SomeException String)) cabalCandidates
      let paired = zip cabalCandidates eres
          nonGenerated = [c | (c, Right contents) <- paired, not ("generated-by: wires cast" `isInfixOf` contents)]
          unreadable = [c | (c, Left _) <- paired]
      if not (null nonGenerated) || not (null unreadable)
        then return () -- leave manual or unreadable .cabal files intact
        else do
          -- safe to overwrite generated cabal files; but first merge any existing
          -- executable / test-suite build-depends so manual edits are not lost.
          let existingContents = [contents | (_, Right contents) <- paired]
              extraExeDeps = concatMap (extractSectionBuildDepends ("executable " ++ name)) existingContents
              extraCogDeps = concatMap (extractSectionBuildDepends ("test-suite " ++ cogSuite package)) existingContents
              finalExeDeps = nub (executableDepends package ++ extraExeDeps)
              finalCogDeps = nub (cogSuiteDepends package ++ extraCogDeps)
          removeGeneratedCabalFiles dir
          writeFile (dir </> cabalPackageName name <.> "cabal") (renderCabalPackage package finalExeDeps finalCogDeps)

-- | Generate the small runtime sources for a package: the executable
-- `Main.hs` (which dispatches into the package `go` module) and the
-- `CogMain.hs` test harness used by cog tests. These files are
-- deterministic and safe to regenerate on each run.
writeGeneratedPackageSources :: WiresObject -> WiresPackage -> IO ()
writeGeneratedPackageSources object package = do
  let dir = packageDirectory object package
  prepareGeneratedSourceDirs package dir
  writeFile (dir </> "exe" </> "Main.hs") (renderMainModule package)
  writeFile (dir </> cogMainPath package) (renderCogMain object package)

-- | Ensure generated source directories are clean and present. The
-- function removes stale generated directories and recreates the
-- expected layout for `exe` and `cog` sources.
prepareGeneratedSourceDirs :: WiresPackage -> FilePath -> IO ()
prepareGeneratedSourceDirs package dir = do
  resetGeneratedDir (dir </> "exe")
  mapM_ (resetGeneratedDir . (dir </>)) (cogSourceDirsValue package)
  createDirectoryIfMissing True (dir </> "exe")
  createDirectoryIfMissing True (takeDirectory (dir </> cogMainPath package))

-- | Remove a directory recursively if it exists. This is used to
-- clear previously-generated source trees before regenerating them.
resetGeneratedDir :: FilePath -> IO ()
resetGeneratedDir dir = do
  exists <- doesDirectoryExist dir
  if exists
    then removeDirectoryRecursive dir
    else return ()

-- | Remove any `.cabal` files found directly in `dir`. This avoids
-- leaving stale manifests around when the package name changes or the
-- generator's output evolves.
removeGeneratedCabalFiles :: FilePath -> IO ()
removeGeneratedCabalFiles dir = do
  entries <- listDirectory dir
  let cabals = filter ((== ".cabal") . takeExtension) entries
  forM_ cabals $ \entry -> do
    let path = dir </> entry
    eres <- try (readFileStrict path) :: IO (Either SomeException String)
    case eres of
      Left _ -> return () -- if we can't read it, be conservative and do not remove
      Right contents ->
        when ("generated-by: wires cast" `isInfixOf` contents) (removeFile path)

readFileStrict :: FilePath -> IO String
readFileStrict path = do
  contents <- readFile path
  length contents `seq` return contents

-- | Render a complete Cabal package manifest for `WiresPackage`.
--
-- The function computes the list of `exposed-modules` from the
-- `nut` metadata and places any remaining modules in `other-modules`.
-- This is important so that helper modules generated into `lib/` are
-- included when the package is built (see the Robocop issue where a
-- helper module was missing from `.cabal`). The output is the raw
-- `.cabal` file text to be written to disk.
renderCabalPackage :: WiresPackage -> [String] -> [String] -> String
renderCabalPackage package extraExeDeps extraCogDeps =
  let packageName' = wiresPackageName package
      allModules = map hsModuleName (wiresPackageModules package)
      exposed = nub (nutExposes (wiresPackageNut package))
      otherModules = filter (`notElem` exposed) allModules
      exeDeps = nub (executableDepends package ++ extraExeDeps)
      -- If the package's cog stanza didn't declare explicit depends,
      -- fall back to the package's `nut` depends so generated cogs
      -- inherit the library-level dependencies by default.
      cogDeclared = case cogDepends (wiresPackageCog package) of
        [] -> map cabalPackageName (nutDepends (wiresPackageNut package))
        cds -> map cabalPackageName cds
      cogDeps = nub (libraryDepends package ++ ["process >=1.6"] ++ cogDeclared ++ extraCogDeps)
  in unlines
    ( [ "cabal-version: 3.0"
    , "-- generated-by: wires cast 0.1"
    , "name: " ++ cabalPackageName packageName'
    , "version: 0.1.0.0"
    , "build-type: Simple"
    , ""
    , "library"
    , renderFieldBlock "exposed-modules" exposed
    ]
    ++ (if null otherModules then [] else [renderFieldBlock "other-modules" otherModules])
    ++ [ "  hs-source-dirs:"
    , "      lib"
    , renderBuildDepends (libraryDepends package)
    , ""
    , "  default-language:"
    , "      Haskell2010"
    , "  ghc-options: -Wall"
    , ""
    , "executable " ++ packageName'
    , "  main-is:"
    , "      Main.hs"
    , "  hs-source-dirs:"
    , "      exe"
    , renderBuildDepends exeDeps
    , ""
    , "  default-language:"
    , "      Haskell2010"
    , "  ghc-options: -Wall"
    , ""
    , "test-suite " ++ cogSuite package
    , "  type:"
    , "      " ++ cogSuiteTypeValue package
    , "  main-is:"
    , "      " ++ cogMain package
    , "  hs-source-dirs:"
    , renderFieldValues (cogSourceDirsValue package)
    , renderBuildDepends cogDeps
    , ""
    , "  default-language:"
    , "      Haskell2010"
    , "  ghc-options: -Wall"
    ])

-- | Extract build-depends values from a specific stanza in an existing
-- .cabal file. We look for the stanza header (like "executable foo") and
-- collect any `build-depends:` lines and their continuation lines until the
-- stanza ends. This is intentionally forgiving to allow simple merges of
-- manual edits without implementing a full Cabal parser.
extractSectionBuildDepends :: String -> String -> [String]
extractSectionBuildDepends header contents =
  let ls = lines contents
      mIndex = findHeaderIndex header ls 0
  in case mIndex of
       Nothing -> []
       Just i ->
         let rest = drop (i+1) ls -- examine lines after the header
             depsLines = takeWhile (not . null) rest
         in concatMap parseBuildDependsBlock (sectionsContainingBuildDepends depsLines)

-- Find the first line index that contains the header prefix
findHeaderIndex :: String -> [String] -> Int -> Maybe Int
findHeaderIndex _ [] _ = Nothing
findHeaderIndex pref (x:xs) n
  | pref `isInfixOf` x = Just n
  | otherwise = findHeaderIndex pref xs (n+1)

-- Identify contiguous blocks that contain a `build-depends:` line within
-- the given stanza lines. Return each block as a list of lines.
sectionsContainingBuildDepends :: [String] -> [[String]]
sectionsContainingBuildDepends ls =
  case dropWhile (not . ("build-depends:" `isInfixOf`)) ls of
    [] -> []
    (x:xs) -> let block = x : takeWhile isContinuation xs
              in block : sectionsContainingBuildDepends (dropWhile isContinuation xs)

-- A line is considered a continuation of build-depends if it is indented
-- (starts with spaces) and may begin with a comma.
isContinuation :: String -> Bool
isContinuation s = not (null s) && (head s == ' ' || head s == '\t')

-- Parse a block of lines containing `build-depends:` into individual
-- dependency strings.
parseBuildDependsBlock :: [String] -> [String]
parseBuildDependsBlock [] = []
parseBuildDependsBlock (first:rest) =
  let afterColon = case dropWhile (/= ':') first of
                     (':':xs) -> xs
                     _ -> ""
      combined = unwords (afterColon : rest)
      items = splitOnComma combined
  in map trimString items

-- Split a comma-separated string into parts.
splitOnComma :: String -> [String]
splitOnComma s = case break (== ',') s of
  (a, ',' : b) -> a : splitOnComma b
  (a, _) -> [a]

trimString :: String -> String
trimString = f . f
  where f = reverse . dropWhile (== ' ') . dropWhile (== '\t') . dropWhile (== '\n')

-- | Generate the `Main.hs` for a package executable. The generated
-- main normalises the incoming command-line arguments and delegates
-- to the package `go` dispatcher inside the package's `go` module.
-- The call is wrapped with `withAliveRuntime` to ensure the runtime
-- lifecycle hooks are handled consistently across packages.
renderMainModule :: WiresPackage -> String
renderMainModule package =
  let needsAlive = "wires" `elem` map cabalPackageName (boltDepends (wiresPackageBolt package))
  in Gofur.renderGoMain (goModuleName package) needsAlive

-- | Generate the `CogMain.hs` test harness used to run package-level
-- cog tests. The harness enumerates the package's `VerifiedRoute`s and
-- produces `runCase` invocations that call the built executable and
-- assert the textual `precog` predicate. The generated test verifies
-- the runtime behaviour from the outside (via the produced binaries),
-- which matches the philosophy of treating packages as black-boxes in
-- the verification pipeline.
renderCogMain :: WiresObject -> WiresPackage -> String
renderCogMain _object package =
  Gofur.renderCogMain
    (wiresPackageName package)
    -- No root/wires-lifecycle options are injected. A package cog tests only
    -- the package's own go routes (their string outputs); it must never test
    -- wires operations such as --cast.
    []
    (wiresPackageRoutes package)

renderFieldBlock :: String -> [String] -> String
renderFieldBlock field values =
  unlines
    ( ("  " ++ field ++ ":")
    : case values of
      [] -> []
      (v:vs) -> ("      " ++ v) : map ("      , " ++) vs
    )

renderFieldValues :: [String] -> String
renderFieldValues values =
  unlines (map ("      " ++) values)

renderBuildDepends :: [String] -> String
renderBuildDepends depends =
  case uniqueDepends of
    [] -> ""
    (first:rest) ->
      unlines
        ( [ "  build-depends:"
              , "      " ++ first
              ]
            ++ map ("      , " ++) rest
            ) ++ "\n"
  where
    uniqueDepends = nub depends
    -- Ensure the returned block ends with an extra newline to separate
    -- subsequent fields in the generated .cabal and avoid accidental
    -- inline concatenation on some platforms.

executableDepends :: WiresPackage -> [String]
executableDepends package =
  let declared = map cabalPackageName (boltDepends (wiresPackageBolt package))
      aliveDepends = ["gofur" | "wires" `elem` declared || "gofur" `elem` declared]
      libDeps = libraryDepends package
  in nub (libDeps ++ aliveDepends ++ declared)

libraryDepends :: WiresPackage -> [String]
libraryDepends package =
  nub ("base >=4.14 && <5" : "directory" : "filepath" : map cabalPackageName (nutDepends (wiresPackageNut package)))

cogSuiteDepends :: WiresPackage -> [String]
cogSuiteDepends package =
  let libDeps = libraryDepends package
      cogDeclared = case cogDepends (wiresPackageCog package) of
        [] -> map cabalPackageName (nutDepends (wiresPackageNut package))
        cds -> map cabalPackageName cds
  in nub (libDeps ++ ["process >=1.6"] ++ cogDeclared)

cogSuite :: WiresPackage -> String
cogSuite package =
  case cogSuiteName (wiresPackageCog package) of
    Just name -> name
    Nothing -> cabalPackageName (wiresPackageName package) ++ "-cog"

cogSuiteTypeValue :: WiresPackage -> String
cogSuiteTypeValue package =
  case cogSuiteType (wiresPackageCog package) of
    Just value -> value
    Nothing -> "exitcode-stdio-1.0"

cogMain :: WiresPackage -> FilePath
cogMain package =
  case cogMainIs (wiresPackageCog package) of
    Just value -> value
    Nothing -> "CogMain.hs"

cogMainPath :: WiresPackage -> FilePath
cogMainPath package =
  case cogSourceDirsValue package of
    dir:_ -> dir </> cogMain package
    [] -> "cog" </> cogMain package

cogSourceDirsValue :: WiresPackage -> [FilePath]
cogSourceDirsValue package =
  case cogSourceDirs (wiresPackageCog package) of
    [] -> ["cog"]
    values -> values

cabalPackageName :: String -> String
cabalPackageName =
  map replaceUnderscore

replaceUnderscore :: Char -> Char
replaceUnderscore char
  | char == '_' = '-'
  | otherwise = char

goModuleName :: WiresPackage -> String
goModuleName package =
  case nutGoIs (wiresPackageNut package) of
    Just target ->
      case splitGoTarget target of
        (moduleName, _) -> moduleName
    Nothing -> error ("missing go-is for " ++ wiresPackageName package)

packageDirectory :: WiresObject -> WiresPackage -> FilePath
packageDirectory object package =
  wiresRoot object </> "projects" </> wiresPackagePath package
