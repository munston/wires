# Purge Cloudflare cache for web-chat image
$tokenPath = Join-Path (Resolve-Path .).Path 'projects\cloudflare\API_key.txt'
if (-not (Test-Path $tokenPath)) { Write-Error "Cloudflare token file not found: $tokenPath"; exit 2 }
$token = (Get-Content $tokenPath -Raw).Trim()
$zone = 'd8e5a56a8fd0311f35a34ff03c34e9ee'  # llambda.net zone id from repo
$files = @(
  'https://llambda.net/static/images/web-chat.png'
)
$body = @{ files = $files } | ConvertTo-Json -Depth 4
Write-Output "Purging Cloudflare cache for: $($files -join ', ')"
try {
  $r = Invoke-RestMethod -Method Post -Uri "https://api.cloudflare.com/client/v4/zones/$zone/purge_cache" -Headers @{ Authorization = "Bearer $token"; 'Content-Type' = 'application/json' } -Body $body -TimeoutSec 30
  Write-Output ("Success: " + ($r.success -as [string]))
  if ($r.errors -and $r.errors.Count -gt 0) { Write-Output "Errors:"; $r.errors | ForEach-Object { Write-Output $_ } }
  if ($r.messages -and $r.messages.Count -gt 0) { Write-Output "Messages:"; $r.messages | ForEach-Object { Write-Output $_ } }
} catch {
  Write-Output ("Purge API error: " + $_.Exception.Message)
  exit 1
}

# Verify by fetching the images with no-cache header
$urls = @('https://llambda.net/static/images/web-chat.png','https://ccc672e1.llambda.pages.dev/static/images/web-chat.png')
foreach ($u in $urls) {
  Write-Output "\nFetching $u"
  try {
    $res = Invoke-WebRequest -Uri $u -Headers @{ 'Cache-Control' = 'no-cache' } -UseBasicParsing -TimeoutSec 30
    Write-Output ("Status: $($res.StatusCode) Length: $($res.RawContentLength)")
  } catch {
    Write-Output ('ERROR fetching ' + $u + ': ' + $_.Exception.Message)
  }
}
