$src = "assets\site-images\llambda\a_high_detail_stylized_computer_ui_game_splash_sc.png"
$dst = "projects\cloudflare\src\cloudflare\public\static\images\web-chat.png"
$dir = Split-Path $dst
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
Copy-Item -Path $src -Destination $dst -Force
Write-Output "Copied to $dst"
& "$PSScriptRoot\..\notes\llambda-recovery\llambda.ps1" site-deploy
Get-Item $dst | Select-Object FullName,Length
