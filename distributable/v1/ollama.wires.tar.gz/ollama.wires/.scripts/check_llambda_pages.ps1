$urls = @(
  'https://llambda.net/downloads.html',
  'https://ccc672e1.llambda.pages.dev/downloads.html'
)
foreach ($u in $urls) {
  Write-Output "\n== $u =="
  try {
    $c = (Invoke-WebRequest -Uri $u -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 30).Content
    $m = Select-String -InputObject $c -Pattern 'web-chat.png' -AllMatches
    if ($m) {
      Write-Output "Found occurrences: $($m.Count)"
      foreach ($mm in $m.Matches) { Write-Output $mm.Value }
    } else {
      Write-Output 'No occurrences of web-chat.png found in HTML'
    }
  } catch {
    Write-Output ('ERROR fetching ' + $u + ': ' + $_.Exception.Message)
  }
}

$imgs = @(
  'https://llambda.net/static/images/web-chat.png',
  'https://ccc672e1.llambda.pages.dev/static/images/web-chat.png'
)
foreach ($i in $imgs) {
  Write-Output "\n-- Fetching $i --"
  try {
    $r = Invoke-WebRequest -Uri $i -UseBasicParsing -Headers @{ 'Cache-Control' = 'no-cache' } -TimeoutSec 30
    Write-Output ("Status: $($r.StatusCode) Length: $($r.RawContentLength)")
  } catch {
    Write-Output ('ERROR fetching ' + $i + ': ' + $_.Exception.Message)
  }
}
