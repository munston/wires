@echo off
setlocal
set "ROOT=%~dp0."

pushd "%ROOT%\projects\self\codfish"
cabal build all:exes --project-file=cabal.project
if errorlevel 1 exit /b %ERRORLEVEL%
popd

if not exist "%ROOT%\bin" mkdir "%ROOT%\bin"
if not exist "%ROOT%\projects\bin" mkdir "%ROOT%\projects\bin"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$root = (Resolve-Path $env:ROOT).Path; " ^
  "$dist = Join-Path $root 'projects\self\codfish\dist-newstyle'; " ^
  "$tools = 'buttons','garrage','gofur','wires','codfish'; " ^
  "foreach ($tool in $tools) { " ^
  "  $name = $tool + '.exe'; " ^
  "  $source = Get-ChildItem -LiteralPath $dist -Recurse -File -Filter $name | Where-Object { $_.FullName -like ('*\x\' + $tool + '\build\' + $tool + '\' + $name) } | Select-Object -First 1; " ^
  "  if (-not $source) { Write-Error ('built executable not found: ' + $name); exit 1 }; " ^
  "  Copy-Item -LiteralPath $source.FullName -Destination (Join-Path $root ('bin\' + $name)) -Force; " ^
  "  Copy-Item -LiteralPath $source.FullName -Destination (Join-Path $root ('projects\bin\' + $name)) -Force; " ^
  "  Write-Output ('installed tool: ' + $name) " ^
  "}"
if errorlevel 1 exit /b %ERRORLEVEL%

if not exist "%ROOT%\.build" mkdir "%ROOT%\.build"
if not exist "%ROOT%\.install" mkdir "%ROOT%\.install"
if not exist "%ROOT%\.test" mkdir "%ROOT%\.test"
if not exist "%ROOT%\.document" mkdir "%ROOT%\.document"
type nul > "%ROOT%\.build\build.buttons"
type nul > "%ROOT%\.install\install.buttons"
type nul > "%ROOT%\.test\test.buttons"
type nul > "%ROOT%\.document\document.buttons"

echo installed self tools into bin and projects/bin
exit /b 0
