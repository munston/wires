@echo off
setlocal
set "ROOT=%~dp0."

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$root = (Resolve-Path $env:ROOT).Path; " ^
  "$fixed = '.build','.install','.test','.document','.create','.onepush','.onepush-bootstrap','.wires-verification','bin','projects\bin'; " ^
  "foreach ($name in $fixed) { $path = Join-Path $root $name; if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force; Write-Output ('removed: ' + $name) } }; " ^
  "$targets = Get-ChildItem -LiteralPath $root -Directory -Recurse -Force | Where-Object { $_.FullName -notlike (Join-Path $root 'inactive*') -and ($_.Name -in '.buttons','bin','dist-newstyle') } | Sort-Object { $_.FullName.Length } -Descending; " ^
  "foreach ($target in $targets) { if (Test-Path -LiteralPath $target.FullName) { Remove-Item -LiteralPath $target.FullName -Recurse -Force; Write-Output ('removed: ' + $target.FullName.Substring($root.Length + 1)) } }; " ^
  "Write-Output 'uninstalled generated buttons, executables, stamps, and dist-newstyle for windows'"

if errorlevel 1 exit /b %ERRORLEVEL%

call "%ROOT%\ship\package.bat"
exit /b %ERRORLEVEL%
