#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

"$ROOT/bin/buttons" "$ROOT/.build/build.buttons"
"$ROOT/bin/buttons" "$ROOT/.install/install.buttons"
"$ROOT/bin/buttons" "$ROOT/.test/test.buttons"
"$ROOT/bin/buttons" "$ROOT/.document/document.buttons"
