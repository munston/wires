#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SELF_BUILD="$ROOT/projects/self/codfish"

case "$(uname -s 2>/dev/null || echo unknown)" in
  MINGW*|MSYS*|CYGWIN*) EXE_SUFFIX=".exe" ;;
  *) EXE_SUFFIX="" ;;
esac

copy_tool() {
  name="$1"
  exe="$name$EXE_SUFFIX"
  source=$(find "$SELF_BUILD/dist-newstyle" -type f -path "*/x/$name/build/$name/$exe" | head -n 1)
  if [ -z "$source" ]; then
    echo "built executable not found: $exe" >&2
    exit 1
  fi
  cp -f "$source" "$ROOT/bin/$exe"
  cp -f "$source" "$ROOT/projects/bin/$exe"
  chmod +x "$ROOT/bin/$exe" "$ROOT/projects/bin/$exe"
  echo "installed tool: $exe"
}

(cd "$SELF_BUILD" && cabal build all:exes --project-file=cabal.project)

mkdir -p "$ROOT/bin" "$ROOT/projects/bin"
for tool in buttons garrage gofur wires codfish; do
  copy_tool "$tool"
done

mkdir -p "$ROOT/.build" "$ROOT/.install" "$ROOT/.test" "$ROOT/.document"
: > "$ROOT/.build/build.buttons"
: > "$ROOT/.install/install.buttons"
: > "$ROOT/.test/test.buttons"
: > "$ROOT/.document/document.buttons"

echo "installed self tools into bin and projects/bin"
