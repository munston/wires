#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

cd "$ROOT"

remove_dir() {
  if [ -d "$1" ]; then
    rm -rf "$1"
    echo "removed: $1"
  fi
}

for dir in .build .install .test .document .create .onepush .onepush-bootstrap .wires-verification bin projects/bin; do
  remove_dir "$dir"
done

find . \
  \( -path './inactive' -o -path './inactive/*' \) -prune -o \
  \( -type d \( -name '.buttons' -o -name 'bin' -o -name 'dist-newstyle' \) -print \) |
while IFS= read -r dir; do
  remove_dir "$dir"
done

echo "uninstalled generated buttons, executables, stamps, and dist-newstyle"

sh "$ROOT/ship/package.sh"
