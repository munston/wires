@echo off
setlocal
set "ROOT=%~dp0."

rem The only allowed option is --install-only.
set "INSTALL_ONLY=0"
if not "%~1"=="" (
  if "%~1"=="--install-only" (
    set "INSTALL_ONLY=1"
  ) else (
    echo unsupported option: %~1
    echo the only allowed option is --install-only
    exit /b 1
  )
)
if not "%~2"=="" (
  echo unsupported extra option: %~2
  echo the only allowed option is --install-only
  exit /b 1
)

"%ROOT%\bin\buttons.exe" "%ROOT%\.build\build.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ROOT%\bin\buttons.exe" "%ROOT%\.install\install.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

if "%INSTALL_ONLY%"=="1" exit /b 0

"%ROOT%\bin\buttons.exe" "%ROOT%\.test\test.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

"%ROOT%\bin\buttons.exe" "%ROOT%\.document\document.buttons"
if errorlevel 1 exit /b %ERRORLEVEL%

exit /b %ERRORLEVEL%
