#!/usr/bin/env sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

(cd "$DIR/buttons" && sh ./deploy-to-top.sh)
sh "$DIR/deploy-to-top.sh"
