@echo off
setlocal

pushd "%~dp0buttons"
call deploy-to-projects.bat
if errorlevel 1 exit /b %ERRORLEVEL%
popd

call "%~dp0deploy-to-projects.bat"
exit /b %ERRORLEVEL%
