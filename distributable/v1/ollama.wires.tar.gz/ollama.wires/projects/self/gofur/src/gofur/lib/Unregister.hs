module Gofur.Unregister where

import System.FilePath
import qualified Folders.Project as FP

-- | Gofur-level unregister wrapper. Gofur defers semantic decision to
-- Garrage; here we perform the filesystem removal using `Folders`.
unregisterProject :: FilePath -> String -> IO String
unregisterProject root projectName = FP.removeProject root projectName

-- | Exact-path version (delegates to Folders).
unregisterPackage :: FilePath -> FilePath -> IO String
unregisterPackage root packageRelative = FP.unregisterPackage root packageRelative
