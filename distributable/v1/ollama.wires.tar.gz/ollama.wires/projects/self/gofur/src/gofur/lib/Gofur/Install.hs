module Gofur.Install where

import Control.Monad
import qualified Data.List as List
import Data.Char (isSpace)
import System.Directory
import System.Exit
import System.FilePath
import System.IO
import System.Info (os)
import System.Process
import qualified Garrage
import qualified Garrage.Buttons as Buttons
import qualified Garrage.Descriptor as Descriptor
import qualified Gofur.Codegen as Codegen
import qualified Gofur.Verification as Verification

garrageToNutFile :: FilePath -> FilePath -> IO String
garrageToNutFile root packageRelative = do
  let packageDir = root </> "projects" </> packageRelative
      garragePath = packageDir </> "package.garrage"
      nutPath = packageDir </> "package.nut"
  garrageExists <- doesFileExist garragePath
  if not garrageExists
    then return ("gofur skipped " ++ packageRelative ++ ": no package.garrage")
    else do
      garrageText <- readFileStrict garragePath
      writeFile nutPath (Garrage.garrageToNut garrageText)
      return ("gofur wrote package.nut for " ++ packageRelative)

genExe :: FilePath -> FilePath -> FilePath -> IO String
genExe root packageRelative outSubdir = do
  let packageDir = root </> "projects" </> packageRelative
      packageName = takeFileName packageRelative
      outDir = packageDir </> outSubdir
      exeDir = outDir </> "exe"
      cabalName = Descriptor.cabalPackageName packageName
  upToDate <- Verification.isWiresInstallCurrent root packageRelative
  if upToDate
    then return ("gofur skipped " ++ packageRelative ++ ": install stamp current")
    else do
      createDirectoryIfMissing True exeDir
      nutText <- readOrCreateNut root packageRelative
      case Descriptor.parseField "go-is:" nutText of
        Nothing -> return ("gofur skipped " ++ packageRelative ++ ": no go-is")
        Just goTarget -> do
          let target = Descriptor.splitGoTarget goTarget
              moduleName = Descriptor.goTargetModule target
              fn = Descriptor.goTargetFunction target
              expectedModulePath = Descriptor.moduleFilePath moduleName
              moduleFileCandidate = packageDir </> "lib" </> expectedModulePath

          -- if the module isn't at the classic package root/lib path, search
          -- recursively under the package directory (covers garrage src/<pkg>/lib layout)
          moduleFile <- do
            existsAtCandidate <- doesFileExist moduleFileCandidate
            if existsAtCandidate
              then return moduleFileCandidate
              else do
                found <- findFileRecursive packageDir (takeFileName expectedModulePath)
                case found of
                  Just p -> return p
                  Nothing -> return ""

          if null moduleFile
            then return ("gofur failed: missing module " ++ moduleName)
            else do
              srcText <- readFileStrict moduleFile
              if not (Descriptor.checkFunctionExists srcText fn)
                then return ("gofur failed: go function missing: " ++ fn)
                else do
                  let depends = Descriptor.parseIndentedList "depends:" nutText
                      boltPath = packageDir </> "package.bolt"
                  boltExists <- doesFileExist boltPath
                  boltDepends <- if boltExists
                    then fmap (Descriptor.parseIndentedList "depends:") (readFileStrict boltPath)
                    else return []
                  let mergedDepends = List.nub (depends ++ boltDepends)
                      exposes = case Descriptor.parseIndentedList "exposes:" nutText of
                        [] -> [moduleName]
                        values -> values
                  writeFile (exeDir </> "Main.hs") (Codegen.renderGoMain moduleName False)
                  -- Safety guard: do not write a .cabal into a package root that already
                  -- contains any .cabal file, or when outSubdir indicates the package root (".").
                  let packageRoot = packageDir
                  cabalFilesRoot <- listDirectory packageRoot
                  let cabalCandidatesRoot = filter (".cabal" `List.isSuffixOf`) cabalFilesRoot
                  if outSubdir == "." && not (null cabalCandidatesRoot)
                    then return ("gofur skipped cabal write for " ++ packageRelative ++ ": existing .cabal present")
                    else do
                      writeFile (outDir </> cabalName <.> "cabal") (renderTwoStanzaCabal packageName exposes mergedDepends)
                      return ("gofur generated exe and cabal for " ++ packageRelative ++ " -> " ++ outDir)

-- Recursively search for a file with the given name under base directory.
findFileRecursive :: FilePath -> FilePath -> IO (Maybe FilePath)
findFileRecursive base name = do
  entries <- listDirectory base
  let loop [] = return Nothing
      loop (e:es) = do
        let p = base </> e
        isDir <- doesDirectoryExist p
        isFile <- doesFileExist p
        if isFile && takeFileName p == name
          then return (Just p)
          else if isDir
            then do
              r <- findFileRecursive p name
              case r of
                Just _ -> return r
                Nothing -> loop es
            else loop es
  loop entries

installRoot :: FilePath -> IO String
installRoot root = do
  packagePaths <- readProjectPackages root
  results <- forM packagePaths $ \packageRelative -> do
    -- Do NOT auto-generate an exe/cabal during normal install runs.
    -- `genExe` is available as an explicit command only, to avoid creating
    -- or overwriting package .cabal files in the package root.
    installPackage root packageRelative
  return (unlines ("gofur install ok" : results))

installPackage :: FilePath -> FilePath -> IO String
installPackage root packageRelative = do
  let packageDir = root </> "projects" </> packageRelative
      packageName = takeFileName packageRelative
      installDir = packageRelative </> "bin"
  upToDate <- Verification.isWiresInstallCurrent root packageRelative
  if upToDate
    then return ("gofur skipped install for " ++ packageRelative ++ ": install stamp current")
    else do
      createDirectoryIfMissing True (packageDir </> "bin")
      let args =
            [ "v2-install"
            , "exe:" ++ packageName
            , "--install-method=copy"
            , "--installdir=" ++ installDir
            , "--overwrite-policy=always"
            ]
      code <- withCreateProcess (proc "cabal" args) { cwd = Just (root </> "projects") } waitForCreatedProcess
      case code of
        ExitSuccess -> do
          stampMsg <- Verification.recordWiresInstallStamp root packageRelative
          return ("installed: " ++ packageRelative ++ "\n" ++ stampMsg)
        _ -> fail ("gofur cabal install failed for: " ++ packageRelative)

generateGofurButtons :: FilePath -> IO String
generateGofurButtons root =
  generateGofurButtonsFor regularOnly root

generateGofurButtonsWithMode :: FilePath -> String -> IO String
generateGofurButtonsWithMode root mode =
  case parsePackageSelection mode of
    Just selection -> generateGofurButtonsFor selection root
    Nothing -> return ("unknown package selection: " ++ mode)

generateGofurButtonsFor :: PackageSelection -> FilePath -> IO String
generateGofurButtonsFor selection root = do
  absoluteRoot <- makeAbsolute root
  packagePaths <- readProjectPackagesWithSelection selection absoluteRoot
  let installDir = absoluteRoot </> ".install"
  cleanupInactivePhaseButtons absoluteRoot packagePaths "install"
  -- Remove any lingering generate-exe buttons left from previous runs
  forM_ packagePaths $ \packageRelative -> do
    let packageDir = absoluteRoot </> "projects" </> packageRelative
        buttonsDir = packageDir </> ".buttons"
        genButton = buttonsDir </> "install-00-generate-exe.button"
    genExists <- doesFileExist genButton
    when genExists $ removeFile genButton
  sequences <- forM packagePaths $ \packageRelative -> do
    let packageDir = absoluteRoot </> "projects" </> packageRelative
        buttonsDir = packageDir </> ".buttons"
        sequencePath = buttonsDir </> "install.buttons"
        endpoint = normalise (makeRelative buttonsDir (absoluteRoot </> "bin" </> toolExe "gofur"))
    -- Do NOT emit the gen-exe button as part of install sequence; it overwrites manual cabal edits.
    -- Only write the cabal install button when the package declares an executable
    cabalFiles <- listDirectory packageDir
    let cabalCandidates = filter (".cabal" `List.isSuffixOf`) cabalFiles
    hasExe <- fmap or $ forM cabalCandidates $ \c -> do
      let path = packageDir </> c
      exists <- doesFileExist path
      if not exists
        then return False
        else do
          txt <- readFileStrict path
          return ("executable " `List.isInfixOf` txt)

    let entries = if hasExe then ["install-01-cabal-install.button"] else []
    current <- Verification.isWiresInstallCurrent absoluteRoot packageRelative
    if current then return () else removeStageSkips buttonsDir "install"
    cleanupStalePhaseArtifacts buttonsDir "install" ("install.buttons" : entries)

    if hasExe
      then do
        -- ensure any stale gen-exe button is removed
        let genButton = buttonsDir </> "install-00-generate-exe.button"
        genExists <- doesFileExist genButton
        when genExists $ removeFile genButton
        Buttons.writeButton buttonsDir "install-01-cabal-install.button" endpoint (unwords ["install-package", "..", packageRelative])
        Buttons.writeButtons sequencePath entries
      else do
        -- ensure any stale gen-exe button is removed and write empty sequence
        let genButton = buttonsDir </> "install-00-generate-exe.button"
        genExists <- doesFileExist genButton
        when genExists $ removeFile genButton
        Buttons.writeButtons sequencePath []
    return (normalise (makeRelative installDir sequencePath))
  Buttons.writeButtons (installDir </> "install.buttons") sequences
  return ("generated gofur install buttons\npackages: " ++ show (length packagePaths))

toolExe :: String -> FilePath
toolExe name =
  if os == "mingw32" then name <.> "exe" else name

-- Remove any `install-00-generate-exe.button` lines from a sequence file.
-- (sanitization removed; generator no longer emits install-00 entries)

readOrCreateNut :: FilePath -> FilePath -> IO String
readOrCreateNut root packageRelative = do
  let packageDir = root </> "projects" </> packageRelative
      nutPath = packageDir </> "package.nut"
  nutExists <- doesFileExist nutPath
  if nutExists
    then readFileStrict nutPath
    else do
      -- try to locate any .nut file under the package directory (covers garrage src/<pkg>/package.nut)
      found <- findFirstNut packageDir
      case found of
        Just p -> readFileStrict p
        Nothing -> do
          _ <- garrageToNutFile root packageRelative
          readFileStrict nutPath

readProjectPackages :: FilePath -> IO [FilePath]
readProjectPackages =
  readProjectPackagesWithSelection regularOnly

readProjectPackagesWithSelection :: PackageSelection -> FilePath -> IO [FilePath]
readProjectPackagesWithSelection selection root = do
  let projectsWires = root </> "projects" </> "projects.wires"
  pwExists <- doesFileExist projectsWires
  if pwExists
    then do
      -- `projects/projects.wires` supports two forms:
      -- 1) simple list: one package path per non-empty line
      -- 2) sectioned form mirroring `wire.project`:
      --    packages:\n    <space>path\n    bootstrap-packages:\n    <space>path
      text <- readFileStrict projectsWires
      let raw = lines text
          stripComments s = takeWhile (/= '#') s
          trim s = let f = reverse . dropWhile isSpace in f (f s)
          cleaned = map (trim . stripComments) raw
          nonEmpty = filter (not . null) cleaned
          -- parse sections if present
          hasSections = any (`elem` ["packages:", "bootstrap-packages:"]) nonEmpty
      if not hasSections
        then do
          valid <- validatePackageEntries root nonEmpty
          return (selectPackages selection valid [])
        else do
          let go [] _ accReg accBoot = (reverse accReg, reverse accBoot)
              go (l:ls) mode accReg accBoot
                | l == "packages:" = go ls "packages" accReg accBoot
                | l == "bootstrap-packages:" = go ls "boot" accReg accBoot
                | mode == "packages" = go ls mode (l:accReg) accBoot
                | mode == "boot" = go ls mode accReg (l:accBoot)
                | otherwise = go ls mode accReg accBoot
              (regs, boots) = go nonEmpty "" [] []
          validRegs <- validatePackageEntries root regs
          validBoots <- validatePackageEntries root boots
          return (selectPackages selection validRegs validBoots)
    else do
      let projectFile = root </> "projects" </> "wire.project"
      exists <- doesFileExist projectFile
      if not exists
        then return []
        else do
          text <- readFileStrict projectFile
          let regularPackages = Descriptor.parseIndentedList "packages:" text
              bootstrapPackages = Descriptor.parseIndentedList "bootstrap-packages:" text
          return (selectPackages selection regularPackages bootstrapPackages)

data PackageSelection =
  PackageSelection
    { includeRegularPackages :: Bool
    , includeBootstrapPackages :: Bool
    }

regularOnly :: PackageSelection
regularOnly = PackageSelection True False

parsePackageSelection :: String -> Maybe PackageSelection
parsePackageSelection "--dont-exclude-bootstrap" = Just (PackageSelection True True)
parsePackageSelection "--bootstrap-only" = Just (PackageSelection False True)
parsePackageSelection _ = Nothing

selectPackages :: PackageSelection -> [FilePath] -> [FilePath] -> [FilePath]
selectPackages selection regularPackages bootstrapPackages =
  List.nub $
    (if includeRegularPackages selection then regularPackages else []) ++
    (if includeBootstrapPackages selection then bootstrapPackages else [])

renderTwoStanzaCabal :: String -> [String] -> [String] -> String
renderTwoStanzaCabal packageName exposedModules depends =
  let cabalName = Descriptor.cabalPackageName packageName
      packageDepends = filter (`notElem` [cabalName, "base"]) depends
      header =
        [ "cabal-version: 3.0"
        , "name: " ++ cabalName
        , "version: 0.1.0.0"
        , "build-type: Simple"
        , ""
        , "library"
        , "  exposed-modules:"
        ] ++ map ("      " ++) exposedModules ++
        [ "  hs-source-dirs:"
        , "      lib"
        , "  build-depends:"
        , "      base >=4.14 && <5"
        ]
      footer =
        [ "  default-language:"
        , "      Haskell2010"
        , "  ghc-options: -Wall"
        , ""
        , "executable " ++ packageName
        , "  main-is:"
        , "      Main.hs"
        , "  hs-source-dirs:"
        , "      exe"
        , "  build-depends:"
        , "      base >=4.14 && <5"
        , "    , " ++ cabalName
        , "  default-language:"
        , "      Haskell2010"
        , "  ghc-options: -Wall"
        ]
  in unlines (header ++ map ("    , " ++) packageDepends ++ [""] ++ footer)

exeNutContent :: String -> String
exeNutContent packageName =
  unlines
    [ "name: " ++ packageName ++ "-exe"
    , "depends:"
    , "exposes:"
    , ""
    ]

renderBolt :: [String] -> String
renderBolt depends =
  unlines ("depends:" : map ("  " ++) depends)

waitForCreatedProcess :: Maybe Handle -> Maybe Handle -> Maybe Handle -> ProcessHandle -> IO ExitCode
waitForCreatedProcess _ _ _ processHandle =
  waitForProcess processHandle

readFileStrict :: FilePath -> IO String
readFileStrict path = do
  text <- readFile path
  length text `seq` return text

-- Validate that package entries correspond to existing buildable folders.
-- A valid package directory is one that exists under `projects/` and
-- contains either a `cabal.project` file, a `wire.project` file, or a
-- `.buttons` directory. Returns the subset of entries that are valid.
validatePackageEntries :: FilePath -> [FilePath] -> IO [FilePath]
validatePackageEntries root entries = do
  let projectsRoot = root </> "projects"
  fmap concat $ forM entries $ \e -> do
    let pkgDir = projectsRoot </> e
        cabalP = pkgDir </> "cabal.project"
        wireP = pkgDir </> "wire.project"
        buttonsD = pkgDir </> ".buttons"
    existsDir <- doesDirectoryExist pkgDir
    if not existsDir
      then do
        putStrLn ("gofur skipped " ++ e ++ ": missing directory")
        return []
      else do
        hasCabal <- doesFileExist cabalP
        hasWire <- doesFileExist wireP
        hasButtons <- doesDirectoryExist buttonsD
        if hasCabal || hasWire || hasButtons
          then return [e]
          else do
            putStrLn ("gofur skipped " ++ e ++ ": no cabal.project, wire.project, or .buttons found")
            return []

findFirstNut :: FilePath -> IO (Maybe FilePath)
findFirstNut base = do
  exists <- doesDirectoryExist base
  if not exists
    then return Nothing
    else do
      entries <- listDirectory base
      let loop [] = return Nothing
          loop (e:es) = do
            let p = base </> e
            isDir <- doesDirectoryExist p
            isFile <- doesFileExist p
            if isFile && takeExtension p == ".nut"
              then return (Just p)
              else if isDir
                then do
                  r <- findFirstNut p
                  case r of
                    Just _ -> return r
                    Nothing -> loop es
                else loop es
      loop entries


-- | Stage API: materialise a `package.bolt` and `exe/Main.hs` from
-- an existing `package.nut`. This is the canonical Gofur-owned
-- advance operation: it writes `package.bolt` describing executable
-- dependency on the package and emits a generated `exe/Main.hs`.
advanceToBolt :: FilePath -> FilePath -> IO String
advanceToBolt root packageRelative = do
  let packageDir = root </> "projects" </> packageRelative
      nutPath = packageDir </> "package.nut"
      boltPath = packageDir </> "package.bolt"
      exeDir = packageDir </> "exe"
      packageName = takeFileName packageRelative
  nutExists <- doesFileExist nutPath
  if not nutExists
    then return ("gofur advance skipped " ++ packageRelative ++ ": no package.nut")
    else do
      nutText <- readFileStrict nutPath
      case Descriptor.parseField "go-is:" nutText of
        Nothing -> return ("gofur advance skipped " ++ packageRelative ++ ": no go-is in nut")
        Just goTarget -> do
          let target = Descriptor.splitGoTarget goTarget
              moduleName = Descriptor.goTargetModule target
          createDirectoryIfMissing True exeDir
          writeFile (exeDir </> "Main.hs") (Codegen.renderGoMain moduleName False)
          writeFile boltPath (renderBolt [packageName])
          return ("gofur advance wrote package.bolt and exe/Main.hs for " ++ packageRelative)

removeStageSkips :: FilePath -> String -> IO ()
removeStageSkips buttonsDir prefix = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if (prefix `List.isPrefixOf` entry || entry == prefix ++ ".buttons.skip") && ".skip" `List.isSuffixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

cleanupInactivePhaseButtons :: FilePath -> [FilePath] -> String -> IO ()
cleanupInactivePhaseButtons root activePackages phase = do
  buttonsDirs <- discoverButtonsDirs (root </> "projects")
  let active = map normalise activePackages
  forM_ buttonsDirs $ \buttonsDir -> do
    let packageRelative = normalise (makeRelative (root </> "projects") (takeDirectory buttonsDir))
    if packageRelative `elem` active
      then return ()
      else removePhaseFiles buttonsDir phase

discoverButtonsDirs :: FilePath -> IO [FilePath]
discoverButtonsDirs projectsRoot = do
  exists <- doesDirectoryExist projectsRoot
  if not exists
    then return []
    else do
      projects <- listDirectory projectsRoot
      fmap concat $ forM projects $ \projectName -> do
        let srcRoot = projectsRoot </> projectName </> "src"
        srcExists <- doesDirectoryExist srcRoot
        if not srcExists
          then return []
          else do
            packages <- listDirectory srcRoot
            return [srcRoot </> packageName </> ".buttons" | packageName <- packages]

removePhaseFiles :: FilePath -> String -> IO ()
removePhaseFiles buttonsDir phase = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if phase `List.isPrefixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

cleanupStalePhaseArtifacts :: FilePath -> String -> [FilePath] -> IO ()
cleanupStalePhaseArtifacts buttonsDir phase keep = do
  exists <- doesDirectoryExist buttonsDir
  when exists $ do
    entries <- listDirectory buttonsDir
    forM_ entries $ \entry ->
      when (phase `List.isPrefixOf` entry && entry `notElem` keep && takeExtension entry `elem` [".button", ".buttons"]) $ do
        fileExists <- doesFileExist (buttonsDir </> entry)
        when fileExists (removeFile (buttonsDir </> entry))
