module Gofur where

import Folders.Routes
import qualified Folders.Project as FP
import qualified Gofur.Install as Install

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--list\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts =
  [ RouteOptout { routeOptoutOption = "--generate-buttons", routeOptoutReason = "generates install-stage buttons before the buttonized phase runs" }
  , RouteOptout { routeOptoutOption = "install", routeOptoutReason = "runs the gofur install phase over the active project list" }
  , RouteOptout { routeOptoutOption = "install-package", routeOptoutReason = "runs gofur installation for a single package and records its install stamp" }
  , RouteOptout { routeOptoutOption = "garrage-to-nut", routeOptoutReason = "advances a primitive garrage descriptor to gofur nut form" }
  , RouteOptout { routeOptoutOption = "gen-exe", routeOptoutReason = "generates the executable source and cabal stanza for gofur install" }
  , RouteOptout { routeOptoutOption = "create", routeOptoutReason = "create a minimal hello-style project via folders" }
  ]

go :: String -> [String] -> IO String
go "--list" [] = pure (show ["--list", "--generate-buttons", "install", "install-package", "garrage-to-nut", "gen-exe", "create"])
go "--list" _ = pure "--list expects no arguments"
go "--generate-buttons" [root] = Install.generateGofurButtons root
go "--generate-buttons" [root, mode] = Install.generateGofurButtonsWithMode root mode
go "--generate-buttons" _ = pure "usage: gofur.exe --generate-buttons <root> [--dont-exclude-bootstrap|--bootstrap-only]"
go "install" [root] = Install.installRoot root
go "install" _ = pure "usage: gofur.exe install <root>"
go "install-package" [root, packageRelative] = Install.installPackage root packageRelative
go "install-package" _ = pure "usage: gofur.exe install-package <root> <packageRelative>"
go "garrage-to-nut" [root, packageRelative] = Install.garrageToNutFile root packageRelative
go "garrage-to-nut" _ = pure "usage: gofur.exe garrage-to-nut <root> <packageRelative>"
go "gen-exe" [root, packageRelative, outSubdir] = Install.genExe root packageRelative outSubdir
go "gen-exe" _ = pure "usage: gofur.exe gen-exe <root> <packageRelative> <outSubdir>"
go "create" [root, projectName] = do
  msg <- FP.createHelloProject root projectName
  _ <- Install.genExe root projectName "."
  return msg
go "create" _ = pure "usage: gofur.exe create <root> <projectName>"
go option _ = pure ("unknown gofur option: " ++ option)
