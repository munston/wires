module Gofur.Verification where

import System.Directory
import System.FilePath
import System.IO
import Garrage.Verification

-- | Path to the stage install stamp under the root `.wires-verification`.
wiresStageStampFile :: FilePath -> FilePath -> FilePath -> FilePath
wiresStageStampFile root packageRelative stampName =
  root </> ".wires-verification" </> normalise packageRelative </> stampName

wiresInstallStampFile :: FilePath -> FilePath -> FilePath
wiresInstallStampFile root packageRelative = wiresStageStampFile root packageRelative "install.stamp"

wiresTestStampFile :: FilePath -> FilePath -> FilePath
wiresTestStampFile root packageRelative = wiresStageStampFile root packageRelative "test.stamp"

readWiresStampLine :: FilePath -> IO String
readWiresStampLine path = withFile path ReadMode hGetLine

-- | Determine whether the recorded Wires install-stage stamp matches the
-- current project fingerprint. This mirrors the idempotency check used by
-- Wires (checks `install.stamp` under `.wires-verification/<package>/`).
isWiresInstallCurrent :: FilePath -> FilePath -> IO Bool
isWiresInstallCurrent root packageRelative = do
  current <- computeProjectStageFingerprint root packageRelative "install.stamp"
  let stampFile = wiresInstallStampFile root packageRelative
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- readWiresStampLine stampFile
      return (recorded == current)

-- | Record an arbitrary stage stamp under `.wires-verification/<package>/`.
recordWiresStage :: FilePath -> FilePath -> FilePath -> IO String
recordWiresStage root packageRelative stampName = do
  fingerprint <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = wiresStageStampFile root packageRelative stampName
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("wires " ++ takeBaseName stampName ++ " stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ fingerprint)

recordWiresInstallStamp :: FilePath -> FilePath -> IO String
recordWiresInstallStamp root packageRelative = recordWiresStage root packageRelative "install.stamp"

recordWiresTestStamp :: FilePath -> FilePath -> IO String
recordWiresTestStamp root packageRelative = recordWiresStage root packageRelative "test.stamp"
