module Gofur.Codegen where

import Data.List
import Folders.Routes

renderGoMain :: String -> Bool -> String
renderGoMain goModuleName useAlive =
  let aliveImport = ["import Gofur.Alive" | useAlive]
      dispatchLine =
        if useAlive
          then "dispatch (option : args) = withAliveRuntime option (" ++ goModuleName ++ ".go option args >>= print >> return ())"
          else "dispatch (option : args) = " ++ goModuleName ++ ".go option args >>= print >> return ()"
  in
  unlines
    ( [ "-- generated-by: gofur codegen 0.1"
      , "module Main where"
      , ""
      , "import System.Environment"
      ]
    ++ aliveImport
    ++ [ "import qualified " ++ goModuleName
       , ""
       , "main :: IO ()"
       , "main = getArgs >>= dispatch . normalizeArgs"
       , ""
       , "normalizeArgs :: [String] -> [String]"
       , "normalizeArgs [single] = words single"
       , "normalizeArgs args = args"
       , ""
       , "dispatch :: [String] -> IO ()"
       , dispatchLine
       , "dispatch [] = fail \"missing gofur option\""
       ]
    )

renderCogMain :: String -> [String] -> [VerifiedRoute] -> String
renderCogMain goModuleName _rootOptions routes =
  -- If no explicit routes were provided, emit a minimal cog main that
  -- avoids forcing any package-specific imports when there is nothing
  -- to verify.
  if null routes
    then unlines
      [ "-- generated-by: gofur codegen 0.1"
      , "module Main where"
      , ""
      , "import System.Exit"
      , ""
      , "main :: IO ()"
      , "main = return ()"
      ]
    else
      let effectiveRoutes = routes
      in unlines
        ( [ "-- generated-by: gofur codegen 0.1"
          , "module Main where"
          , ""
          ]
        ++ dataListImport effectiveRoutes
        ++ [ "import System.Exit"
          , "import qualified " ++ goModuleName
          , ""
          , "main :: IO ()"
          , "main = do"
          ]
        ++ concatMap renderCogCase effectiveRoutes
        ++ [ "  return ()"
           , ""
           , "runCase :: String -> [String] -> (String -> Bool) -> IO ()"
           , "runCase option args predicate = do"
           , "  value <- " ++ goModuleName ++ ".go option args"
           , "  if predicate value"
           , "    then return ()"
           , "    else do"
           , "      putStrLn (\"cog failed for \" ++ option ++ \": \" ++ value)"
           , "      exitFailure"
          ] )

nullListRoute :: VerifiedRoute
nullListRoute =
  VerifiedRoute
    { routeOption = "--list"
    , routeArgs = []
    , routePrecog = "\\s -> \"--list\" `isInfixOf` s"
    }

dataListImport :: [VerifiedRoute] -> [String]
dataListImport routes =
  ["import Data.List" | any (isInfixOf "isInfixOf" . routePrecog) routes]

renderCogCase :: VerifiedRoute -> [String]
renderCogCase entry =
  [ "  runCase " ++ show option ++ " " ++ show args ++ " (" ++ body ++ ")"
  ]
  where
    option = routeOption entry
    args = routeArgs entry
    body = routePrecog entry
