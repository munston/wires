{-# LANGUAGE TypeFamilies #-}

module Gofur.Object where

-- Minimal, non-opinionated extensibility surface for `gofur`.
-- This file defines the `Gofur` typeclass with associated data
-- declarations only. Concrete representations (Cabal, Wires, etc.)
-- should provide `instance Gofur ...` in their own packages.

import System.FilePath

class Gofur rep where
  -- Associated data types for the representation `rep`.
  data GofurObject rep
  data GofurMetadata rep
  data GofurProject rep
  data GofurPackage rep

  -- Smart-constructor methods. Instances should implement these to
  -- provide a stable construction API per representation.
  mkGofurObject :: FilePath -> GofurMetadata rep -> GofurProject rep -> [GofurPackage rep] -> GofurObject rep
  mkGofurMetadata :: FilePath -> String -> Maybe String -> FilePath -> FilePath -> FilePath -> Maybe String -> Maybe String -> GofurMetadata rep
  mkGofurProject :: FilePath -> [FilePath] -> [FilePath] -> GofurProject rep

-- Note: Intentionally no default `CabalRep` instance or concrete
-- data declarations are provided here — that was an artificial
-- structure added earlier and has been removed. Concrete packages
-- (for example `gofur`'s Cabal package or `wires`) should implement
-- `instance Gofur MyRep` in their own modules to keep separation of
-- concerns and avoid imposing layout-specific shapes here.
