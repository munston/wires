name: gofur
depends:
  folders
  garrage
exposes:
  Gofur
  Gofur.Alive
  Gofur.Codegen
  Gofur.Folders
  Gofur.Install
  Gofur.Object
  Gofur.Verification
go-is: Gofur.go
