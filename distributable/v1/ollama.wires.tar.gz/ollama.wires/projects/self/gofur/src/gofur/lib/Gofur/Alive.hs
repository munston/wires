module Gofur.Alive where

import Control.Concurrent
import Control.Exception
import Data.Char
import Data.Unique
import System.Directory
import System.Environment
import System.FilePath

data AliveEvent a =
  AliveActionDone a
  | AliveActionFailed String
  | AliveDeleted

withAliveRuntime :: String -> IO a -> IO a
withAliveRuntime option action = do
  currentExePath <- getExecutablePath
  unique <- newUnique
  let executableDir = takeDirectory currentExePath
      executableName = takeBaseName currentExePath
      runId = sanitizeAlivePart option ++ "-" ++ show (hashUnique unique)
      aliveDir = executableDir </> ".alive" </> executableName
      aliveFile = aliveDir </> runId <.> "alive"
  withAlive aliveDir aliveFile 500000 action

withAlive :: FilePath -> FilePath -> Int -> IO a -> IO a
withAlive aliveDir aliveFile delay action = do
  createDirectoryIfMissing True aliveDir
  writeFile aliveFile "alive"
  event <- newEmptyMVar
  worker <- forkIO (runWorker event action)
  watcher <- forkIO (runWatcher event aliveFile delay)
  result <- takeMVar event
  killThread watcher
  killThread worker
  resolveAlive aliveFile result

runWorker :: MVar (AliveEvent a) -> IO a -> IO ()
runWorker event action = catch runAction (workerFailed event)
  where
    runAction = do
      value <- action
      _ <- tryPutMVar event (AliveActionDone value)
      return ()

workerFailed :: MVar (AliveEvent a) -> SomeException -> IO ()
workerFailed event exception = do
  _ <- tryPutMVar event (AliveActionFailed (show exception))
  return ()

runWatcher :: MVar (AliveEvent a) -> FilePath -> Int -> IO ()
runWatcher event aliveFile delay = do
  exists <- doesFileExist aliveFile
  if exists
    then do
      threadDelay delay
      runWatcher event aliveFile delay
    else do
      _ <- tryPutMVar event AliveDeleted
      return ()

resolveAlive :: FilePath -> AliveEvent a -> IO a
resolveAlive aliveFile event =
  case event of
    AliveActionDone value -> do
      cleanupAlive aliveFile
      return value
    AliveActionFailed message -> do
      cleanupAlive aliveFile
      error message
    AliveDeleted ->
      error "gofur alive file removed"

cleanupAlive :: FilePath -> IO ()
cleanupAlive aliveFile = do
  exists <- doesFileExist aliveFile
  if exists
    then removeFile aliveFile
    else return ()

sanitizeAlivePart :: String -> String
sanitizeAlivePart value =
  case map sanitizeAliveChar value of
    [] -> "run"
    chars -> chars

sanitizeAliveChar :: Char -> Char
sanitizeAliveChar char
  | isAlphaNum char = char
  | otherwise = '_'
