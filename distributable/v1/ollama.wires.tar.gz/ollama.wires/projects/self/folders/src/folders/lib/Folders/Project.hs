module Folders.Project where

import Data.Char
import System.Directory
import System.FilePath
import Control.Exception
import Control.Monad
import Control.Concurrent

validProjectName :: String -> Bool
validProjectName value =
  not (null value) && all validProjectChar value && any isAlpha value

validProjectChar :: Char -> Bool
validProjectChar char =
  isAlphaNum char || char == '_' || char == '-'

projectModuleName :: String -> String
projectModuleName =
  concatMap capitalizePart . wordsBySeparator

wordsBySeparator :: String -> [String]
wordsBySeparator value =
  case dropWhile separator value of
    "" -> []
    rest ->
      let (word, next) = break separator rest
      in word : wordsBySeparator next

separator :: Char -> Bool
separator char =
  char == '_' || char == '-'

capitalizePart :: String -> String
capitalizePart "" = ""
capitalizePart (char:chars) = toUpper char : map normalizeModuleChar chars

normalizeModuleChar :: Char -> Char
normalizeModuleChar char
  | isAlphaNum char = char
  | otherwise = '_'

cabalPackageName :: String -> String
cabalPackageName =
  map (\char -> if char == '_' then '-' else toLower char)

createHelloProject :: FilePath -> FilePath -> IO String
createHelloProject root projectName
  | not (validProjectName projectName) =
      error ("invalid project name: " ++ projectName)
  | otherwise = do
      let projectRoot = root </> "projects" </> projectName
      exists <- doesPathExist projectRoot
      if exists
        then do
          contents <- listDirectory projectRoot
          if not (null contents)
            then error ("project already exists: " ++ projectRoot)
            else return ("folders created minimal project skeleton: " ++ projectName)
        else do
          -- Create only the minimal project directory. Concrete
          -- source/layout generation belongs to Garrage/Gofur/Wires
          -- so Folders should not materialize hello-style source.
          createDirectoryIfMissing True projectRoot
          return ("folders created minimal project skeleton: " ++ projectName)

-- | Remove a package directory under `projects/<project>/src/<pkg>`.
removePackage :: FilePath -> String -> String -> IO String
removePackage root projectName packageName = do
  let pkgDir = root </> "projects" </> projectName </> "src" </> packageName
  exists <- doesPathExist pkgDir
  if not exists
    then return ("package not found: " ++ pkgDir)
    else do
      _ <- try (removePathForcibly pkgDir) :: IO (Either SomeException ())
      let projectCabal = root </> "projects" </> projectName </> "cabal.project"
      removeIndentedEntryIfExists projectCabal ("  src/" ++ projectName)
      return ("removed package: " ++ projectName ++ "/src/" ++ packageName)

removeIndentedEntryIfExists :: FilePath -> String -> IO ()
removeIndentedEntryIfExists path entry = do
  exists <- doesFileExist path
  if not exists
    then return ()
    else do
      contents <- readFile path
      let rows = lines contents
          rows' = filter (/= entry) rows
      when (rows /= rows') $ writeFile path (unlines rows')

-- | Exact-match removal of a registration line (e.g. "  aws-host/aws-host").
-- This is the low-level primitive used by the canonical unregister path.
removeIndentedEntryExact :: FilePath -> String -> IO ()
removeIndentedEntryExact = removeIndentedEntryIfExists

-- | Retry an IO action a few times when it fails with an IOException
-- (e.g. transient file lock / sharing violation on Windows).
-- This makes unregistration much more reliable during active builds.
retryIO :: Int -> IO () -> IO ()
retryIO 0 action = action
retryIO attempts action = do
  result <- try action :: IO (Either IOException ())
  case result of
    Right () -> return ()
    Left _   -> do
      threadDelay 150000  -- 150 ms backoff
      retryIO (attempts - 1) action

-- | Remove an exact registration line, with retry on transient file locks.
removeIndentedEntryExactWithRetry :: FilePath -> String -> IO ()
removeIndentedEntryExactWithRetry path entry =
  retryIO 6 (removeIndentedEntryExact path entry)

-- | Ensure an indented entry exists under a header (e.g. "packages:" or "bootstrap-packages:").
-- This is the canonical way to register a package into wire.project or cabal.project.
ensureIndentedEntry :: FilePath -> String -> String -> IO ()
ensureIndentedEntry projectFile header value = do
  exists <- doesFileExist projectFile
  if not exists
    then do
      createDirectoryIfMissing True (takeDirectory projectFile)
      writeFile projectFile (unlines [header, "  " ++ value])
    else do
      text <- readFile projectFile
      let rows = lines text
          entry = "  " ++ value
      when (entry `notElem` rows) $
        writeFile projectFile (unlines (insertIndentedEntry header entry rows))

insertIndentedEntry :: String -> String -> [String] -> [String]
insertIndentedEntry header entry rows =
  case break ((== header) . trimLine) rows of
    (_, []) -> rows ++ ["", header, entry]
    (before, sectionStart:after) -> before ++ sectionStart : entry : after

trimLine :: String -> String
trimLine =
  dropWhile (== ' ') . reverse . dropWhile (== ' ') . reverse

-- | Register a package using its actual relative path as stored in wire.project.
-- Example paths: "myproject/src/mypkg" or "aws-host/aws-host"
registerPackage :: FilePath -> FilePath -> IO String
registerPackage root packageRelative = do
  let wire = root </> "projects" </> "wire.project"
      cabal = root </> "projects" </> "cabal.project"
  ensureIndentedEntry wire "packages:" (normalise packageRelative)
  ensureIndentedEntry cabal "packages:" (normalise packageRelative)
  return ("registered package: " ++ normalise packageRelative)

-- | Unregister a package using its exact registered relative path (the canonical form).
--
-- This is the symmetric counterpart to 'registerPackage'.
-- It removes the exact entry (e.g. "aws-host/aws-host" or "hnlp/src/hnlp")
-- from both wire.project and cabal.project, and deletes the corresponding
-- package directory under projects/.
--
-- For direct-layout packages (aws-host/aws-host style) this is the only safe way
-- to remove the registration without guessing.
--
-- Directory deletion targets exactly the packageRelative (the leaf that contains
-- the .cabal). Removing an entire top-level project bucket is a separate concern.
unregisterPackage :: FilePath -> FilePath -> IO String
unregisterPackage root packageRelative = do
  let rel = normalise packageRelative
      pkgDir = root </> "projects" </> rel
      wire   = root </> "projects" </> "wire.project"
      cabal  = root </> "projects" </> "cabal.project"

  -- CRITICAL: Remove the exact registration lines FIRST, with retries for locks.
  -- This must succeed even if the directory is gone or other steps fail.
  removeIndentedEntryExactWithRetry wire ("  " ++ rel)
  removeIndentedEntryExactWithRetry cabal ("  " ++ rel)

  -- Directory deletion is best-effort and can happen after line removal.
  dirExisted <- doesPathExist pkgDir
  when dirExisted $
    void (try (removePathForcibly pkgDir) :: IO (Either SomeException ()))

  if dirExisted
    then return ("unregistered package: " ++ rel)
    else return ("unregistered stale package entry: " ++ rel ++ " (directory was already absent)")

-- | Force removal of the exact registration lines for a packageRelative.
-- This does *not* delete any directory or touch verification state.
-- It is the recovery / "last resort" tool when normal unregister is blocked
-- by locks or other issues. It guarantees the lines are gone from
-- wire.project and cabal.project (with retries).
purgePackageRegistration :: FilePath -> FilePath -> IO String
purgePackageRegistration root packageRelative = do
  let rel = normalise packageRelative
      wire = root </> "projects" </> "wire.project"
      cabal = root </> "projects" </> "cabal.project"

  removeIndentedEntryExactWithRetry wire ("  " ++ rel)
  removeIndentedEntryExactWithRetry cabal ("  " ++ rel)

  return ("purged package registration: " ++ rel)

-- | Remove an entire top-level project directory (e.g. the whole "aws-host/" bucket).
-- This is the destructive "nuke the parent" operation.
-- It removes the directory and best-effort removes any registration lines
-- that start with the given top-level prefix.
removeTopLevelProject :: FilePath -> String -> IO String
removeTopLevelProject root topLevel = do
  let topDir = root </> "projects" </> topLevel
      wire = root </> "projects" </> "wire.project"
      cabal = root </> "projects" </> "cabal.project"

  -- Remove registration lines first (with retry for locks), then dir.
  removeEntriesWithPrefixWithRetry wire ("  " ++ topLevel ++ "/")
  removeEntriesWithPrefixWithRetry cabal ("  " ++ topLevel ++ "/")

  exists <- doesPathExist topDir
  when exists $
    void (try (removePathForcibly topDir) :: IO (Either SomeException ()))

  if exists
    then return ("removed top-level project: " ++ topLevel)
    else return ("removed stale top-level project registrations: " ++ topLevel ++ " (directory was already absent)")

-- | Remove all lines in a project file that start with the given prefix.
removeEntriesWithPrefix :: FilePath -> String -> IO ()
removeEntriesWithPrefix path prefix = do
  exists <- doesFileExist path
  when exists $ do
    contents <- readFile path
    let rows = lines contents
        rows' = filter (not . (`isPrefixedBy` prefix)) rows
    when (rows /= rows') $
      writeFile path (unlines rows')
  where
    isPrefixedBy line pre = take (length pre) line == pre

-- | Version of removeEntriesWithPrefix that retries on transient file locks.
removeEntriesWithPrefixWithRetry :: FilePath -> String -> IO ()
removeEntriesWithPrefixWithRetry path prefix =
  retryIO 6 (removeEntriesWithPrefix path prefix)

-- | Legacy: Remove using only a top-level project name and old guessed patterns.
--
-- This is the pre-canonical form. It only works reliably for classic hello-style
-- registrations of the form "name/src/name". For direct packages such as
-- "aws-host/aws-host" it will leave stale entries in wire.project / cabal.project.
--
-- Prefer 'unregisterPackage' (exact packageRelative) for all new code.
removeProject :: FilePath -> String -> IO String
removeProject root projectName = do
  let projectRoot = root </> "projects" </> projectName
  exists <- doesPathExist projectRoot
  if not exists
    then return ("project not found: " ++ projectRoot)
    else do
      _ <- try (removePathForcibly projectRoot) :: IO (Either SomeException ())
      let wireProject = root </> "projects" </> "wire.project"
          cabalProject = root </> "projects" </> "cabal.project"
      -- Best effort with the old simple pattern (will be improved when callers
      -- start passing the real registered relative path)
      removeIndentedEntryIfExists wireProject ("  " ++ projectName ++ "/src/" ++ projectName)
      removeIndentedEntryIfExists cabalProject ("  " ++ projectName ++ "/src/" ++ projectName)
      return ("removed project: " ++ projectName)

renderProjectCabalProject :: String -> String
renderProjectCabalProject projectName =
  unlines
    [ "-- generated-by: folders create-hello-project"
    , "packages:"
    , "  src/" ++ projectName
    , "  ../self/folders/src/folders"
    , "  ../self/wires"
    , "  ../gofur"
    ]

renderHelloCabal :: String -> String -> String
renderHelloCabal projectName moduleName =
  let cabalName = cabalPackageName projectName
  in unlines
       [ "cabal-version: 3.0"
       , "name: " ++ cabalName
       , "version: 0.1.0.0"
       , "build-type: Simple"
       , ""
       , "library"
       , "  exposed-modules:"
       , "      " ++ moduleName
       , ""
       , "  hs-source-dirs:"
       , "      lib"
       , "  build-depends:"
       , "      base >=4.14 && <5"
       , "    , wires"
       , ""
       , "  default-language:"
       , "      Haskell2010"
       , "  ghc-options: -Wall"
       , ""
       , "executable " ++ projectName
       , "  main-is:"
       , "      Main.hs"
       , "  hs-source-dirs:"
       , "      exe"
       , "  build-depends:"
       , "      base >=4.14 && <5"
       , "    , " ++ cabalName
       , "    , gofur"
       , "    , wires"
       , ""
       , "  default-language:"
       , "      Haskell2010"
       , "  ghc-options: -Wall"
       , ""
       , "test-suite " ++ cabalName ++ "-cog"
       , "  type:"
       , "      exitcode-stdio-1.0"
       , "  main-is:"
       , "      CogMain.hs"
       , "  hs-source-dirs:"
       , "      cog"
       , ""
       , "  build-depends:"
       , "      base >=4.14 && <5"
       , "    , directory"
       , "    , filepath"
       , "    , process"
       , "    , " ++ cabalName
       , "    , wires"
       , ""
       , "  default-language:"
       , "      Haskell2010"
       , "  ghc-options: -Wall"
       ]

renderHelloNut :: String -> String
renderHelloNut moduleName =
  unlines
    [ "depends:"
    , "  wires"
    , "exposes:"
    , "  " ++ moduleName
    , "go-is: " ++ moduleName ++ ".go"
    ]

renderHelloBolt :: String -> String
renderHelloBolt _ =
  unlines
    [ "depends:"
    , "  wires"
    ]

renderHelloCog :: String -> String
renderHelloCog projectName =
  let cabalName = cabalPackageName projectName
  in unlines
       [ "test-suite: " ++ cabalName ++ "-cog"
       , "type: exitcode-stdio-1.0"
       , "main-is: CogMain.hs"
       , "source-dirs:"
       , "  cog"
       , "depends:"
       , "  " ++ projectName
       , "  wires"
       ]

renderHelloModule :: String -> String -> String
renderHelloModule projectName moduleName =
  let helloPrecog = "\\s -> s == " ++ show ("hello " ++ projectName ++ "!")
  in
  unlines
    [ "module " ++ moduleName ++ " where"
    , ""
    , "import Folders.Routes"
    , ""
    , "verifiedRoutes :: [VerifiedRoute]"
    , "verifiedRoutes ="
    , "  [ VerifiedRoute { routeOption = \"--list\", routeArgs = [], routePrecog = \"\\s -> \\\"--list\\\" `isInfixOf` s\" }"
    , "  , VerifiedRoute { routeOption = \"--hello\", routeArgs = [], routePrecog = " ++ show helloPrecog ++ " }"
    , "  ]"
    , ""
    , "routeOptouts :: [RouteOptout]"
    , "routeOptouts ="
    , "  []"
    , ""
    , "go :: String -> [String] -> IO String"
    , "go \"--list\" [] = pure (show [\"--list\", \"--hello\"])"
    , "go \"--list\" _ = pure \"--list expects no arguments\""
    , "go \"--hello\" [] = pure \"hello " ++ projectName ++ "!\""
    , "go \"--hello\" _ = pure \"hello expects no arguments\""
    , "go option _ = pure (\"unknown " ++ projectName ++ " option: \" ++ option)"
    ]

renderHelloMain :: String -> String
renderHelloMain moduleName =
  unlines
    [ "module Main where"
    , ""
    , "import System.Environment"
    , "import Gofur.Alive"
    , "import qualified " ++ moduleName
    , ""
    , "main :: IO ()"
    , "main = getArgs >>= dispatch . normalizeArgs"
    , ""
    , "normalizeArgs :: [String] -> [String]"
    , "normalizeArgs [single] = words single"
    , "normalizeArgs args = args"
    , ""
    , "dispatch :: [String] -> IO ()"
    , "dispatch (option : args) = withAliveRuntime option (" ++ moduleName ++ ".go option args >>= print >> return ())"
    , "dispatch [] = fail \"missing wires option\""
    ]

renderHelloCogMain :: String -> String
renderHelloCogMain projectName =
  unlines
    [ "module Main where"
    , ""
    , "import System.Exit"
    , "import System.FilePath"
    , "import System.Process"
    , ""
    , "main :: IO ()"
    , "main = do"
    , "  let exe = \"..\" </> \"bin\" </> " ++ show (projectName <.> "exe")
    , "  output <- readProcess exe [\"--hello\"] \"\""
    , "  let value = read output :: String"
    , "  if value == " ++ show ("hello " ++ projectName ++ "!")
    , "    then return ()"
    , "    else do"
    , "      putStrLn (\"cog failed for --hello: \" ++ value)"
    , "      exitFailure"
    ]
