-- generated-by: gofur codegen 0.1
module Main where

import System.Directory
import System.Exit
import System.FilePath
import System.Process

main :: IO ()
main = do
  root <- findProjectRoot
  project <- getCurrentDirectory
  runCase root project "--folders" ([] ++ rootArgument "--folders" root) (\s -> s == "folders ok")
  return ()

findProjectRoot :: IO FilePath
findProjectRoot = do
  current <- getCurrentDirectory
  return (normalise (current </> ".." </> ".." </> ".."))

runCase :: FilePath -> FilePath -> String -> [String] -> (String -> Bool) -> IO ()
runCase _root project option extraArgs predicate = do
  let exe = project </> "bin" </> "folders.exe"
      args = option : extraArgs
  output <- readProcess exe args ""
  let value = read output :: String
  if predicate value
    then return ()
    else do
      putStrLn ("cog failed for " ++ option ++ ": " ++ value)
      exitFailure

rootArgument :: String -> FilePath -> [String]
rootArgument option root
  | option `elem` rootOptions = [root]
  | otherwise = []

rootOptions :: [String]
rootOptions = []
