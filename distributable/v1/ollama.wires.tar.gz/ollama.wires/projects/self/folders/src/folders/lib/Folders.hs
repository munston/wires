module Folders where

import Folders.Routes
import Folders.Shape

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--folders", routeArgs = [], routePrecog = "\\s -> s == \"folders ok\"" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts = []

go :: String -> [String] -> IO String
go "--folders" [] = pure "folders ok"
go "--folders" _ = pure "folders expects no arguments"
go option _ = pure ("unknown folders option: " ++ option)
