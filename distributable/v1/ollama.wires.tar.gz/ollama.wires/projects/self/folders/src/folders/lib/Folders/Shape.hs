{-# LANGUAGE DataKinds #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE PolyKinds #-}
{-# LANGUAGE TypeOperators #-}

module Folders.Shape where

import Data.Kind

data FList (f :: k -> Type) (xs :: [k]) where
  FEmpty :: FList f '[]
  FCons  :: f x -> FList f xs -> FList f (x ': xs)

data Filetype
  = Bat
  | Exe
  | Alive
  | Buttons
  | Button
  | ButtonSkip
  | Plan
  | Project
  | Cabal
  | Nut
  | Garrage
  | Bolt
  | Cog
  | Hs
  | Txt
  | Md
  | Json
  | Wire
  | Stamp
  | Step
  deriving (Eq, Show)

data Folder a =
    Branches [Folder a] [a]
  | Leaf a

data HFile (filetype :: Filetype) where
  HFile :: String -> HFile filetype

data HFolder (folder :: Folder Filetype) where
  HBranches ::
    String ->
    FList HFolder folders ->
    FList HFile files ->
    HFolder ('Branches folders files)

  HLeaf ::
    HFile filetype ->
    HFolder ('Leaf filetype)

data TypedFile =
  TypedFile
    { typedFileType :: Filetype
    , typedFilePath :: FilePath
    }
  deriving (Eq, Show)

data FolderTree =
  FolderTree
    { folderTreeName :: FilePath
    , folderTreeFolders :: [FolderTree]
    , folderTreeFiles :: [TypedFile]
    }
  deriving (Eq, Show)

data WireFolders =
  WireFolders
    { wireOtherTree :: FolderTree
    , wireProjectsTree :: ProjectsTree
    }
  deriving (Eq, Show)

data ProjectsTree =
  ProjectsTree
    { projectsTreeName :: FilePath
    , projectsTreeProjects :: [ProjectTree]
    , projectsTreeFiles :: [TypedFile]
    }
  deriving (Eq, Show)

data ProjectTree =
  ProjectTree
    { projectTreeName :: FilePath
    , projectTreePackages :: [PackageTree]
    , projectTreeFolders :: [FolderTree]
    , projectTreeFiles :: [TypedFile]
    }
  deriving (Eq, Show)

data PackageTree =
  PackageTree
    { packageTreeName :: FilePath
    , packageTreeFolders :: [FolderTree]
    , packageTreeFiles :: [TypedFile]
    }
  deriving (Eq, Show)

rollWireFolders :: WireFolders -> FolderTree
rollWireFolders wireFolders =
  (wireOtherTree wireFolders)
    { folderTreeFolders =
        folderTreeFolders (wireOtherTree wireFolders)
          ++ [rollProjectsTree (wireProjectsTree wireFolders)]
    }

unrollWireFolders :: FolderTree -> WireFolders
unrollWireFolders tree =
  let (beforeProjects, fromProjects) =
        break ((== "projects") . folderTreeName) (folderTreeFolders tree)
   in case fromProjects of
        [] ->
          WireFolders
            { wireOtherTree = tree
            , wireProjectsTree = ProjectsTree "projects" [] []
            }
        projectsFolder : afterProjects ->
          WireFolders
            { wireOtherTree = tree { folderTreeFolders = beforeProjects ++ afterProjects }
            , wireProjectsTree = unrollProjectsTree projectsFolder
            }

rollProjectsTree :: ProjectsTree -> FolderTree
rollProjectsTree projectsTree =
  FolderTree
    { folderTreeName = projectsTreeName projectsTree
    , folderTreeFolders = map rollProjectTree (projectsTreeProjects projectsTree)
    , folderTreeFiles = projectsTreeFiles projectsTree
    }

unrollProjectsTree :: FolderTree -> ProjectsTree
unrollProjectsTree tree =
  ProjectsTree
    { projectsTreeName = folderTreeName tree
    , projectsTreeProjects = map unrollProjectTree (folderTreeFolders tree)
    , projectsTreeFiles = folderTreeFiles tree
    }

rollProjectTree :: ProjectTree -> FolderTree
rollProjectTree projectTree =
  FolderTree
    { folderTreeName = projectTreeName projectTree
    , folderTreeFolders =
        projectTreeFolders projectTree
          ++ [ FolderTree
                 { folderTreeName = "src"
                 , folderTreeFolders = map rollPackageTree (projectTreePackages projectTree)
                 , folderTreeFiles = []
                 }
             ]
    , folderTreeFiles = projectTreeFiles projectTree
    }

unrollProjectTree :: FolderTree -> ProjectTree
unrollProjectTree tree =
  let (beforeSrc, fromSrc) =
        break ((== "src") . folderTreeName) (folderTreeFolders tree)
      packages =
        case fromSrc of
          [] -> []
          srcFolder : _ -> map unrollPackageTree (folderTreeFolders srcFolder)
   in ProjectTree
        { projectTreeName = folderTreeName tree
        , projectTreePackages = packages
        , projectTreeFolders =
            case fromSrc of
              [] -> beforeSrc
              _srcFolder : afterSrc -> beforeSrc ++ afterSrc
        , projectTreeFiles = folderTreeFiles tree
        }

rollPackageTree :: PackageTree -> FolderTree
rollPackageTree packageTree =
  FolderTree
    { folderTreeName = packageTreeName packageTree
    , folderTreeFolders = packageTreeFolders packageTree
    , folderTreeFiles = packageTreeFiles packageTree
    }

unrollPackageTree :: FolderTree -> PackageTree
unrollPackageTree tree =
  PackageTree
    { packageTreeName = folderTreeName tree
    , packageTreeFolders = folderTreeFolders tree
    , packageTreeFiles = folderTreeFiles tree
    }

type PackageFolder =
  'Branches
    '[]
    '[ Nut, Garrage, Bolt, Cog, Cabal, Hs ]

type ProjectFolder =
  'Branches
    '[ PackageFolder ]
    '[ Project ]

type ProjectsFolder =
  'Branches
    '[ ProjectFolder ]
    '[]

type WireRoot =
  'Branches
    '[ ProjectsFolder ]
    '[ Wire, Bat, Buttons, Plan ]

wireRoot :: HFolder WireRoot
wireRoot =
  HBranches
    "wire"
    (projects `FCons` FEmpty)
    ( HFile "ollama.wire"
        `FCons` (HFile "install.bat"
        `FCons` (HFile "install.buttons"
        `FCons` (HFile "buttons.plan" `FCons` FEmpty)))
    )

projects :: HFolder ProjectsFolder
projects =
  HBranches
    "projects"
    (project `FCons` FEmpty)
    FEmpty

project :: HFolder ProjectFolder
project =
  HBranches
    "project"
    (package `FCons` FEmpty)
    (HFile "cabal.project" `FCons` FEmpty)

package :: HFolder PackageFolder
package =
  HBranches
    "package"
    FEmpty
    ( (HFile "package.nut" :: HFile 'Nut)
      `FCons` ( (HFile "package.garrage" :: HFile 'Garrage)
        `FCons` ( (HFile "package.bolt" :: HFile 'Bolt)
          `FCons` ( (HFile "package.cog" :: HFile 'Cog)
            `FCons` ( (HFile "package.cabal" :: HFile 'Cabal)
              `FCons` ( (HFile "Module.hs" :: HFile 'Hs) `FCons` FEmpty)
            )
          )
        )
      )
    )
