module Folders.Routes where

data VerifiedRoute =
  VerifiedRoute
    { routeOption :: String
    , routeArgs :: [String]
    , routePrecog :: String
    }
  deriving (Eq, Read, Show)

data RouteOptout =
  RouteOptout
    { routeOptoutOption :: String
    , routeOptoutReason :: String
    }
  deriving (Eq, Read, Show)
