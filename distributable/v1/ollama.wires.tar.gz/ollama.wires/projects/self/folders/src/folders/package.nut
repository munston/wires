name: folders
depends:
exposes:
  Folders
  Folders.Routes
  Folders.Project
  Folders.Shape
go-is: Folders.go
