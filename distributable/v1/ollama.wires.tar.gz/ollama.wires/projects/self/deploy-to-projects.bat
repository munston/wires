"%~dp0..\bin\buttons.exe" "%~dp0deploy-to-projects.buttons"
