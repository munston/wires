@echo off
setlocal

pushd "%~dp0buttons"
call deploy-to-top.bat
if errorlevel 1 exit /b %ERRORLEVEL%
popd

call "%~dp0deploy-to-top.bat"
exit /b %ERRORLEVEL%
