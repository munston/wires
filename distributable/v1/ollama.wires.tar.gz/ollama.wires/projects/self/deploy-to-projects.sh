#!/usr/bin/env sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

(cd "$DIR/garrage" && sh ./deploy-to-projects.sh)
(cd "$DIR/gofur" && sh ./deploy-to-projects.sh)
(cd "$DIR/codfish" && sh ./deploy-to-projects.sh)
(cd "$DIR/wires" && sh ./deploy-to-projects.sh)
