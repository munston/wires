module Buttons where

import Folders.Routes
import Data.List

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--list\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts = []

go :: String -> [String] -> IO String
go "--list" [] = pure (show ["--list"]) 
go "--list" _ = pure "--list expects no arguments"
go option _ = pure ("unknown buttons option: " ++ option)
