if exist "bin" rmdir /s /q "bin"
cabal install all:exes --project-file=cabal.project --installdir=bin --install-method=copy --overwrite-policy=always
if not exist "..\..\..\bin" mkdir "..\..\..\bin"
copy /Y "bin\buttons.exe" "..\..\..\bin\buttons.exe"
