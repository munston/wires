module Main where

import Control.Monad
import Data.Char
import Data.List
import System.Directory
  ( doesDirectoryExist
  , doesFileExist
  , getCurrentDirectory
  , listDirectory
  , makeAbsolute
  , copyFile
  , createDirectoryIfMissing
  , removeFile
  )
import System.Environment
import System.Exit
import System.FilePath
  ( (</>)
  , dropExtension
  , normalise
  , takeDirectory
  , takeExtension
  , takeFileName
  , isAbsolute
  , (<.>)
  )
import System.IO
import System.Info (os)
import System.Process
  ( CreateProcess(..)
  , proc
  , waitForProcess
  , withCreateProcess
  )

data Button =
  Button
    { buttonName :: String
    , buttonPath :: FilePath
    , buttonKind :: String
    }
  deriving (Eq, Show)

main :: IO ()
main = do
  args <- getArgs
  case args of
    ["--clean", target] -> cleanPathOrSequence target
    [target] -> runPathOrSequence target Nothing
    [target, destination] ->
      case validateButtonArgument destination of
        Left message -> do
          putStrLn message
          exitWith (ExitFailure 2)
        Right value -> runPathOrSequence target (Just value)
    _ -> do
      putStrLn usageText
      exitWith (ExitFailure 2)

runPathOrSequence :: FilePath -> Maybe FilePath -> IO ()
runPathOrSequence target destination = do
  isDir <- doesDirectoryExist target
  isFile <- doesFileExist target
  if isDir
    then do
      sequencePath <- ensureDirectoryButtons target
      code <- runSequence sequencePath destination
      exitWith code
    else if not isFile
      then do
        putStrLn ("Path not found: " ++ target)
        exitWith (ExitFailure 1)
      else
        case lowerExtension target of
          ".buttons" -> do
            code <- runSequence target destination
            exitWith code
          ".button" -> do
            code <- runButtonFileResult target destination
            exitWith code
          ".bat" -> do
            code <- runEndpoint target (maybe [] (:[]) destination)
            exitWith code
          ".exe" -> do
            code <- runEndpoint target (maybe [] (:[]) destination)
            exitWith code
          other -> do
            putStrLn ("Unsupported entry type (must be .bat, .exe, .button or .buttons): " ++ other)
            exitWith (ExitFailure 2)

cleanPathOrSequence :: FilePath -> IO ()
cleanPathOrSequence target = do
  isDir <- doesDirectoryExist target
  isFile <- doesFileExist target
  if isDir
    then do
      sequencePath <- ensureDirectoryButtons target
      cleanSequence sequencePath
    else if not isFile
      then do
        putStrLn ("Path not found: " ++ target)
        exitWith (ExitFailure 1)
      else
        case lowerExtension target of
          ".buttons" -> cleanSequence target
          ".button" -> cleanButtonSkip target
          other -> do
            putStrLn ("Unsupported entry type (must be .button or .buttons): " ++ other)
            exitWith (ExitFailure 2)

listButtons :: IO ()
listButtons = do
  buttons <- discoverButtons
  case buttons of
    [] -> putStrLn "No buttons found."
    _ -> mapM_ printButton buttons

runNamedButton :: String -> IO ()
runNamedButton target = do
  directExists <- doesFileExist target
  if directExists
    then exitWith =<< runButtonPath target
    else do
      buttons <- discoverButtons
      case filter (\button -> buttonName button == target || takeFileName (buttonPath button) == target) buttons of
        [] -> do
          putStrLn ("Button not found: " ++ target)
          putStrLn ""
          listButtons
          exitWith (ExitFailure 1)
        button:_ -> exitWith =<< runButtonPath (buttonPath button)

runButtonPath :: FilePath -> IO ExitCode
runButtonPath path = runButtonPathResult path Nothing

runButtonPathResult :: FilePath -> Maybe FilePath -> IO ExitCode
runButtonPathResult path destination =
  case lowerExtension path of
    ".buttons" -> runSequence path destination
    ".button" -> runButtonFileResult path destination
    ".bat" -> runEndpoint path []
    ".exe" -> runEndpoint path []
    other -> do
      putStrLn ("Unsupported button endpoint extension: " ++ other)
      return (ExitFailure 2)

runButtonFile :: FilePath -> IO ()
runButtonFile path = do
  code <- runButtonFileResult path Nothing
  exitWith code

runButtonFileResult :: FilePath -> Maybe FilePath -> IO ExitCode
runButtonFileResult path destination = do
  contents <- readFile path
  case reads contents of
    [((endpoint, argument), rest)] | all (`elem` " \r\n\t") rest -> do
      let finalArgument = applyDestination destination argument
      if null finalArgument
        then do
          putStrLn (".button files must include a non-empty single-argument string.\nUse a .buttons sequence with a direct .bat/.exe line for no-arg entries.")
          return (ExitFailure 1)
        else do
          let dir = takeDirectory path
              candidate = if isAbsolute endpoint then endpoint else normalise (dir </> endpoint)
          exists <- doesFileExist candidate
          if not exists
            then do
              putStrLn ("Button endpoint does not exist: " ++ candidate)
              return (ExitFailure 1)
            else
              case lowerExtension candidate of
                ".bat" -> runEndpoint candidate [finalArgument]
                ".exe" -> runEndpoint candidate [finalArgument]
                "" -> runEndpoint candidate [finalArgument]
                other -> do
                  putStrLn (".button file must name a .bat, .exe, or extensionless executable endpoint, got: " ++ other)
                  return (ExitFailure 2)
    _ -> do
      putStrLn ("Unable to parse .button file as Haskell (String, String): " ++ path)
      return (ExitFailure 1)

ensureDirectoryButtons :: FilePath -> IO FilePath
ensureDirectoryButtons dir = do
  entries <- listDirectory dir
  numbered <- validateNumberedButtons dir entries
  buttonsExe <- getExecutablePath
  sequencePath <- makeAbsolute (dir </> "buttons.buttons")
  let generatedSequence = normalise sequencePath
      buttonNames = map snd numbered
  writeFile generatedSequence (unlines buttonNames)
  writeFile (normalise (dir </> "run.bat")) (runBatText buttonsExe generatedSequence)
  writeFile (normalise (dir </> "clean.bat")) (cleanBatText buttonsExe generatedSequence)
  return generatedSequence

validateNumberedButtons :: FilePath -> [FilePath] -> IO [(Int, FilePath)]
validateNumberedButtons dir entries = do
  let buttonFiles = filter ((== ".button") . lowerExtension) entries
      buttonsFiles = filter ((== ".buttons") . lowerExtension) entries
      parsed = map parseNumberedButton buttonFiles
      badNames = [name | (name, Nothing) <- zip buttonFiles parsed]
  if null buttonFiles
    then failDirectoryButtons dir "No numbered .button files found."
    else if any (/= "buttons.buttons") buttonsFiles || length buttonsFiles > 1
      then failDirectoryButtons dir ("A buttons directory may contain at most one generated .buttons file named buttons.buttons. Found: " ++ show buttonsFiles)
      else if not (null badNames)
        then failDirectoryButtons dir ("Every .button file must start with a contiguous integer prefix like 01-. Bad entries: " ++ show badNames)
        else do
          let numbered = sortOn fst [(n, name) | Just (n, name) <- parsed]
              expected = [1 .. length numbered]
              actual = map fst numbered
          if actual /= expected
            then failDirectoryButtons dir ("Button prefixes must be contiguous starting at 1. Expected " ++ show expected ++ ", got " ++ show actual ++ ".")
            else return numbered

parseNumberedButton :: FilePath -> Maybe (Int, FilePath)
parseNumberedButton name =
  let (digits, rest) = span isDigit name
  in case rest of
       '-':_ | not (null digits) -> Just (read digits, name)
       _ -> Nothing

failDirectoryButtons :: FilePath -> String -> IO a
failDirectoryButtons dir message = do
  putStrLn ("Invalid buttons directory: " ++ normalise dir)
  putStrLn message
  exitWith (ExitFailure 2)

runBatText :: FilePath -> FilePath -> String
runBatText buttonsExe sequencePath =
  unlines
    [ "@echo off"
    , "setlocal"
    , "if \"%~1\"==\"\" ("
    , "  \"" ++ buttonsExe ++ "\" \"" ++ sequencePath ++ "\""
    , ") else ("
    , "  \"" ++ buttonsExe ++ "\" \"" ++ sequencePath ++ "\" \"%~1\""
    , ")"
    , "exit /b %ERRORLEVEL%"
    ]

cleanBatText :: FilePath -> FilePath -> String
cleanBatText buttonsExe sequencePath =
  unlines
    [ "@echo off"
    , "setlocal"
    , "\"" ++ buttonsExe ++ "\" --clean \"" ++ sequencePath ++ "\""
    , "exit /b %ERRORLEVEL%"
    ]

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile (`elem` " \r\n\t")

discoverButtons :: IO [Button]
discoverButtons = do
  currentDir <- getCurrentDirectory
  roots <- filterM doesDirectoryExist [currentDir </> "buttons", currentDir </> ".buttons", currentDir </> "scripts"]
  concat <$> mapM discoverButtonsIn roots

discoverButtonsIn :: FilePath -> IO [Button]
discoverButtonsIn root = do
  entries <- listDirectory root
  fmap concat $
    mapM
      (\entry -> do
        let path = root </> entry
        isDir <- doesDirectoryExist path
        isFile <- doesFileExist path
        if isDir
          then discoverButtonsIn path
          else
            if isFile && lowerExtension path `elem` [".bat", ".exe", ".button", ".buttons"]
              then pure [Button (dropExtension entry) (normalise path) (drop 1 (lowerExtension path))]
              else pure [])
      entries

runSequence :: FilePath -> Maybe FilePath -> IO ExitCode
runSequence path destination = do
  putStrLn ("sequence: " ++ normalise path)
  hFlush stdout
  prepareStageSequence path destination
  contents <- readFile path
  let ls = filter (not . ignoredSequenceLine) $ map trim (lines contents)
      dir = takeDirectory path
  code <- runLines ls dir destination
  case code of
    ExitSuccess -> finalizeStageSequence path destination
    _ -> return ()
  return code

runLines :: [String] -> FilePath -> Maybe FilePath -> IO ExitCode
runLines [] _ _ = return ExitSuccess
runLines (l:ls) dir destination = do
  case parseInlineEndpoint l of
    Just (endpoint, argument) -> do
      let candidate = if isAbsolute endpoint then endpoint else normalise (dir </> endpoint)
          finalArgument = applyDestination destination argument
      exists <- doesFileExist candidate
      if not exists
        then do
          putStrLn ("Inline endpoint not found in sequence: " ++ candidate)
          return (ExitFailure 1)
        else do
          putStrLn ("running-inline: " ++ candidate ++ " " ++ finalArgument)
          hFlush stdout
          code <- runInlineEndpoint candidate finalArgument
          case code of
            ExitSuccess -> do
              putStrLn ("completed-inline: " ++ candidate)
              hFlush stdout
              runLines ls dir destination
            _ -> do
              putStrLn ("failed-inline: " ++ candidate ++ " (" ++ show code ++ ")")
              hFlush stdout
              return code
    Nothing -> do
      let candidate = if isAbsolute l then l else normalise (dir </> l)
      exists <- doesFileExist candidate
      if not exists
        then do
          putStrLn ("Entry not found in sequence: " ++ candidate)
          return (ExitFailure 1)
        else do
          shouldSkip <- doesFileExist (skipPath candidate)
          if shouldSkip
            then do
              putStrLn ("skipped: " ++ candidate)
              hFlush stdout
              runLines ls dir destination
            else do
              putStrLn ("running: " ++ candidate)
              hFlush stdout
              code <- runButtonPathResult candidate destination
              case code of
                ExitSuccess -> do
                  putStrLn ("completed: " ++ candidate)
                  marked <- markSkip candidate
                  if marked
                    then putStrLn ("marked-skip: " ++ skipPath candidate)
                    else return ()
                  hFlush stdout
                  runLines ls dir destination
                _ -> do
                  putStrLn ("failed: " ++ candidate ++ " (" ++ show code ++ ")")
                  hFlush stdout
                  return code

runInlineEndpoint :: FilePath -> String -> IO ExitCode
runInlineEndpoint candidate argument =
  case lowerExtension candidate of
    ".buttons" -> runButtonPathResult candidate (argumentDestination argument)
    ".button" -> runButtonPathResult candidate (argumentDestination argument)
    ".bat" -> runEndpoint candidate (argumentList argument)
    ".exe" -> runEndpoint candidate (argumentList argument)
    "" -> runEndpoint candidate (argumentList argument)
    other -> do
      putStrLn ("Unsupported inline endpoint extension: " ++ other)
      return (ExitFailure 2)

argumentDestination :: String -> Maybe FilePath
argumentDestination "" = Nothing
argumentDestination value = Just value

splitArguments :: String -> [String]
splitArguments input = go (dropWhile isSpace input) []
  where
    go :: String -> [String] -> [String]
    go [] acc = reverse acc
    go s acc =
      let (arg, rest) = parseArg s
      in go (dropWhile isSpace rest) (arg : acc)

    parseArg :: String -> (String, String)
    parseArg ('"':xs) = parseQuoted xs ""
    parseArg xs       = parseUnquoted xs ""

    parseUnquoted :: String -> String -> (String, String)
    parseUnquoted [] acc = (reverse acc, [])
    parseUnquoted (c:cs) acc
      | isSpace c = (reverse acc, cs)
      | otherwise = parseUnquoted cs (c:acc)

    parseQuoted :: String -> String -> (String, String)
    parseQuoted [] acc = (reverse acc, [])
    parseQuoted ('"':cs) acc = (reverse acc, cs)
    parseQuoted ('\\':'"':cs) acc = parseQuoted cs ('"':acc)
    parseQuoted (c:cs) acc = parseQuoted cs (c:acc)

argumentList :: String -> [String]
argumentList = splitArguments

parseInlineEndpoint :: String -> Maybe (FilePath, String)
parseInlineEndpoint line =
  case reads line of
    [((endpoint, argument), rest)] | all (`elem` " \r\n\t") rest -> Just (endpoint, argument)
    _ -> Nothing

applyDestination :: Maybe FilePath -> String -> String
applyDestination Nothing argument = argument
applyDestination (Just destination) argument =
  replaceAll "{{destination}}" destination argument

replaceAll :: String -> String -> String -> String
replaceAll needle replacement value
  | null needle = value
  | otherwise =
      case splitPrefix needle value of
        Just rest -> replacement ++ replaceAll needle replacement rest
        Nothing ->
          case value of
            [] -> []
            c:cs -> c : replaceAll needle replacement cs

splitPrefix :: String -> String -> Maybe String
splitPrefix [] rest = Just rest
splitPrefix (_:_) [] = Nothing
splitPrefix (p:ps) (x:xs)
  | p == x = splitPrefix ps xs
  | otherwise = Nothing

validateButtonArgument :: FilePath -> Either String FilePath
validateButtonArgument value
  | null value = Left "Button argument must not be empty."
  | value `elem` knownModeArguments = Right value
  | any (`elem` "\r\n\"<>|?*") value = Left ("Button argument contains unsupported characters: " ++ value)
  | take 1 value == "-" = Left ("Button argument must not look like an unsupported option: " ++ value)
  | otherwise = Right value

knownModeArguments :: [String]
knownModeArguments =
  [ "--bootstrap-only"
  , "--dont-exclude-bootstrap"
  ]

prepareStageSequence :: FilePath -> Maybe FilePath -> IO ()
prepareStageSequence path destination =
  case stageGeneratorFor path of
    Nothing -> return ()
    Just exeName -> do
      let root = takeDirectory (takeDirectory path)
          exePath = normalise (root </> "bin" </> exeName)
          args =
            case destination of
              Just mode | mode `elem` knownModeArguments -> ["--generate-buttons", root, mode]
              _ -> ["--generate-buttons", root]
      exists <- doesFileExist exePath
      if exists
        then do
          code <- runEndpoint exePath args
          case code of
            ExitSuccess -> return ()
            _ -> exitWith code
        else return ()

stageGeneratorFor :: FilePath -> Maybe FilePath
stageGeneratorFor path =
  let dirName = takeFileName (takeDirectory path)
      fileName = takeFileName path
  in case (dirName, fileName) of
       (".build", "build.buttons") -> Just (toolExe "garrage")
       (".install", "install.buttons") -> Just (toolExe "gofur")
       (".test", "test.buttons") -> Just (toolExe "wires")
       (".document", "document.buttons") -> Just (toolExe "codfish")
       _ -> Nothing

finalizeStageSequence :: FilePath -> Maybe FilePath -> IO ()
finalizeStageSequence path destination =
  case (takeFileName (takeDirectory path), takeFileName path, destination) of
    (".install", "install.buttons", Just "--bootstrap-only") ->
      provisionBootstrapTools (takeDirectory (takeDirectory path))
    _ -> return ()

provisionBootstrapTools :: FilePath -> IO ()
provisionBootstrapTools root = do
  let binDir = root </> "bin"
      copies =
        [ ("projects" </> "garrage" </> "src" </> "garrage" </> "bin" </> toolExe "garrage", toolExe "garrage")
        , ("projects" </> "gofur" </> "src" </> "gofur" </> "bin" </> toolExe "gofur", toolExe "gofur")
        , ("projects" </> "codfish" </> "src" </> "codfish" </> "bin" </> toolExe "codfish", toolExe "codfish")
        , ("projects" </> "self" </> "wires" </> "bin" </> toolExe "wires", toolExe "wires")
        ]
  createDirectoryIfMissing True binDir
  mapM_ copyTool copies
  where
    copyTool (sourceRelative, targetName) = do
      let source = root </> sourceRelative
          target = root </> "bin" </> targetName
      exists <- doesFileExist source
      if exists
        then do
          copyFile source target
          putStrLn ("provisioned: " ++ normalise target)
          hFlush stdout
        else do
          putStrLn ("missing bootstrap tool: " ++ normalise source)
          exitWith (ExitFailure 1)

skipPath :: FilePath -> FilePath
skipPath path = path ++ ".skip"

toolExe :: String -> FilePath
toolExe name =
  if os == "mingw32" then name <.> "exe" else name

markSkip :: FilePath -> IO Bool
markSkip path =
  case lowerExtension path of
    ".button" -> writeFile (skipPath path) "completed\n" >> return True
    _ -> return False

cleanSequence :: FilePath -> IO ()
cleanSequence path = do
  putStrLn ("clean-sequence: " ++ normalise path)
  hFlush stdout
  contents <- readFile path
  let ls = filter (not . ignoredSequenceLine) $ map trim (lines contents)
      dir = takeDirectory path
  mapM_ (cleanSequenceEntry dir) ls

cleanSequenceEntry :: FilePath -> String -> IO ()
cleanSequenceEntry dir line =
  case parseInlineEndpoint line of
    Just _ -> return ()
    Nothing -> do
      let candidate = if isAbsolute line then line else normalise (dir </> line)
      case lowerExtension candidate of
        ".buttons" -> cleanSequence candidate
        _ -> cleanButtonSkip candidate

cleanButtonSkip :: FilePath -> IO ()
cleanButtonSkip path = do
  let marker = skipPath path
  exists <- doesFileExist marker
  if exists
    then do
      removeFile marker
      putStrLn ("removed-skip: " ++ marker)
      hFlush stdout
    else do
      putStrLn ("missing-skip: " ++ marker)
      hFlush stdout

ignoredSequenceLine :: String -> Bool
ignoredSequenceLine value =
  null value || take 1 value == "#"

printButton :: Button -> IO ()
printButton button =
  putStrLn (buttonName button ++ " [" ++ buttonKind button ++ "] " ++ buttonPath button)

lowerExtension :: FilePath -> String
lowerExtension path = map lowerAscii (takeExtension path)

lowerAscii :: Char -> Char
lowerAscii char
  | char >= 'A' && char <= 'Z' = toEnum (fromEnum char + 32)
  | otherwise = char

runEndpoint :: FilePath -> [String] -> IO ExitCode
runEndpoint endpoint args = do
  absoluteEndpoint <- makeAbsolute endpoint
  withCreateProcess (proc absoluteEndpoint args) { cwd = Just (takeDirectory absoluteEndpoint) } $ \_ _ _ processHandle ->
    waitForProcess processHandle

usageText :: String
usageText =
  unlines
    [ "buttons"
    , "buttons --clean <path.to/.buttons-or-.button>"
    , "buttons <path.to/.buttons-or-.button>"
    , "buttons <path.to/.buttons-or-.button> <destination-filepath>"
    , ""
    , "Invokes a directory, .buttons file (newline-separated endpoint list), or .button file."
    , ".buttons lines may also be inline endpoint pairs: (\"path/to/tool.exe\", \"single argument string\")."
    , "When an argument is supplied, {{destination}} in button arguments is replaced with it."
    , "Known mode arguments such as --bootstrap-only retarget generated root stage .buttons before they run."
    , "Directory targets must contain contiguous numbered .button files starting at 1, e.g. 01-name.button."
    , "Directory targets generate buttons.buttons, run.bat, and clean.bat before running."
    , "--clean removes sibling .button.skip markers without running entries."
    , ".button files contain a Haskell show/read (String, String) pair: (endpoint, argument)."
    , "Endpoints may be .bat, .exe, or extensionless executables such as /bin/bash."
    , "A .button is skipped when a sibling .button.skip marker exists."
    , "Successful .button entries in a .buttons sequence create their .button.skip marker."
    ]
