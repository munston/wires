module Garrage.Descriptor where

import Data.List
import System.FilePath

data GoTarget =
  GoTarget
    { goTargetModule :: String
    , goTargetFunction :: String
    }
  deriving (Eq, Show)

data NutDescriptor =
  NutDescriptor
    { nutDescriptorName :: String
    , nutDescriptorDepends :: [String]
    , nutDescriptorExposes :: [String]
    , nutDescriptorGoIs :: Maybe String
    }
  deriving (Eq, Show)

parseNutDescriptor :: String -> NutDescriptor
parseNutDescriptor text =
  NutDescriptor
    { nutDescriptorName = maybe "unknown" id (parseField "name:" text)
    , nutDescriptorDepends = parseIndentedList "depends:" text
    , nutDescriptorExposes = parseIndentedList "exposes:" text
    , nutDescriptorGoIs = parseField "go-is:" text
    }

renderNutDescriptor :: NutDescriptor -> String
renderNutDescriptor descriptor =
  unlines
    ( [ "name: " ++ nutDescriptorName descriptor
      , "depends:"
      ]
    ++ map ("  " ++) (nutDescriptorDepends descriptor)
    ++ [ "exposes:" ]
    ++ map ("  " ++) (nutDescriptorExposes descriptor)
    ++ maybeField "go-is" (nutDescriptorGoIs descriptor)
    )

renderGarrageDescriptor :: NutDescriptor -> String
renderGarrageDescriptor descriptor =
  unlines
    ( [ "name: " ++ nutDescriptorName descriptor
      , "depends:"
      ]
    ++ map ("  " ++) (nutDescriptorDepends descriptor)
    ++ [ "exposes:" ]
    ++ map ("  " ++) (nutDescriptorExposes descriptor)
    ++ maybeField "garrage-is" (nutDescriptorGoIs descriptor)
    )

ensureNutExpose :: String -> String -> String
ensureNutExpose moduleName nutText =
  let descriptor = parseNutDescriptor nutText
      exposed = nutDescriptorExposes descriptor
  in if moduleName `elem` exposed
       then nutText
       else renderNutDescriptor descriptor { nutDescriptorExposes = exposed ++ [moduleName] }

garrageToNut :: String -> String
garrageToNut gtext =
  unlines
    [ if "garrage-is:" `isPrefixOf` trim row
        then "go-is: " ++ trim (drop (length "garrage-is:") row)
        else row
    | row <- lines gtext
    ]

parseField :: String -> String -> Maybe String
parseField key text =
  case [trim (drop (length key) line) | line <- lines text, key `isPrefixOf` trim line] of
    value:_ | not (null value) -> Just value
    _ -> Nothing

parseIndentedList :: String -> String -> [String]
parseIndentedList key text =
  let rest = dropWhile (not . isSection key) (lines text)
  in case rest of
       [] -> []
       _:items -> map trimListItem (takeWhile isListItem items)

splitGoTarget :: String -> GoTarget
splitGoTarget target =
  let reversed = reverse target
  in case break (== '.') reversed of
       (_, []) -> GoTarget target ""
       (functionName, '.':moduleName) -> GoTarget (reverse moduleName) (reverse functionName)
       _ -> GoTarget target ""

moduleFilePath :: String -> FilePath
moduleFilePath moduleName =
  foldr (</>) "" (splitOnDot moduleName) <.> "hs"

cabalPackageName :: String -> String
cabalPackageName =
  map replaceUnderscore

checkFunctionExists :: String -> String -> Bool
checkFunctionExists text functionName =
  any (`isInfixOf` text) [functionName ++ " ::", functionName ++ " "]

maybeField :: String -> Maybe String -> [String]
maybeField _ Nothing = []
maybeField key (Just value) = [key ++ ": " ++ value]

isSection :: String -> String -> Bool
isSection key line =
  key `isPrefixOf` trim line

isListItem :: String -> Bool
isListItem line =
  let value = trim line
  in not (null value) && (head line == ' ' || "- " `isPrefixOf` value)

trimListItem :: String -> String
trimListItem line =
  let value = trim line
  in if "- " `isPrefixOf` value
       then trim (drop 2 value)
       else value

splitOnDot :: String -> [String]
splitOnDot value =
  case break (== '.') value of
    (left, []) -> [left]
    (left, _:right) -> left : splitOnDot right

replaceUnderscore :: Char -> Char
replaceUnderscore char
  | char == '_' = '-'
  | otherwise = char

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile (`elem` [' ', '\n', '\r', '\t'])
