module Garrage where

import System.FilePath
import System.Directory
import Data.Char (isSpace)
import qualified Data.List as List
import Control.Monad
import System.Process (rawSystem)
import System.Exit (ExitCode(..))
import System.Info (os)

import Folders.Shape
import qualified Folders.Project as FP
import Folders.Routes
import qualified Garrage.Descriptor as Descriptor
import qualified Garrage.Buttons as GButtons
import qualified Garrage.Verification as Verification
 

-- | Create a sample 'hello' project at the given workspace root.
-- The project will be created under root/projects/<projectName>.
createHelloProject :: FilePath -> String -> String -> IO ()
createHelloProject root projectName packageName =
  createProjectFromProjectTree root (mkSampleProjectTree projectName packageName)

-- | Construct a minimal ProjectTree for a hello project.
mkSampleProjectTree :: String -> String -> ProjectTree
mkSampleProjectTree projectName packageName =
  ProjectTree
    { projectTreeName = projectName
    , projectTreePackages = [PackageTree packageName [] samplePackageFiles]
    , projectTreeFolders = []
    , projectTreeFiles = []
    }
  where
    moduleName = FP.projectModuleName packageName
    -- Do not auto-generate a package.garrage inside the package; instead
    -- prefer a project-level descriptor (cabal.project). Generating
    -- package.garrage here produced duplicate/false package prefixes.
    samplePackageFiles =
      [ TypedFile Garrage "package.garrage"
      , TypedFile Hs ("lib" </> moduleName ++ ".hs")
      ]

-- | Library-only variant: do not generate exe/test/cog runtime test artifacts.
mkSampleLibraryProjectTree :: String -> String -> ProjectTree
mkSampleLibraryProjectTree projectName packageName =
  ProjectTree
    { projectTreeName = projectName
    , projectTreePackages = [PackageTree packageName [] libraryPackageFiles]
    , projectTreeFolders = []
    , projectTreeFiles = []
    }
  where
    -- keep metadata needed for packaging but omit runtime/test code
    moduleName = FP.projectModuleName packageName
    -- Library projects also omit package.garrage to avoid creating
    -- stray package descriptors under `src/<pkg>`.
    libraryPackageFiles =
      [ TypedFile Garrage "package.garrage"
      , TypedFile Hs ("lib" </> moduleName ++ ".hs")
      ]

-- | Write a ProjectTree into the filesystem. Creates directories and files
-- under root/projects/<projectName> according to the ProjectTree.
createProjectFromProjectTree :: FilePath -> ProjectTree -> IO ()
createProjectFromProjectTree workspaceRoot projectTree = do
  let projectsRoot = workspaceRoot </> "projects"
      projectDir = projectsRoot </> projectTreeName projectTree
  createDirectoryIfMissing True projectDir
  -- write a minimal `cabal.project` so the created project is
  -- recognized as a first-class workspace entry by downstream tools
  -- (allows tools that expect a project-level file to operate).
  let cabalProjectContent = unlines
        [ "-- generated-by: garrage create"
        , "packages:"
        , "  src/" ++ projectTreeName projectTree
        , "  ../self/folders/src/folders"
        , "  ../self/wires"
        , "  ../gofur"
        ]
  writeFile (projectDir </> "cabal.project") cabalProjectContent

  -- write any top-level project files (none in the sample)
  forM_ (projectTreeFiles projectTree) $ \tf -> writeTypedFile projectDir "" tf

  -- ensure src/ exists and write packages
  let srcRoot = projectDir </> "src"
  createDirectoryIfMissing True srcRoot
  forM_ (projectTreePackages projectTree) $ \pkg -> do
    writePackageFromPackageTree workspaceRoot srcRoot (projectTreeName projectTree) pkg
    -- Do not copy package-level descriptors from `src/<pkg>` up to the
    -- project root. Copying introduced duplicate descriptors and false
    -- package prefixes; prefer creating a project-level `cabal.project`
    -- (done above) or running an explicit conversion step when needed.

  -- write any extra folders
  forM_ (projectTreeFolders projectTree) $ \ft -> writeFolderTree projectDir ft
  forM_ (projectTreePackages projectTree) $ \pkg ->
    ensureRootProjectEntry workspaceRoot (projectTreeName projectTree) (packageTreeName pkg)

-- | Write a package directory from a PackageTree under a given src root.
writePackageFromPackageTree :: FilePath -> FilePath -> String -> PackageTree -> IO ()
writePackageFromPackageTree _workspaceRoot srcRoot _projectName pkg = do
  let pkgDir = srcRoot </> packageTreeName pkg
  createDirectoryIfMissing True pkgDir

  -- create nested folders inside the package
  forM_ (packageTreeFolders pkg) $ \ft -> writeFolderTree pkgDir ft

  -- write declared files
  forM_ (packageTreeFiles pkg) $ \tf -> writeTypedFile pkgDir (packageTreeName pkg) tf

  return ()

ensureRootProjectEntry :: FilePath -> String -> String -> IO ()
ensureRootProjectEntry workspaceRoot projectName packageName = do
  let packageRelative = projectName ++ "/src/" ++ packageName
  -- Delegate to the canonical registration logic in Folders
  _ <- FP.registerPackage workspaceRoot packageRelative
  return ()

-- | Write a FolderTree into the filesystem under the given base path.
writeFolderTree :: FilePath -> FolderTree -> IO ()
writeFolderTree base tree = do
  let dir = base </> folderTreeName tree
  createDirectoryIfMissing True dir
  forM_ (folderTreeFiles tree) $ \tf -> writeTypedFile dir "" tf
  forM_ (folderTreeFolders tree) $ \child -> writeFolderTree dir child

-- | Create a file for a TypedFile at the requested base directory.
-- The 'owner' parameter may be the package name and is used to fill template contents.
writeTypedFile :: FilePath -> String -> TypedFile -> IO ()
writeTypedFile base owner (TypedFile ftype fpath) = do
  let full = base </> fpath
      dir = takeDirectory full
  createDirectoryIfMissing True dir
  doesExist <- doesFileExist full
  if doesExist
      then return ()
      else writeFile full (contentFor owner ftype fpath)

-- | Basic templated content for common filetypes in our sample hello project.
contentFor :: String -> Filetype -> FilePath -> String
contentFor owner ftype fpath =
  case ftype of
    Hs -> hsContent owner fpath
    Nut -> nutContent owner
    Garrage -> garrageContent owner
    Bolt -> boltContent owner
    Cog -> cogContent owner
    Cabal -> "-- cabal file\n"
    Txt -> ""
    Md -> ""
    Json -> "{}\n"
    Wire -> ""
    Bat -> ""
    _ -> ""

hsContent :: String -> FilePath -> String
hsContent owner fpath
  | "Main.hs" `List.isSuffixOf` fpath = unlines
      [ "module Main where"
      , "import System.Environment"
      , "import qualified Lib"
      , ""
      , "main :: IO ()"
      , "main = getArgs >>= dispatch . normalizeArgs"
      , ""
      , "normalizeArgs :: [String] -> [String]"
      , "normalizeArgs [single] = words single"
      , "normalizeArgs args = args"
      , ""
      , "dispatch :: [String] -> IO ()"
      , "dispatch (option : args) = Lib.go option args >>= print >> return ()"
      , "dispatch [] = fail \"missing go option\""
      ]
  | "Test.hs" `List.isSuffixOf` fpath = unlines
      [ "module TestMain where"
      , "import Lib (hello)"
      , "main :: IO ()"
      , "main = putStrLn (\"TEST: \" ++ hello)"
      ]
  | otherwise = -- library module
    let modName = moduleNameFromPath fpath
        precog = "\\s -> \"--list\" `isInfixOf` s"
    in unlines
      [ "module " ++ modName ++ " where"
      , ""
      , "import Folders.Routes"
      , ""
      , "verifiedRoutes :: [VerifiedRoute]"
      , "verifiedRoutes ="
          , "  [ VerifiedRoute { routeOption = \"--list\", routeArgs = [], routePrecog = " ++ show precog ++ " }"
      , "  ]"
      , ""
      , "routeOptouts :: [RouteOptout]"
      , "routeOptouts ="
      , "  []"
      , ""
      , "go :: String -> [String] -> IO String"
          , "go \"--list\" [] = pure (show [\"--list\"])"
          , "go \"--list\" _ = pure \"--list expects no arguments\""
      , "go option _ = pure (\"unknown " ++ owner ++ " option: \" ++ option)"
      ]

moduleNameFromPath :: FilePath -> String
moduleNameFromPath path =
  let base = takeFileName path
      name = List.takeWhile (/= '.') base
  in if name == "Lib" then "Lib" else name

nutContent :: String -> String
nutContent owner =
  let moduleName = FP.projectModuleName owner
  in unlines
    [ "name: " ++ owner
    , "depends:"
    , "  folders"
    , "exposes:" 
    , "  " ++ moduleName
    , "go-is: " ++ moduleName ++ ".go"
    ]

garrageContent :: String -> String
garrageContent owner =
  let moduleName = FP.projectModuleName owner
  in unlines
    [ "name: " ++ owner
    , "depends:"
    , "  folders"
    , "exposes:" 
    , "  " ++ moduleName
    , "garrage-is: " ++ moduleName ++ ".go"
    ]

boltContent :: String -> String
boltContent _ = unlines
  [ "depends:" 
  , "options:" 
  ]

cogContent :: String -> String
cogContent _ = unlines
  [ "test-suite: test"
  , "type: exitcode-stdio-1.0"
  , "main-is: test/Test.hs"
  , "source-dirs: test"
  , "depends:" 
  ]

-- | Convert a package.garrage text into a package.nut text by mapping
-- the `garrage-is:` field to `go-is:` while preserving other fields.
garrageToNut :: String -> String
garrageToNut =
  Descriptor.garrageToNut

-- | Read an existing directory tree into a FolderTree value.
readFolderTree :: FilePath -> IO FolderTree
readFolderTree path = do
  exists <- doesDirectoryExist path
  if not exists
    then return (FolderTree path [] [])
    else do
      entries <- listDirectory path
      let visible = filter (not . List.isPrefixOf ".") entries
      dirs <- filterM' (doesDirectoryExist . (path </>)) visible
      files <- filterM' (doesFileExist . (path </>)) visible
      childTrees <- forM dirs $ \d -> readFolderTree (path </> d)
      typedFiles <- forM files $ \f -> do
        let ft = extToFiletype f
        return (TypedFile ft f)
      return (FolderTree (takeFileName path) childTrees typedFiles)

filterM' :: Monad m => (a -> m Bool) -> [a] -> m [a]
filterM' p xs = foldr step (return []) xs
  where
    step x r = do
      b <- p x
      rs <- r
      return (if b then x:rs else rs)

extToFiletype :: FilePath -> Filetype
extToFiletype f =
  case takeExtension f of
    ".hs" -> Hs
    ".nut" -> Nut
    ".garrage" -> Garrage
    ".bolt" -> Bolt
    ".cog" -> Cog
    ".cabal" -> Cabal
    ".wire" -> Wire
    ".bat" -> Bat
    ".txt" -> Txt
    ".md" -> Md
    ".json" -> Json
    ".plan" -> Plan
    _ -> Txt

-- | Create a library-only hello project.
createHelloLibraryProject :: FilePath -> String -> String -> IO ()
createHelloLibraryProject root projectName packageName =
  createProjectFromProjectTree root (mkSampleLibraryProjectTree projectName packageName)

-- | Canonical project creation wrapper that delegates to the
-- central `folders` backend. This matches the `Wires`-style
-- creation API: `createHelloProject root projectName`.
createProject :: FilePath -> String -> IO String
createProject root projectName =
  createHelloProjectCanonical root projectName

createHelloProjectCanonical :: FilePath -> FilePath -> IO String
createHelloProjectCanonical root projectName = do
  -- Use Garrage's ProjectTree creation so garrage controls the
  -- exact hello-source layout. Delegate to our tree writer.
  createProjectFromProjectTree root (mkSampleProjectTree projectName projectName)
  return ("garrage created project: " ++ projectName)

-- | Unregister and remove a project. Performs conservative checks
-- then delegates to `Folders.removeProject`. This function does not
-- create snapshots; callers must snapshot before calling.
unregisterProject :: FilePath -> String -> IO String
unregisterProject root projectName = do
  -- Simple semantic check: ensure project directory exists
  let projectRoot = root </> "projects" </> projectName
  exists <- doesDirectoryExist projectRoot
  if not exists
    then return ("project not found: " ++ projectRoot)
    else FP.removeProject root projectName

-- | Read a folder tree but filter out runtime/test folders used by Wires
-- (e.g. `exe`, `cog`, `test`) for a gofur-oriented view.
readFolderTreeGofur :: FilePath -> IO FolderTree
readFolderTreeGofur path = do
  tree <- readFolderTree path
  return (filterFolderTree tree)


filterFolderTree :: FolderTree -> FolderTree
filterFolderTree (FolderTree name folders files) =
  let blockedDirs = ["exe", "cog", "test", ".buttons"]
      blockedFiles = ["CogMain.hs"]
      keptFolders = map filterFolderTree $ filter (\f -> folderTreeName f `notElem` blockedDirs) folders
      keptFiles = filter (\tf -> let fn = takeFileName (typedFilePath tf) in fn `notElem` blockedFiles) files
  in FolderTree name keptFolders keptFiles

-- Minimal runtime hooks so `garrage` can serve as a go-is target itself.
verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--list\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--garrage", routeArgs = [], routePrecog = "\\s -> s == \"garrage ok\"" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts =
  [ RouteOptout { routeOptoutOption = "--generate-buttons", routeOptoutReason = "generates build-stage buttons before the buttonized phase runs" }
  , RouteOptout { routeOptoutOption = "create", routeOptoutReason = "create a minimal hello-style project via folders" }
  ]

go :: String -> [String] -> IO String
go "--list" [] = pure (show ["--list", "--garrage", "create", "build"])
go "--list" _ = pure "--list expects no arguments"
go "--garrage" [] = pure "garrage ok"
go "--garrage" _ = pure "garrage expects no arguments"
go "--generate-buttons" [root] = generateGarrageButtons root
go "--generate-buttons" [root, mode] = generateGarrageButtonsWithMode root mode
go "--generate-buttons" _ = pure "garrage --generate-buttons <root> [--dont-exclude-bootstrap|--bootstrap-only]"
go "create" [root, projectName] = createProject root projectName
go "create" _ = pure "usage: garrage create <root> <projectName>"
go "--build" [root, packageRelative] = buildPackage root packageRelative
go "--build" _ = pure "usage: garrage --build <root> <packageRelative>"
go "build" [root, packageRelative] = buildPackage root packageRelative
go "build" _ = pure "usage: garrage build <root> <packageRelative>"
go "unregister" [root, projectName] = unregisterProject root projectName
go "unregister" _ = pure "usage: garrage unregister <root> <projectName>   (legacy)"
go "--unregister" [root, projectName] = unregisterProject root projectName
go "--unregister" _ = pure "usage: garrage.exe --unregister <root> <projectName>   (legacy)"

go "unregister-package" [root, pkgRel] = FP.unregisterPackage root pkgRel
go "unregister-package" _ = pure "usage: garrage unregister-package <root> <package-relative>"
go "--unregister-package" [root, pkgRel] = FP.unregisterPackage root pkgRel
go "--unregister-package" _ = pure "usage: garrage.exe --unregister-package <root> <package-relative>"

go "remove-top-level" [root, top] = FP.removeTopLevelProject root top
go "remove-top-level" _ = pure "usage: garrage remove-top-level <root> <top-level-name>"
go "--remove-top-level" [root, top] = FP.removeTopLevelProject root top
go "--remove-top-level" _ = pure "usage: garrage.exe --remove-top-level <root> <top-level-name>"
go option _ = pure ("unknown garrage option: " ++ option)

-- | Stage API: materialise a `package.nut` from `package.garrage`.
-- This is the canonical Garrage-owned advance operation: it reads
-- `package.garrage` (if present) and writes an idempotent
-- `package.nut` using the `Garrage.garrageToNut` transformation.
advanceToNut :: FilePath -> FilePath -> IO String
advanceToNut root packageRelative = do
  let packageDir = root </> "projects" </> normalise packageRelative
      garragePath = packageDir </> "package.garrage"
      nutPath = packageDir </> "package.nut"
  garrageExists <- doesFileExist garragePath
  if not garrageExists
    then return ("garrage advance skipped " ++ packageRelative ++ ": no package.garrage")
    else do
      garrageText <- readFileStrict garragePath
      writeFile nutPath (garrageToNut garrageText)
      return ("garrage advance wrote package.nut for " ++ packageRelative)


-- | Generate the garrage build-stage buttons for the workspace.
generateGarrageButtons :: FilePath -> IO String
generateGarrageButtons workspaceRoot =
  generateGarrageButtonsFor workspaceRoot regularOnly

generateGarrageButtonsWithMode :: FilePath -> String -> IO String
generateGarrageButtonsWithMode workspaceRoot mode =
  case parsePackageSelection mode of
    Just selection -> generateGarrageButtonsFor workspaceRoot selection
    Nothing -> return ("unknown package selection: " ++ mode)

generateGarrageButtonsFor :: FilePath -> PackageSelection -> IO String
generateGarrageButtonsFor workspaceRoot selection = do
  absoluteRoot <- makeAbsolute workspaceRoot
  let projectsRoot = absoluteRoot </> "projects"
      buildDirRoot = absoluteRoot </> ".build"
  exists <- doesDirectoryExist projectsRoot
  if not exists
    then do
      GButtons.writeButtons (buildDirRoot </> "build.buttons") []
      return "generated garrage build buttons: no projects found"
    else do
      packagePaths <- readProjectPackagesWithSelection selection absoluteRoot
      buildSequences <- forM packagePaths $ \packageRelative -> do
        let pkgDir = projectsRoot </> packageRelative
            buttonsDir = pkgDir </> ".buttons"
            sequencePath = buttonsDir </> "build.buttons"
            endpoint = normalise (makeRelative buttonsDir (absoluteRoot </> "bin" </> toolExe "garrage"))
        current <- Verification.isStageCurrent absoluteRoot packageRelative "build.stamp"
        if current then return () else removeStageSkips buttonsDir "build"
        GButtons.writeButton buttonsDir "build-00-cabal-build.button" endpoint (unwords ["--build", "..", packageRelative])
        GButtons.writeButtons sequencePath ["build-00-cabal-build.button"]
        return (normalise (makeRelative buildDirRoot sequencePath))
      GButtons.writeButtons (buildDirRoot </> "build.buttons") buildSequences
      return ("generated garrage build buttons\npackages: " ++ show (length packagePaths))

toolExe :: String -> FilePath
toolExe name =
  if os == "mingw32" then name <.> "exe" else name

-- | Actual implementation for the "build" command.
-- Runs cabal build for the given package from the workspace project root.
buildPackage :: FilePath -> FilePath -> IO String
buildPackage root packageRelative = do
  let packageDir = root </> "projects" </> normalise packageRelative
      projectsRoot = root </> "projects"
  cabalFile <- findPackageCabalFile packageDir
  case cabalFile of
    Nothing -> error ("build failed for package: " ++ packageRelative ++ " (no .cabal file)")
    Just cabalPath -> do
      cabalText <- readFileStrict cabalPath
      let packageTarget = cabalPackageNameFromText cabalText (takeBaseName cabalPath)
      exitCode <- withCurrentDirectory projectsRoot $
        rawSystem "cabal" ["v2-build", packageTarget]
      case exitCode of
        ExitSuccess -> do
          stampMsg <- Verification.recordStage root packageRelative "build.stamp"
          return ("built package: " ++ packageRelative ++ "\n" ++ stampMsg)
        _           -> error ("build failed for package: " ++ packageRelative ++ " (target: " ++ packageTarget ++ ")")

readProjectPackages :: FilePath -> IO [FilePath]
readProjectPackages =
  readProjectPackagesWithSelection (includeBootstrap False)

readProjectPackagesWithSelection :: PackageSelection -> FilePath -> IO [FilePath]
readProjectPackagesWithSelection selection root = do
  let projectFile = root </> "projects" </> "wire.project"
  exists <- doesFileExist projectFile
  if not exists
    then return []
    else do
      text <- readFile projectFile
      let regularPackages = Descriptor.parseIndentedList "packages:" text
          bootstrapPackages = Descriptor.parseIndentedList "bootstrap-packages:" text
      return (selectPackages selection regularPackages bootstrapPackages)

data PackageSelection =
  PackageSelection
    { includeRegularPackages :: Bool
    , includeBootstrapPackages :: Bool
    }

regularOnly :: PackageSelection
regularOnly = PackageSelection True False

includeBootstrap :: Bool -> PackageSelection
includeBootstrap includeRegular =
  PackageSelection includeRegular True

parsePackageSelection :: String -> Maybe PackageSelection
parsePackageSelection "--dont-exclude-bootstrap" = Just (includeBootstrap True)
parsePackageSelection "--bootstrap-only" = Just (includeBootstrap False)
parsePackageSelection _ = Nothing

selectPackages :: PackageSelection -> [FilePath] -> [FilePath] -> [FilePath]
selectPackages selection regularPackages bootstrapPackages =
  List.nub $
    (if includeRegularPackages selection then regularPackages else []) ++
    (if includeBootstrapPackages selection then bootstrapPackages else [])

removeStageSkips :: FilePath -> String -> IO ()
removeStageSkips buttonsDir prefix = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if (prefix `List.isPrefixOf` entry || entry == prefix ++ ".buttons.skip") && ".skip" `List.isSuffixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()


readFileStrict :: FilePath -> IO String
readFileStrict path = do
  text <- readFile path
  length text `seq` return text

findPackageCabalFile :: FilePath -> IO (Maybe FilePath)
findPackageCabalFile packageDir = do
  exists <- doesDirectoryExist packageDir
  if not exists
    then return Nothing
    else do
      entries <- listDirectory packageDir
      let cabalFiles = [packageDir </> entry | entry <- entries, takeExtension entry == ".cabal"]
      return (case cabalFiles of
                [] -> Nothing
                (path:_) -> Just path)

cabalPackageNameFromText :: String -> String -> String
cabalPackageNameFromText cabalText fallback =
  case [trim (drop (length "name:") line) | line <- lines cabalText, "name:" `List.isPrefixOf` trimStart line] of
    (name:_) | not (null name) -> name
    _ -> fallback

trim :: String -> String
trim = trimEnd . trimStart

trimStart :: String -> String
trimStart = dropWhile isSpace

trimEnd :: String -> String
trimEnd = reverse . trimStart . reverse
