name: garrage
depends:
  folders
exposes:
  Garrage
  Garrage.Descriptor
  Garrage.Buttons
  Garrage.Verification
  Garrage.Check
go-is: Garrage.go
