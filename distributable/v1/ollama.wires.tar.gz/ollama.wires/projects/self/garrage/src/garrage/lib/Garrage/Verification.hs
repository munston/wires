module Garrage.Verification where

import Control.Monad
import qualified Data.List as L
import System.Directory
import System.FilePath
import System.IO

-- | Location for per-project verification stamps for garrage.
verificationProjectStampFile :: FilePath -> FilePath -> FilePath
verificationProjectStampFile root packageRelative =
  root </> ".wires-verification" </> normalise packageRelative </> "cog.stamp"

stageProjectStampFile :: FilePath -> FilePath -> FilePath -> FilePath
stageProjectStampFile root packageRelative stampName =
  root </> ".wires-verification" </> normalise packageRelative </> stampName

-- | Compute a verification fingerprint for a project package.
computeProjectVerificationFingerprint :: FilePath -> FilePath -> IO String
computeProjectVerificationFingerprint root packageRelative = do
  pkgDir <- findPackageDir root packageRelative
  absolutePkgRoot <- canonicalizePath pkgDir
  packageFiles <- fmap L.sort (verificationPackageFiles absolutePkgRoot)
  packageChunks <- mapM (fingerprintChunk absolutePkgRoot) packageFiles
  return (show (hashText (concat packageChunks)))

computeProjectStageFingerprint :: FilePath -> FilePath -> FilePath -> IO String
computeProjectStageFingerprint root packageRelative stampName = do
  pkgDir <- findPackageDir root packageRelative
  absolutePkgRoot <- canonicalizePath pkgDir
  packageFiles <- fmap L.sort (stagePackageFiles stampName absolutePkgRoot)
  chunks <- mapM (fingerprintChunk absolutePkgRoot) packageFiles
  return (show (hashText (concat chunks)))

-- | Determine whether the recorded stamp matches the current fingerprint.
isProjectVerificationCurrent :: FilePath -> FilePath -> IO Bool
isProjectVerificationCurrent root packageRelative = do
  current <- computeProjectVerificationFingerprint root packageRelative
  let stampFile = verificationProjectStampFile root packageRelative
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- readStampLine stampFile
      return (recorded == current)

isStageCurrent :: FilePath -> FilePath -> FilePath -> IO Bool
isStageCurrent root packageRelative stampName = do
  current <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = stageProjectStampFile root packageRelative stampName
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- readStampLine stampFile
      return (recorded == current)

readStampLine :: FilePath -> IO String
readStampLine path = withFile path ReadMode hGetLine

-- | Record the current fingerprint into the stamp file.
recordVerificationSingleProject :: FilePath -> FilePath -> IO String
recordVerificationSingleProject root packageRelative = do
  fingerprint <- computeProjectVerificationFingerprint root packageRelative
  let stampFile = verificationProjectStampFile root packageRelative
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("garrage verification stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ fingerprint)

-- | Clean per-package verification state: remove stamp files and any .skip markers
cleanProjectVerification :: FilePath -> FilePath -> IO String
cleanProjectVerification root packageRelative = do
  pkgDir <- findPackageDir root packageRelative
  let stampFiles =
        [ verificationProjectStampFile root packageRelative
        , stageProjectStampFile root packageRelative "install.stamp"
        , stageProjectStampFile root packageRelative "test.stamp"
        , stageProjectStampFile root packageRelative "documentation.stamp"
        ]
  forM_ stampFiles $ \stampFile -> do
    exists <- doesFileExist stampFile
    when exists (removeFile stampFile)
  -- remove .skip markers in package .buttons
  skipFiles <- findFilesByExtension (pkgDir </> ".buttons") ".skip"
  mapM_ removeFile skipFiles
  return ("cleaned garrage project verification for " ++ packageRelative ++ ": removed skips " ++ show (length skipFiles))


-- | Record an arbitrary stage stamp under `.wires-verification/<package>/`.
-- stampName is typically one of: "build.stamp", "install.stamp",
-- "test.stamp", or "documentation.stamp".
recordStage :: FilePath -> FilePath -> FilePath -> IO String
recordStage root packageRelative stampName = do
  fingerprint <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = stageProjectStampFile root packageRelative stampName
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("garrage " ++ takeBaseName stampName ++ " stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ fingerprint)

-- | Files that contribute to the verification fingerprint for a package.
verificationPackageFiles :: FilePath -> IO [FilePath]
verificationPackageFiles pkgDir = do
  descriptors <- fmap concat (mapM (findImmediateFilesByExtension pkgDir) [".nut", ".bolt", ".cog"])
  cabalFiles <- findImmediateFilesByExtension pkgDir ".cabal"
  modules <- findFilesByExtension (pkgDir </> "lib") ".hs"
  return (descriptors ++ cabalFiles ++ modules)

stagePackageFiles :: FilePath -> FilePath -> IO [FilePath]
stagePackageFiles stampName pkgDir = do
  cabalFiles <- findImmediateFilesByExtension pkgDir ".cabal"
  nutFiles <- findImmediateFilesByExtension pkgDir ".nut"
  garrageFiles <- findImmediateFilesByExtension pkgDir ".garrage"
  boltFiles <- findImmediateFilesByExtension pkgDir ".bolt"
  cogFiles <- findImmediateFilesByExtension pkgDir ".cog"
  libFiles <- sourceTreeFiles pkgDir ["lib", "src"] [".hs"]
  exeFiles <- sourceTreeFiles pkgDir ["exe", "app"] [".hs"]
  testFiles <- sourceTreeFiles pkgDir ["test", "cog"] [".hs"]
  let buildFiles = cabalFiles ++ nutFiles ++ garrageFiles ++ libFiles
      installFiles = buildFiles ++ boltFiles ++ exeFiles
      testStageFiles = buildFiles ++ cogFiles ++ testFiles
      documentationFiles = buildFiles
  return $
    case stampName of
      "build.stamp" -> buildFiles
      "install.stamp" -> installFiles
      "test.stamp" -> testStageFiles
      "documentation.stamp" -> documentationFiles
      _ -> cabalFiles ++ nutFiles ++ garrageFiles ++ boltFiles ++ cogFiles ++ libFiles ++ exeFiles ++ testFiles

sourceTreeFiles :: FilePath -> [FilePath] -> [String] -> IO [FilePath]
sourceTreeFiles pkgDir dirs extensions =
  fmap concat $
    forM dirs $ \dirName ->
      findFilesByExtensions (pkgDir </> dirName) extensions

-- | Helpers for discovering files
findImmediateFilesByExtension :: FilePath -> String -> IO [FilePath]
findImmediateFilesByExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      filterM doesFileExist [dir </> entry | entry <- entries, takeExtension entry == extension]

findFilesByExtension :: FilePath -> String -> IO [FilePath]
findFilesByExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      fmap concat $ forM entries $ \entry -> do
        let path = dir </> entry
        isDir <- doesDirectoryExist path
        isFile <- doesFileExist path
        if isDir
          then findFilesByExtension path extension
          else return [path | isFile && takeExtension path == extension]

-- | Read a file and yield a normalized chunk for hashing.
fingerprintChunk :: FilePath -> FilePath -> IO String
fingerprintChunk root path = do
  text <- readFile path
  return (normalise (makeRelative root path) ++ "\n" ++ text ++ "\n")

-- | Simple deterministic text hash (small FNV-like)
hashText :: String -> Integer
hashText = foldl' hashStep 2166136261

foldl' :: (a -> b -> a) -> a -> [b] -> a
foldl' = \f z xs -> case xs of
  [] -> z
  (y:ys) -> foldl' f (f z y) ys

hashStep :: Integer -> Char -> Integer
hashStep value char = ((value * 16777619) + toInteger (fromEnum char)) `mod` 1000000007

-- | Very small utility: try common locations for a package relative path.
findPackageDir :: FilePath -> FilePath -> IO FilePath
findPackageDir root packageRelative = do
  let candidate1 = root </> "projects" </> packageRelative
      candidate2 = root </> packageRelative
  exists1 <- doesDirectoryExist candidate1
  if exists1
    then return candidate1
    else do
      exists2 <- doesDirectoryExist candidate2
      if exists2
        then return candidate2
        else error ("package not found: " ++ packageRelative)

-- | find files with any of given extensions (not used currently, kept for parity)
findFilesByExtensions :: FilePath -> [String] -> IO [FilePath]
findFilesByExtensions dir extensions = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      fmap concat $ forM entries $ \entry -> do
        let path = dir </> entry
        isDir <- doesDirectoryExist path
        isFile <- doesFileExist path
        if isDir
          then findFilesByExtensions path extensions
          else return [path | isFile && takeExtension path `elem` extensions]
