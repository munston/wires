module Garrage.Check where

import Data.Char
import Data.List
import Folders.Routes
import System.Directory
import System.FilePath

-- | Check that a package contains a correctly formatted go-is module.
-- Expects: root/projects/<packageRelative>
checkPackageGo :: FilePath -> FilePath -> IO (Either [String] String)
checkPackageGo root packageRelative = do
  pkgDir <- findPackageDir root packageRelative
  let garragePath = pkgDir </> "package.garrage"
  garrageExists <- doesFileExist garragePath
  if garrageExists
    then do
      garrageText <- readFile garragePath
      case parseField "garrage-is:" garrageText of
        Nothing -> return (Left [packageRelative ++ ": missing garrage-is in package.garrage"])
        Just goTarget -> checkModuleTarget pkgDir goTarget
    else do
      -- fallback: accept a package that is cabal-only (library stanza).
      -- find a .cabal file and parse exposed modules to derive the go target
      entries <- listDirectory pkgDir
      let cabalFiles = [e | e <- entries, ".cabal" `isSuffixOf` e]
      case cabalFiles of
        [] -> return (Left [packageRelative ++ ": missing package descriptor (.garrage or .cabal)"])
        (cabalFile:_) -> do
          cabalText <- readFile (pkgDir </> cabalFile)
          let exposed = parseExposedModules cabalText
          case exposed of
            (m:_) -> checkModuleTarget pkgDir (m ++ ".go")
            [] -> return (Left [packageRelative ++ ": no exposed-modules in .cabal; cannot infer go target"]) 

-- | Parse `exposed-modules:` section from a .cabal file text.
parseExposedModules :: String -> [String]
parseExposedModules text =
  let ls = lines text
      -- find header line
      rest = dropWhile (not . ("exposed-modules:" `isPrefixOf`) . trim) ls
  in case rest of
       [] -> []
       (_:items) -> map trimListItem (takeWhile isListItem items)

isSectionHeader :: String -> Bool
isSectionHeader line =
  let value = trim line
  in not (null value) && ":" `isSuffixOf` value && not (isSpace (safeHead line))

isListItem :: String -> Bool
isListItem line =
  let value = trim line
  in not (null value) && not (isSectionHeader line) && (isSpace (safeHead line) || "- " `isPrefixOf` value)

-- | Check a given go-is target (Module.function) against package sources
checkModuleTarget :: FilePath -> String -> IO (Either [String] String)
checkModuleTarget pkgDir goTarget =
  case splitGoTarget goTarget of
    (moduleName, '.':fn) | not (null fn) -> do
      let modulePath = moduleFilePath moduleName
          fullPath = pkgDir </> "lib" </> modulePath
      exists <- doesFileExist fullPath
      if not exists
        then return (Left ["go-is module missing from source: " ++ moduleName])
        else do
          text <- readFile fullPath
          -- only parse implementation routes and perform precog pairing
          -- if a package.nut exists (i.e., downstream stage produced a nut with go-is)
          let nutPath = pkgDir </> "package.nut"
          nutExists <- doesFileExist nutPath
          routesResult <- if nutExists then return (parseImplementationRoutes fullPath text) else return (Right ([], []))
          let fnPresent = checkFunctionExists text fn
              fnSigOk = if fn == "go" then checkGoSignature text fn else True
              -- parse errors from the verifiedRoutes/routeOptouts parsing (only present when nutExists)
              routeParseErrors = case routesResult of Left es -> es; Right _ -> []
              -- additional pairing checks: each VerifiedRoute must have a precog
              -- that looks like a lambda (String -> Bool) and must be covered by
              -- a corresponding 'go "<option>"' branch in the implementation.
              routePairingErrors = case routesResult of
                Left _ -> []
                Right (routes, _optouts) -> concatMap (checkRoutePairing text fullPath) routes
              missingFnErr = if not fnPresent then [fullPath ++ ": go-is function missing: " ++ fn] else []
              sigErr = if fn == "go" && not fnSigOk then [fullPath ++ ": go-is function has incorrect or missing signature; expected: go :: String -> [String] -> IO String"] else []
              errors' = routeParseErrors ++ routePairingErrors ++ missingFnErr ++ sigErr
          if null errors'
            then return (Right ("garrage go check ok for: " ++ moduleName ++ "." ++ fn))
            else return (Left errors')
    _ -> return (Left ["invalid go-is target: " ++ goTarget])

-- Try common locations for package descriptor
findPackageDir :: FilePath -> FilePath -> IO FilePath
findPackageDir root packageRelative = do
  let candidate1 = root </> "projects" </> packageRelative
      candidate2 = root </> "projects" </> packageRelative </> "src" </> packageRelative
      candidate3 = root </> "projects" </> packageRelative </> "src"
  -- prefer src/<pkg> layout where generators typically write files
  e2 <- hasPackageDescriptor candidate2
  if e2 then return candidate2 else do
    e1 <- hasPackageDescriptor candidate1
    if e1 then return candidate1 else do
      e3 <- hasPackageDescriptor candidate3
      if e3 then return candidate3 else error ("package not found: " ++ packageRelative)

hasPackageDescriptor :: FilePath -> IO Bool
hasPackageDescriptor dir = do
  dirExists <- doesDirectoryExist dir
  if not dirExists
    then return False
    else do
      garrageExists <- doesFileExist (dir </> "package.garrage")
      if garrageExists
        then return True
        else do
          entries <- listDirectory dir
          return (any (".cabal" `isSuffixOf`) entries)

-- | Build a filesystem path for a module like Foo.Bar -> Foo/Bar.hs
moduleFilePath :: String -> FilePath
moduleFilePath moduleName =
  foldr (</>) "" (splitOnDot moduleName) <.> "hs"

splitOnDot :: String -> [String]
splitOnDot value =
  case break (== '.') value of
    (left, []) -> [left]
    (left, _:right) -> left : splitOnDot right

-- | Parse verifiedRoutes and routeOptouts from a module text.
parseImplementationRoutes :: FilePath -> String -> Either [String] ([VerifiedRoute], [RouteOptout])
parseImplementationRoutes path text =
  let routeResults = map parseVerifiedRoute (filter routeLine (routeSectionLines "verifiedRoutes =" text))
      optoutResults = map parseRouteOptout (filter optoutLine (routeSectionLines "routeOptouts =" text))
      routes = collectRights routeResults
      optouts = collectRights optoutResults
      errors = concatMap collectErrors routeResults ++ concatMap collectErrors optoutResults
  in if null errors then Right (routes, optouts) else Left (map ((path ++ ": ") ++) errors)

parseField :: String -> String -> Maybe String
parseField key text =
  case [trim (drop (length key) line) | line <- lines text, key `isPrefixOf` trim line] of
    value:_ | not (null value) -> Just value
    _ -> Nothing

splitGoTarget :: String -> (String, String)
splitGoTarget target =
  let reversed = reverse target
  in case break (== '.') reversed of
       (_, []) -> (target, "")
       (functionName, '.':moduleName) -> (reverse moduleName, '.':reverse functionName)
       _ -> (target, "")

routeSectionLines :: String -> String -> [String]
routeSectionLines key text =
  let rest = drop 1 (dropWhile (not . (key `isPrefixOf`) . trim) (lines text))
  in takeWhile routeSectionBody rest

routeSectionBody :: String -> Bool
routeSectionBody line = null (trim line) || isSpace (safeHead line)

routeLine :: String -> Bool
routeLine line = "VerifiedRoute" `isPrefixOf` trimRouteItem line

optoutLine :: String -> Bool
optoutLine line = "RouteOptout" `isPrefixOf` trimRouteItem line

trimRouteItem :: String -> String
trimRouteItem line = stripLeadingRouteMarker (stripTrailingComma (trimListItem line))

stripLeadingRouteMarker :: String -> String
stripLeadingRouteMarker value = case trim value of
  ',':rest -> trim rest
  '[':rest -> trim rest
  other -> other

stripTrailingComma :: String -> String
stripTrailingComma value = case reverse (trim value) of
  ',':rest -> trim (reverse rest)
  _ -> trim value

trimListItem :: String -> String
trimListItem line = let value = trim line in if "- " `isPrefixOf` value then trim (drop 2 value) else value

parseVerifiedRoute :: String -> Either [String] VerifiedRoute
parseVerifiedRoute line = case reads (trimRouteItem line) of
  [(route, rest)] | all isSpace rest -> Right route
  _ -> Left ["invalid VerifiedRoute line: " ++ trim line]

parseRouteOptout :: String -> Either [String] RouteOptout
parseRouteOptout line = case reads (trimRouteItem line) of
  [(optout, rest)] | all isSpace rest -> Right optout
  _ -> Left ["invalid RouteOptout line: " ++ trim line]

collectErrors :: Either [String] a -> [String]
collectErrors value = case value of Left errors -> errors; Right _ -> []

collectRights :: [Either [String] a] -> [a]
collectRights values = [value | Right value <- values]

trim :: String -> String
trim = f . f where f = reverse . dropWhile isSpace

safeHead :: String -> Char
safeHead value = case value of [] -> ' '; char:_ -> char

-- | Minimal check that a function name appears in the module text
-- either as a type signature or as text occurrence followed by space.
checkFunctionExists :: String -> String -> Bool
checkFunctionExists text functionName = any (`isInfixOf` text) [functionName ++ " ::", functionName ++ " "]

-- | Check that the `go` function has the expected type signature.
-- We look for a type signature line like:
--
--   go :: String -> [String] -> IO String
--
-- Whitespace is ignored when matching the RHS.
checkGoSignature :: String -> String -> Bool
checkGoSignature text functionName =
  let ls = lines text
      pattern = functionName ++ " ::"
      matches = [ trim (drop (length pattern) t) | l <- ls, let t = trim l, pattern `isPrefixOf` t ]
  in case matches of
       (sig:_) -> filter (not . isSpace) sig == "String->[String]->IOString"
       [] -> False

-- | Check that a VerifiedRoute is paired with a usable precog expression
-- and that the go implementation contains a branch handling the option.
checkRoutePairing :: String -> FilePath -> VerifiedRoute -> [String]
checkRoutePairing text path route =
  let option = routeOption route
      precog = routePrecog route
      precogOk = isPrecogExpr precog
      branchOk = goHasBranch text option
      precogErr = if not precogOk then [path ++ ": VerifiedRoute has invalid precog expression for option: " ++ option] else []
      branchErr = if not branchOk then [path ++ ": go implementation missing branch for option: " ++ option] else []
  in precogErr ++ branchErr

-- | Heuristic check that the precog text looks like a lambda expression
-- such as "\\s -> ..." or a parenthesised lambda "(\s -> ...)".
isPrecogExpr :: String -> Bool
isPrecogExpr s =
  let t = trim s
      stripParens v = if length v >= 2 && head v == '(' && last v == ')' then trim (init (tail v)) else v
      body = stripParens t
  in not (null body) && head body == '\\' && "->" `isInfixOf` body

-- | Heuristic check that the module text contains a pattern match for
-- the given option in the form: go "<option>" ... =
goHasBranch :: String -> String -> Bool
goHasBranch text option =
  let needle = "go " ++ show option
      ls = lines text
  in any (needle `isInfixOf`) ls
