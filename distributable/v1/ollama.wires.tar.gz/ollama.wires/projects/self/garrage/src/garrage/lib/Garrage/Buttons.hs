module Garrage.Buttons where

import System.FilePath
import System.Directory
import System.IO

writeButton :: FilePath -> FilePath -> String -> String -> IO ()
writeButton dir fileName endpoint argument =
  writeGeneratedFile (dir </> fileName) (show (endpoint, argument) ++ "\n")

writeButtons :: FilePath -> [FilePath] -> IO ()
writeButtons path entries =
  writeGeneratedFile path (unlines entries)

writeGeneratedFile :: FilePath -> String -> IO ()
writeGeneratedFile path body = do
  createDirectoryIfMissing True (takeDirectory path)
  exists <- doesFileExist path
  if exists
    then do
      current <- readFileStrict path
      if current == body
        then return ()
        else writeFile path body
    else writeFile path body

readFileStrict :: FilePath -> IO String
readFileStrict path =
  withFile path ReadMode $ \handle -> do
    text <- hGetContents handle
    length text `seq` return text
