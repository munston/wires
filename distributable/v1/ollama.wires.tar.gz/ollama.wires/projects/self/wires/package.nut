name: wires
depends:
  folders
  gofur
  garrage
exposes:
  Wires
go-is: Wires.go
