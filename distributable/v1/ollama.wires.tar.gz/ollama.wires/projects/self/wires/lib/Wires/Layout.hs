{-|
Module: Wires.Layout
Parsimonious Read/Show datatypes whose field names mirror on-disk names.

Mapping rule used for field names:
- If a filesystem name begins with a dot (`.`) the field name is prefixed with `dot_`.
- All other non-alphanumeric characters (including `.` and `-`) are replaced with `_`.
Examples: `buttons.plan` -> `buttons_plan`, `.buttons` -> `dot_buttons`.
-}

{-# LANGUAGE DuplicateRecordFields #-}

module Wires.Layout where

type Path = FilePath
type Name = String

-- Top-level root object. Field names map to on-disk tokens (see mapping rule above).
data WiresRoot = WiresRoot
  { buttons_plan :: Maybe Path
  , clean_bat :: Maybe Path
  , demo_wire :: Maybe Path
  , document_bat :: Maybe Path
  , install_bat :: Maybe Path
  , status_bat :: Maybe Path
  , test_bat :: Maybe Path
  , wire_bat :: Maybe Path
  , dot_buttons :: Maybe ButtonsSet
  , dot_wires_verification :: Maybe VerificationTree
  , bin :: Maybe RootBins
  , projects :: Projects
  , walks :: WalkTree
  , tools :: ToolTree
  , proposals :: [Path]
  , snapshots :: [Path]
  , versions :: [Path]
  , notes :: [Path]
  } deriving (Eq, Read, Show)

-- `.buttons` / `*.buttons` sets
data ButtonsSet = ButtonsSet
  { buttons :: [Path]        -- *.buttons files
  , button_actions :: [Path] -- *.button files
  , button_skips :: [Path]   -- *.button.skip files
  , button_counts :: ButtonCounts
  } deriving (Eq, Read, Show)

data ButtonCounts = ButtonCounts
  { buttons_count :: Int
  , actions_count :: Int
  , skips_count :: Int
  } deriving (Eq, Read, Show)

-- `.wires-verification` tree (per-project stamps)
data VerificationTree = VerificationTree
  { dot_wires_verification_projects :: [(Name, [Path])] -- project -> stamp paths
  } deriving (Eq, Read, Show)

-- shipped/runtime `bin` layout
data RootBins = RootBins
  { dot_alive :: [Path]       -- e.g. `bin/.alive`
  , top_executables :: [Path] -- top-level exes
  , projects_bin :: [Path]    -- projects/bin/*
  } deriving (Eq, Read, Show)

-- `projects` directory + top manifests
data Projects = Projects
  { projects_path :: Path
  , cabal_project :: Maybe Path -- top-level `cabal.project`
  , wires_project :: Maybe Path -- `wires.project` (casted representation)
  , items :: [Project]
  } deriving (Eq, Read, Show)

data Project = Project
  { project_name :: Name
  , project_path :: Path
  , cabal_project :: Maybe Path -- project-local `cabal.project`
  , wires_project :: Maybe Path -- `wires.project` (after cast)
  , buttons_plan :: Maybe Path  -- package-local `buttons.plan`
  , src :: Maybe ProjectSrc
  , template :: Maybe Path
  } deriving (Eq, Read, Show)

data ProjectSrc = ProjectSrc
  { src_path :: Path
  , src_packages :: [Package]
  } deriving (Eq, Read, Show)

data Package = Package
  { package_name :: Name
  , package_path :: Path
  , cabal :: Maybe CabalPackage
  , wires :: Maybe WiresPackage
  , buttons :: Maybe ButtonsSet
  , srcs :: [PackageSrc]
  , docs_txt :: [Path]
  , bins :: [Path]
  , alive :: [Path]
  , notes :: [Path]
  } deriving (Eq, Read, Show)

data PackageSrcKind = LibSrc | ExeSrc | CogSrc | DocsTxtSrc | BinSrc | TemplateSrc String | OtherSrc String
  deriving (Eq, Read, Show)

data PackageSrc = PackageSrc
  { psrc_kind :: PackageSrcKind
  , psrc_path :: Path
  , psrc_files :: [Path]
  } deriving (Eq, Read, Show)

-- minimal manifest stubs (expand later if desired)
data CabalPackage = CabalPackage
  { cabal_path :: Path
  , cabal_raw :: Maybe String
  } deriving (Eq, Read, Show)

data WiresPackage = WiresPackage
  { wires_path :: Path
  , wires_raw :: Maybe String
  } deriving (Eq, Read, Show)

class PackageLayoutLike p where
  to_wires_package :: p -> WiresPackage
  to_cabal_package :: p -> CabalPackage

-- Walks
data WalkTree = WalkTree { walk_sets :: [WalkSet] } deriving (Eq, Read, Show)
data WalkSet  = WalkSet { walk_set_name :: Name, walk_set_path :: Path, walk_step_count :: Int } deriving (Eq, Read, Show)

-- tools / stores / simple refs
data ToolTree  = ToolTree { tool_files :: [Path] } deriving (Eq, Read, Show)
data StoreTree = StoreTree { store_proposals :: [Path], store_snapshots :: [Path], store_versions :: [Path] } deriving (Eq, Read, Show)

data HsModule = HsModule { hs_module_path :: Path, hs_module_name :: Name } deriving (Eq, Read, Show)
