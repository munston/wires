module Wires.Folders where

import Folders.Shape
