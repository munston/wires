module Wires.Extensions.WireProject where

newtype WireProjectFile = WireProjectFile { wireProjectText :: String }
  deriving (Eq, Show)

fileName :: String
fileName = "wire.project"

parseWireProject :: String -> Either String WireProjectFile
parseWireProject = Right . WireProjectFile

renderWireProject :: WireProjectFile -> String
renderWireProject = wireProjectText

validateWireProject :: WireProjectFile -> Either String ()
validateWireProject _ = Right ()

