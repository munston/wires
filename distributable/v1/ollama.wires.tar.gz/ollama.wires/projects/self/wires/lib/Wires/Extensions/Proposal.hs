module Wires.Extensions.Proposal where

newtype ProposalFile = ProposalFile { proposalText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".proposal"

parseProposal :: String -> Either String ProposalFile
parseProposal = Right . ProposalFile

renderProposal :: ProposalFile -> String
renderProposal = proposalText

validateProposal :: ProposalFile -> Either String ()
validateProposal _ = Right ()

