{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE PolyKinds #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE KindSignatures #-}

module Wires.HTree where

-- HList: heterogeneous list of types
data HList (xs :: [*]) where
  HEmpty :: HList '[]
  HCons  :: x -> HList xs -> HList (x ': xs)

-- FList: heterogeneous list of type-indexed functor applications
data FList (f :: k -> *) (xs :: [k]) where
  FEmpty :: FList f '[]
  FCons  :: f x -> FList f xs -> FList f (x ': xs)

-- Filetype: concrete file kinds present on disk
data Filetype
  = Bat
  | Exe
  | Alive
  | Buttons
  | Button
  | ButtonSkip
  | Plan
  | Project
  | Cabal
  | Nut
  | Bolt
  | Cog
  | Hs
  | Txt
  | Md
  | Json
  | Wire
  | Stamp
  | Step

-- Tree: keep `Tree a` but make Branches carry both subtrees and concrete file kinds
data Tree a = Branches [Tree a] [Filetype] | Leaf a

-- HFile: file leaf tagged by its concrete filetype
data HFile (filetype :: Filetype) where
  HFile :: String -> HFile filetype

-- HTree: type-indexed heterogeneous tree. `Branches` now stores
-- a type-level list of recursive `Tree *` children and a type-level
-- list of concrete `Filetype` values for file leaves.
data HTree (t :: Tree *) where 
  HBranches ::
    FList HTree xs ->
    FList HFile files ->
    HTree (Branches xs files)

  HLeaf ::
    x ->
    HTree (Leaf x)

-- Example directory:
--
-- root/
--   README.txt
--   config.json
--   src/
--     Main.hs

type SrcTree =
  Branches
    '[]
    '[ Hs ]

srcTree :: HTree SrcTree
srcTree =
  HBranches
    FEmpty
    (HFile "Main.hs" `FCons` FEmpty)

type RootTree =
  Branches
    '[ SrcTree ]
    '[ Txt, Json ]

rootTree :: HTree RootTree
rootTree =
  HBranches
    (srcTree `FCons` FEmpty)
    (HFile "README.txt" `FCons` (HFile "config.json" `FCons` FEmpty))
