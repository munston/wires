module Wires.Extensions.Nut where

newtype NutFile = NutFile { nutText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".nut"

parseNut :: String -> Either String NutFile
parseNut = Right . NutFile

renderNut :: NutFile -> String
renderNut = nutText

validateNut :: NutFile -> Either String ()
validateNut _ = Right ()

