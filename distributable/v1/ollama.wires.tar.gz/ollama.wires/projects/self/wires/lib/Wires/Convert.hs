module Wires.Convert where

import System.Directory
import System.FilePath
import Control.Monad
import Wires.Cast (castWiresProject)

-- Conservative helpers
findImmediateFilesByExtension :: FilePath -> String -> IO [FilePath]
findImmediateFilesByExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      filterM doesFileExist [dir </> entry | entry <- entries, takeExtension entry == extension]

-- Detect package representation: prefer Cabal when both present.
detectPackageFormat :: FilePath -> FilePath -> IO String
detectPackageFormat root packageRelative = do
  let pkgDir = root </> "projects" </> packageRelative
  cabals <- findImmediateFilesByExtension pkgDir ".cabal"
  nuts <- findImmediateFilesByExtension pkgDir ".nut"
  garrageExists <- doesFileExist (pkgDir </> "package.garrage")
  case (not (null cabals), (not (null nuts) || garrageExists)) of
    (True, _) -> return "cabal"
    (False, True) -> return "wires"
    _ -> return "unknown"

-- wires -> cabal using existing cast behaviour
convertWiresToCabal :: FilePath -> FilePath -> IO String
convertWiresToCabal root packageRelative = do
  _ <- castWiresProject root packageRelative
  return ("convert wires->cabal: " ++ packageRelative)

-- cabal -> wires: conservative, best-effort. Create a minimal
-- package.nut only when a .cabal exists and no nut/garrage is present.
cabalToWiresProject :: FilePath -> FilePath -> IO String
cabalToWiresProject root packageRelative = do
  let pkgDir = root </> "projects" </> packageRelative
      nutFile = pkgDir </> "package.nut"
  cabals <- findImmediateFilesByExtension pkgDir ".cabal"
  nuts <- findImmediateFilesByExtension pkgDir ".nut"
  garrageExists <- doesFileExist (pkgDir </> "package.garrage")
  if null cabals
    then return ("cabal->wires skipped (no .cabal): " ++ packageRelative)
    else if (not (null nuts) || garrageExists)
      then return ("cabal->wires skipped (already wires form): " ++ packageRelative)
      else do
        createDirectoryIfMissing True pkgDir
        writeFile nutFile ("# generated-by: wires cabal->nut 0.1\nname: " ++ takeFileName packageRelative ++ "\n")
        return ("cabal->wires created package.nut: " ++ packageRelative)

-- wires-first composition (used when starting format is wires)
convertWiresFirst :: FilePath -> FilePath -> IO String
convertWiresFirst root pkg = do
  a <- convertWiresToCabal root pkg
  b <- cabalToWiresProject root pkg
  return (a ++ "; " ++ b)

-- cabal-first composition (used when starting format is cabal)
convertCabalFirst :: FilePath -> FilePath -> IO String
convertCabalFirst root pkg = do
  a <- cabalToWiresProject root pkg
  b <- convertWiresToCabal root pkg
  return (a ++ "; " ++ b)

-- Auto detect and run appropriate composition
convertAuto :: FilePath -> FilePath -> IO String
convertAuto root pkg = do
  fmt <- detectPackageFormat root pkg
  case fmt of
    "wires" -> convertWiresFirst root pkg
    "cabal" -> convertCabalFirst root pkg
    _ -> return ("convert: unknown package format for " ++ pkg)
