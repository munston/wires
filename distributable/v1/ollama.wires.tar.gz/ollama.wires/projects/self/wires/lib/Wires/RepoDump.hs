{-# LANGUAGE OverloadedStrings #-}

module Wires.RepoDump
  ( FileRep(..)
  , RepoDump(..)
  , buildRepoDump
  ) where

import System.Directory
  ( canonicalizePath
  , doesDirectoryExist
  , listDirectory
  )
import System.FilePath
  ( (</>)
  , takeExtension
  , makeRelative
  )
import Control.Monad
import Data.Char
import Control.Exception

type Path = FilePath

-- | A simple representation of a single file in the repository.
data FileRep = FileRep
  { frPath    :: Path
  , frContent :: Maybe String -- ^ textual contents when available
  }
  deriving (Eq, Read, Show)

-- | Full repository dump: root path and a list of `FileRep` entries.
data RepoDump = RepoDump
  { rdRoot  :: Path
  , rdFiles :: [FileRep]
  }
  deriving (Eq, Read, Show)

-- Directories to exclude when walking the tree
defaultExcludes :: [FilePath]
defaultExcludes = ["walks","external","dist-newstyle",".git","dist","tmp","build","node_modules","versions","saves"]

-- Extensions considered textual for inline dumping
textualExts :: [String]
textualExts = map (map toLower) [".hs",".cabal",".project",".wire",".button",".buttons",".bat",".txt",".md",".json",".yaml",".yml",".plan",".nut",".bolt",".cog"]

-- | Recursively list files under a directory while skipping common irrelevant dirs.
-- Directories named ".buttons" are NOT skipped so their contents are included.
listFilesRecursive :: [FilePath] -> FilePath -> IO [FilePath]
listFilesRecursive excludes top = do
  root <- canonicalizePath top
  go root
 where
  go dir = do
    entries <- listDirectory dir
    fmap concat $ forM entries $ \e -> do
      let path = dir </> e
      isDir <- doesDirectoryExist path
      if isDir
        then if (map toLower e) `elem` map (map toLower) excludes && map toLower e /= ".buttons"
               then return []
               else go path
        else return [path]

-- | Build a `RepoDump` by reading textual files inline and noting other files by path.
buildRepoDump :: FilePath -> IO RepoDump
buildRepoDump top = do
  rootAbs <- canonicalizePath top
  files <- listFilesRecursive defaultExcludes top
  reps <- forM files $ \f -> do
    absF <- canonicalizePath f
    let rel = makeRelative rootAbs absF
    let ext = map toLower (takeExtension absF)
    if ext `elem` textualExts
      then do
        eres <- try (readFile absF) :: IO (Either SomeException String)
        case eres of
          Left _ -> return $ FileRep rel Nothing
          Right contents -> return $ FileRep rel (Just contents)
      else return $ FileRep rel Nothing
  return $ RepoDump rootAbs reps
