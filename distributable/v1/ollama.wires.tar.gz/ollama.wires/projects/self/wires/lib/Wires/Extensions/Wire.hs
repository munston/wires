module Wires.Extensions.Wire where

newtype WireFile = WireFile { wireText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".wire"

parseWire :: String -> Either String WireFile
parseWire = Right . WireFile

renderWire :: WireFile -> String
renderWire = wireText

validateWire :: WireFile -> Either String ()
validateWire _ = Right ()

