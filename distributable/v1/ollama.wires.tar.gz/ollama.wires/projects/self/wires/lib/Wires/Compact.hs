module Wires.Compact where

import System.Directory
import System.FilePath
import qualified Garrage.Descriptor as Descriptor
import Wires.Object

compactRootToGofur :: FilePath -> IO String
compactRootToGofur root = do
  object <- readObject "compact-gofur" root
  mapM_ (writeGofurPackage (wiresRoot object)) (wiresPackages object)
  writeRootStageFile (wiresMetadata object) ".gofur"
  return ("compact gofur ok\npackages: " ++ show (length (wiresPackages object)))

compactRootToGarrage :: FilePath -> IO String
compactRootToGarrage root = do
  object <- readObject "compact-garrage" root
  mapM_ (writeGofurPackage (wiresRoot object)) (wiresPackages object)
  mapM_ (writeGarragePackage (wiresRoot object)) (wiresPackages object)
  writeRootStageFile (wiresMetadata object) ".garrage"
  return ("compact garrage ok\npackages: " ++ show (length (wiresPackages object)))

readObject :: String -> FilePath -> IO WiresObject
readObject action root = do
  result <- readWiresObject root
  case result of
    Right object -> return object
    Left errors -> fail (unlines ((action ++ " failed while reading staged object:") : errors))

writeGofurPackage :: FilePath -> WiresPackage -> IO ()
writeGofurPackage root package = do
  -- intentionally no-op: do NOT generate `package.nut` files here.
  -- Generating package descriptors from the `wires` compact phase
  -- produced many false/duplicate package prefixes. Descriptor
  -- generation should be explicit (garrage-to-nut) when required.
  return ()

writeGarragePackage :: FilePath -> WiresPackage -> IO ()
writeGarragePackage root package = do
  -- intentionally no-op: do NOT generate `package.garrage` files here.
  return ()

writeRootStageFile :: WireMetadata -> String -> IO ()
writeRootStageFile metadata extension = do
  let root = takeDirectory (wireMetadataFile metadata)
      target = root </> wireName metadata <.> dropWhile (== '.') extension
  existing <- fmap concat (mapM (listExtension root) rootMetadataExtensions)
  mapM_ removeFile existing
  writeFile target (renderRootMetadata metadata)

renderRootMetadata :: WireMetadata -> String
renderRootMetadata metadata =
  unlines
    ( [ "name: " ++ wireName metadata
      ]
    ++ maybeField "author" (wireAuthor metadata)
    ++ [ "projects-folder: " ++ wireProjectsFolder metadata
       , "bin-folder: " ++ wireBinFolder metadata
       , "wire-entry: " ++ wireEntry metadata
       ]
    ++ maybeField "version-policy" (wireVersionPolicy metadata)
    ++ maybeField "snapshot-policy" (wireSnapshotPolicy metadata)
    ++ renderButtons (wireButtons metadata)
    )

renderButtons :: [(String, FilePath)] -> [String]
renderButtons [] = []
renderButtons buttons =
  "buttons:" : ["  " ++ name ++ ": " ++ path | (name, path) <- buttons]

maybeField :: String -> Maybe String -> [String]
maybeField _ Nothing = []
maybeField key (Just value) = [key ++ ": " ++ value]

renderNutDescriptor :: WiresPackage -> String
renderNutDescriptor package =
  Descriptor.renderNutDescriptor (packageNutDescriptor package)

renderGarrageDescriptor :: WiresPackage -> String
renderGarrageDescriptor package =
  Descriptor.renderGarrageDescriptor (packageNutDescriptor package)

packageNutDescriptor :: WiresPackage -> Descriptor.NutDescriptor
packageNutDescriptor package =
  let nut = wiresPackageNut package
  in Descriptor.NutDescriptor
       { Descriptor.nutDescriptorName = wiresPackageName package
       , Descriptor.nutDescriptorDepends = nutDepends nut
       , Descriptor.nutDescriptorExposes = nutExposes nut
       , Descriptor.nutDescriptorGoIs = nutGoIs nut
       }

packageDir :: FilePath -> WiresPackage -> FilePath
packageDir root package =
  root </> "projects" </> wiresPackagePath package
