module Wires.Extensions.Snapshot where

newtype SnapshotFile = SnapshotFile { snapshotText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".snapshot"

parseSnapshot :: String -> Either String SnapshotFile
parseSnapshot = Right . SnapshotFile

renderSnapshot :: SnapshotFile -> String
renderSnapshot = snapshotText

validateSnapshot :: SnapshotFile -> Either String ()
validateSnapshot _ = Right ()

