module Wires.Extensions.CabalProject where

newtype CabalProjectFile = CabalProjectFile { cabalProjectText :: String }
  deriving (Eq, Show)

fileName :: String
fileName = "cabal.project"

parseCabalProject :: String -> Either String CabalProjectFile
parseCabalProject = Right . CabalProjectFile

renderCabalProject :: CabalProjectFile -> String
renderCabalProject = cabalProjectText

validateGeneratedCabalProject :: CabalProjectFile -> Either String ()
validateGeneratedCabalProject _ = Right ()

