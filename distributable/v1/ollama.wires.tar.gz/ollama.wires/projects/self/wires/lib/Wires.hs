module Wires where

import Folders.Routes
import Wires.Build
import Wires.Cast
import Wires.Convert (convertAuto)
import Wires.Check
import Wires.Compact
import Wires.Object
import Wires.Project
import Wires.GofurAdvance
import qualified Wires.Unregister as Unregister

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--list\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--check", routeArgs = [], routePrecog = "\\s -> \"wires structural check ok\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--object-check", routeArgs = [], routePrecog = "\\s -> \"wires object integrity ok\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts =
  [ RouteOptout { routeOptoutOption = "--make", routeOptoutReason = "optout make is verified by the buttonized workflow itself" }
  , RouteOptout { routeOptoutOption = "--compile-wires", routeOptoutReason = "optout generated-source compilation route is verified by buttons install/test flow" }
  , RouteOptout { routeOptoutOption = "--cast", routeOptoutReason = "optout Cabal file conversion route is verified by buttons install/test flow" }
  , RouteOptout { routeOptoutOption = "--halt-project-bin", routeOptoutReason = "optout destructive/runtime quiescence route is verified structurally for now" }
  , RouteOptout { routeOptoutOption = "--clean-project-bin", routeOptoutReason = "optout destructive bin cleanup route is verified structurally for now" }
  , RouteOptout { routeOptoutOption = "--cabal-install", routeOptoutReason = "optout external Cabal invocation route is verified structurally for now" }
  , RouteOptout { routeOptoutOption = "--test", routeOptoutReason = "optout test route requires generated cog runner" }
  , RouteOptout { routeOptoutOption = "--haddock", routeOptoutReason = "optout Haddock generation route is verified by buttons install flow" }
  , RouteOptout { routeOptoutOption = "--codfish", routeOptoutReason = "optout Codfish documentation extraction route is verified by buttons install flow" }
  , RouteOptout { routeOptoutOption = "--record-install", routeOptoutReason = "records the install phase fingerprint after install sub-batch passes" }
  , RouteOptout { routeOptoutOption = "--record-test", routeOptoutReason = "records the test phase fingerprint after test sub-batch passes" }
  , RouteOptout { routeOptoutOption = "--record-documentation", routeOptoutReason = "records the documentation phase fingerprint after documentation sub-batch passes" }
  , RouteOptout { routeOptoutOption = "--record-save", routeOptoutReason = "records the save phase fingerprint after documentation/test sub-batch passes" }
  , RouteOptout { routeOptoutOption = "--record-verification", routeOptoutReason = "records the buttonized cog pass fingerprint after tests pass" }
  , RouteOptout { routeOptoutOption = "--verification-status", routeOptoutReason = "cheap status route checks whether recorded cog pass is still current" }
  , RouteOptout { routeOptoutOption = "--stage-status", routeOptoutReason = "cheap read-only status route checks whether a recorded stage stamp is current" }
  , RouteOptout { routeOptoutOption = "--versioning-push", routeOptoutReason = "optout version store not implemented yet" }
  , RouteOptout { routeOptoutOption = "--ship-bin", routeOptoutReason = "optout shipped-bin replacement requires later runtime integration" }
  , RouteOptout { routeOptoutOption = "--create-hello-project", routeOptoutReason = "materializes a new hello-style project tree from Wires project layout data" }
  , RouteOptout { routeOptoutOption = "--advance-gofur-wires", routeOptoutReason = "advances a primitive Garrage/Gofur package into Wires descriptors before compile/cast" }
  , RouteOptout { routeOptoutOption = "--save-versions", routeOptoutReason = "creates a versions/ timestamped snapshot of the repo via scripts/save_wires.hs" }
  , RouteOptout { routeOptoutOption = "--compact-gofur", routeOptoutReason = "compacts the root stage marker and package descriptors down to Gofur form without deleting cog/source artefacts" }
  , RouteOptout { routeOptoutOption = "--compact-garrage", routeOptoutReason = "compacts through Gofur down to Garrage form while preserving package.nut and precog-bearing source/cog artefacts" }
  ]

go :: String -> [String] -> IO String
go "--list" [] = pure (show ["--list", "--check", "--object-check", "--generate-buttons", "--advance-gofur-wires", "--record-save", "--save-versions"])
go "--list" _ = pure "--list expects no arguments"
go "--make" _ = pure "wires make placeholder"
go "--check" [root] = formatCheckResult <$> runCheck root
go "--check" [root, _pkg] = formatCheckResult <$> runCheck root
go "--check" _ = pure "usage: wires.exe --check <wires-root> [<package-relative-path>]"
go "--object-check" [root] = formatObjectIntegrity <$> checkWiresObjectIntegrity root
go "--object-check" [root, _pkg] = formatObjectIntegrity <$> checkWiresObjectIntegrity root
go "--object-check" _ = pure "usage: wires.exe --object-check <wires-root> [<package-relative-path>]"
go "--compile-wires" [root] = compileWiresRoot root
go "--compile-wires" [root, _pkg] = compileWiresRoot root
go "--compile-wires" _ = pure "usage: wires.exe --compile-wires <wires-root> [<package-relative-path>]"
go "--cast" [root] = castWiresRoot root
go "--cast" [root, _pkg] = castWiresRoot root
go "--cast" _ = pure "usage: wires.exe --cast <wires-root> [<package-relative-path>]"
go "--convert" [root, pkg] = convertAuto root pkg
go "--convert" _ = pure "usage: wires.exe --convert <wires-root> <package-relative-path>"
go "--convert-again" [root, pkg] = convertAuto root pkg
go "--convert-again" _ = pure "usage: wires.exe --convert-again <wires-root> <package-relative-path>"
go "--halt-project-bin" [root] = haltProjectBins root
go "--halt-project-bin" [root, pkg] = haltSingleProjectBin root pkg
go "--halt-project-bin" _ = pure "usage: wires.exe --halt-project-bin <wires-root> [<package-relative-path>]"
go "--clean-project-bin" [root] = cleanProjectBins root
go "--clean-project-bin" [root, pkg] = cleanSingleProjectBin root pkg
go "--clean-project-bin" _ = pure "usage: wires.exe --clean-project-bin <wires-root> [<package-relative-path>]"
go "--cabal-install" [root] = cabalInstallProjectBins root
go "--cabal-install" [root, pkg] = cabalInstallSingleProjectBin root pkg
go "--cabal-install" _ = pure "usage: wires.exe --cabal-install <wires-root> [<package-relative-path>]"
go "--test" [root] = cabalTestProjectBins root
go "--test" [root, pkg] = cabalTestSingleProject root pkg
go "--test" _ = pure "usage: wires.exe --test <wires-root> [<package-relative-path>]"
go "--haddock" [root, pkg] = cabalHaddockSingleProject root pkg
go "--haddock" _ = pure "usage: wires.exe --haddock <wires-root> <package-relative-path>"
go "--codfish" [root, pkg] = codfishSingleProject root pkg
go "--codfish" _ = pure "usage: wires.exe --codfish <wires-root> <package-relative-path>"
go "--record-install" [root, pkg] = recordInstallSingleProject root pkg
go "--record-install" _ = pure "usage: wires.exe --record-install <wires-root> <package-relative-path>"
go "--record-test" [root, pkg] = recordTestSingleProject root pkg
go "--record-test" _ = pure "usage: wires.exe --record-test <wires-root> <package-relative-path>"
go "--record-documentation" [root, pkg] = recordDocumentationSingleProject root pkg
go "--record-documentation" _ = pure "usage: wires.exe --record-documentation <wires-root> <package-relative-path>"
go "--record-save" [root, pkg] = recordSaveSingleProject root pkg
go "--record-save" _ = pure "usage: wires.exe --record-save <wires-root> <package-relative-path>"
go "--record-verification" [root] = recordVerificationStamp root
go "--record-verification" [root, pkg] = recordVerificationSingleProject root pkg
go "--record-verification" _ = pure "usage: wires.exe --record-verification <wires-root> [<package-relative-path>]"
go "--verification-status" [root] = verificationStatus root
go "--verification-status" [root, pkg] = verificationStatusSingleProject root pkg
go "--verification-status" _ = pure "usage: wires.exe --verification-status <wires-root> [<package-relative-path>]"
go "--stage-status" [root, stampName, pkg] = stageStatus root stampName pkg
go "--stage-status" _ = pure "usage: wires.exe --stage-status <wires-root> <stamp-name> <package-relative-path>"
go "--ensure-verified" [root, pkg] = ensureProjectVerified root pkg
go "--ensure-verified" _ = pure "usage: wires.exe --ensure-verified <wires-root> <package-relative-path>"
go "--prepare-verification" [root, pkg] = prepareProjectVerification root pkg
go "--prepare-verification" _ = pure "usage: wires.exe --prepare-verification <wires-root> <package-relative-path>"
go "--clean-verification" [root, pkg] = cleanProjectVerification root pkg
go "--clean-verification" _ = pure "usage: wires.exe --clean-verification <wires-root> <package-relative-path>"
go "--generate-buttons" [root] = generateWireButtons root
go "--generate-buttons" [root, mode] = generateWireButtonsWithMode root mode
go "--generate-buttons" _ = pure "usage: wires.exe --generate-buttons <wires-root> [--dont-exclude-bootstrap|--bootstrap-only]"
go "--create-hello-project" [root, projectName] = createHelloProject root projectName
go "--create-hello-project" _ = pure "usage: wires.exe --create-hello-project <wires-root> <project-name>"
go "create" [root, projectName] = createHelloProject root projectName
go "create" _ = pure "usage: wires.exe create <wires-root> <project-name>"
go "--advance-gofur-wires" [root, pkg] = advanceGofurPackageToWires root pkg
go "--advance-gofur-wires" _ = pure "usage: wires.exe --advance-gofur-wires <wires-root> <package-relative-path>"
go "--compact-gofur" [root] = compactRootToGofur root
go "--compact-gofur" _ = pure "usage: wires.exe --compact-gofur <wires-root>"
go "--compact-garrage" [root] = compactRootToGarrage root
go "--compact-garrage" _ = pure "usage: wires.exe --compact-garrage <wires-root>"
go "--save-versions" [root] = saveRepoVersions root Nothing
go "--save-versions" [root, name] = saveRepoVersions root (Just name)
go "--save-versions" _ = pure "usage: wires.exe --save-versions <wires-root> [<save-name>]"
go "--versioning-push" _ = pure "wires versioning-push placeholder"
go "--ship-bin" _ = pure "wires ship-bin placeholder"
go "unregister" [root, projectName] = Unregister.unregisterProject root projectName
go "unregister" _ = pure "usage: wires unregister <wires-root> <project-name>   (legacy project-name path)"
go "--unregister" [root, projectName] = Unregister.unregisterProject root projectName
go "--unregister" _ = pure "usage: wires.exe --unregister <wires-root> <project-name>   (legacy)"

go "unregister-package" [root, pkgRel] = Unregister.unregisterPackage root pkgRel
go "unregister-package" _ = pure "usage: wires unregister-package <wires-root> <package-relative>   (exact, e.g. aws-host/aws-host)"
go "--unregister-package" [root, pkgRel] = Unregister.unregisterPackage root pkgRel
go "--unregister-package" _ = pure "usage: wires.exe --unregister-package <wires-root> <package-relative>   (exact)"

go "purge-package" [root, pkgRel] = Unregister.purgePackageRegistration root pkgRel
go "purge-package" _ = pure "usage: wires purge-package <wires-root> <package-relative>   (force remove lines only, for recovery)"
go "--purge-package" [root, pkgRel] = Unregister.purgePackageRegistration root pkgRel
go "--purge-package" _ = pure "usage: wires.exe --purge-package <wires-root> <package-relative>   (force remove lines only)"

go "remove-top-level" [root, top] = Unregister.removeTopLevelProject root top
go "remove-top-level" _ = pure "usage: wires remove-top-level <wires-root> <top-level-name>"
go "--remove-top-level" [root, top] = Unregister.removeTopLevelProject root top
go "--remove-top-level" _ = pure "usage: wires.exe --remove-top-level <wires-root> <top-level-name>"
go option _ = pure ("unknown wires option: " ++ option)
