{-|
Module: Wires.Versioning

Purpose:
	Describe versioning and snapshot policies for the wires workspace.
	This module records the intended semantics for version policy
	fields found in `.wire` and `.nut` descriptors and explains how
	snapshots are generated and stamped during the install/verify
	flow.

Implementation note:
	Concrete snapshot creation lives outside this doc module; the goal
	here is to centralise the policy text so maintainers can update
	versioning rules in one location.
-}
module Wires.Versioning where

