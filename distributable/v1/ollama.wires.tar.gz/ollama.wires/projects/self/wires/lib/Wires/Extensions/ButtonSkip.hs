module Wires.Extensions.ButtonSkip where

newtype ButtonSkipFile = ButtonSkipFile { buttonSkipText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".button.skip"

parseButtonSkip :: String -> Either String ButtonSkipFile
parseButtonSkip = Right . ButtonSkipFile

renderButtonSkip :: ButtonSkipFile -> String
renderButtonSkip = buttonSkipText

validateButtonSkip :: ButtonSkipFile -> Either String ()
validateButtonSkip _ = Right ()

