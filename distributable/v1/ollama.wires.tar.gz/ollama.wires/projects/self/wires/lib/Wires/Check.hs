{-|
Module: Wires.Check

Purpose:
  Static validation of the wires workspace structure and package
  descriptors. `Wires.Check` performs lightweight syntactic and
  structural checks on `.nut`, `.bolt`, `.cog` files and Haskell
  sources to ensure generated packages will build and that
  implementation routes are present and correctly declared.

Role in UI flow:
  - The buttons flow invokes `runCheck` before compilation to
    surface clear, actionable errors to the user.
  - `formatCheckResult` produces the canonical textual output that
    cog tests assert on (for example, "wires structural check ok").

Notes:
  - The check suite prefers explicit, human-friendly messages over
    machine-parsable codes; the UI displays these lines directly.
-}
module Wires.Check where

import Control.Monad
import Data.Char
import Data.List
import qualified Folders.Routes as Routes
import System.Directory
import System.FilePath
import qualified Wires.Object as Object

data CheckReport =
  CheckReport
    { reportRoot :: FilePath
    , reportPackages :: [PackageCheck]
    }
  deriving (Eq, Show)

data PackageCheck =
  PackageCheck
    { packagePath :: FilePath
    , packageName :: String
    , packageModules :: [HsHeader]
    , packageOptions :: [String]
    , packageRouteOptouts :: [String]
    }
  deriving (Eq, Show)

data HsHeader =
  HsHeader
    { headerFile :: FilePath
    , headerModule :: String
    , headerImports :: [String]
    , headerText :: String
    }
  deriving (Eq, Show)

data PackageFiles =
  PackageFiles
    { packageDir :: FilePath
    , packageBase :: String
    , nutPath :: FilePath
    , boltPath :: FilePath
    , cogPath :: FilePath
    }
  deriving (Eq, Show)

-- | Run the full check pipeline for a wires root. Returns either a
-- list of human-readable errors or a `CheckReport` describing the
-- discovered packages and modules.
runCheck :: FilePath -> IO (Either [String] CheckReport)
runCheck root = do
  absoluteRoot <- makeAbsolute root
  rootErrors <- checkRoot absoluteRoot
  packagePaths <- readWireProjectPackages (absoluteRoot </> "projects" </> "wire.project")
  packageResults <- mapM (checkPackage absoluteRoot) packagePaths
  let packageErrors = concatMap collectErrors packageResults
      packages = collectPackages packageResults
      allHeaders = concatMap packageModules packages
      allModuleNames = map headerModule allHeaders
      globalImportErrors = checkLocalImports allModuleNames allHeaders
      errors = rootErrors ++ packageErrors ++ globalImportErrors
  if null errors
    then return (Right (CheckReport absoluteRoot packages))
    else return (Left errors)

formatCheckResult :: Either [String] CheckReport -> String
formatCheckResult result =
  case result of
    Left errors ->
      unlines ("wires check failed:" : map ("- " ++) errors)
    Right report ->
      unlines
        ( [ "wires structural check ok"
          , "root: " ++ reportRoot report
          , "packages: " ++ show (length (reportPackages report))
          ]
        ++ concatMap formatPackage (reportPackages report)
        )

formatPackage :: PackageCheck -> [String]
formatPackage package =
  [ "package: " ++ packagePath package
  , "  modules: " ++ intercalate ", " (map headerModule (packageModules package))
  , "  options: " ++ intercalate ", " (packageOptions package)
  , "  route optouts: " ++ intercalate ", " (packageRouteOptouts package)
  ]

checkRoot :: FilePath -> IO [String]
checkRoot root = do
  rootExists <- doesDirectoryExist root
  wireFiles <- if rootExists then fmap concat (mapM (listExtension root) Object.rootMetadataExtensions) else return []
  wireMetadataResult <- if rootExists then Object.readWireMetadata root else return (Left [])
  let projectsFile = root </> "projects" </> "wire.project"
  projectsExists <- doesFileExist projectsFile
  requiredFileResults <- mapM (\path -> doesFileExist (root </> path)) requiredRootFiles
  requiredDirResults <- mapM (\path -> doesDirectoryExist (root </> path)) requiredRootDirs
  return $
    concat
      [ ["root does not exist: " ++ root | not rootExists]
      , ["expected exactly one root stage file (.garrage, .gofur, or .wire), found " ++ show (length wireFiles) | rootExists && length wireFiles /= 1]
      , Object.collectErrors wireMetadataResult
      , ["missing projects/wire.project" | not projectsExists]
      , ["missing root file: " ++ path | (path, exists) <- zip requiredRootFiles requiredFileResults, not exists]
      , ["missing root directory: " ++ path | (path, exists) <- zip requiredRootDirs requiredDirResults, not exists]
      ]

requiredRootFiles :: [FilePath]
requiredRootFiles =
  [ "installer.bat"
  , "installer.sh"
  , "onepush.bat"
  , "onepush.sh"
  , "uninstaller.bat"
  , "uninstaller.sh"
  ]

requiredRootDirs :: [FilePath]
requiredRootDirs =
  [ "projects"
  , ".build"
  , ".install"
  , ".test"
  , ".document"
  ]

readWireProjectPackages :: FilePath -> IO [FilePath]
readWireProjectPackages path = do
  exists <- doesFileExist path
  if not exists
    then return []
    else do
      text <- readFile path
      return (parseIndentedList "packages:" text)

checkPackage :: FilePath -> FilePath -> IO (Either [String] PackageCheck)
checkPackage root relativePath = do
  let dir = root </> "projects" </> normalise relativePath
  packageExists <- doesDirectoryExist dir
  if not packageExists
    then return (Left ["package path does not exist: " ++ relativePath])
    else do
      descriptorResult <- findPackageFiles dir
      case descriptorResult of
        Left errors -> return (Left errors)
        Right packageFiles -> checkPackageFiles relativePath packageFiles

checkPackageFiles :: FilePath -> PackageFiles -> IO (Either [String] PackageCheck)
checkPackageFiles relativePath packageFiles = do
  nutText <- readFile (nutPath packageFiles)
  boltText <- readFile (boltPath packageFiles)
  cogText <- readFile (cogPath packageFiles)
  sourceDirs <- libraryHsSourceDirs packageFiles
  hsFiles <- fmap concat (mapM (findHsFiles . (packageDir packageFiles </>)) sourceDirs)
  headerResults <- mapM readHsHeader hsFiles
  routeResult <-
    case parseField "go-is:" nutText of
      Just target -> Object.readRoutesForGoTarget (packageDir packageFiles) target
      Nothing -> return (Left ["missing go-is, cannot read implementation routes"])
  let headerErrors = concatMap collectErrors headerResults
      routeErrors = Object.collectErrors routeResult
      headers = collectHeaders headerResults
      moduleNames = map headerModule headers
      exposedModules = parseIndentedList "exposes:" nutText
      goTarget = parseField "go-is:" nutText
      boltOptions = routeOptions routeResult
      routeOptoutValues = routeOptouts routeResult
      exposedErrors = ["exposed module missing from source: " ++ value | value <- exposedModules, value `notElem` moduleNames]
      goErrors = checkGoTarget packageFiles headers goTarget
      optionErrors = checkOptions routeResult
      cogErrors = checkCogTestSuiteDeclaration cogText
      boltErrors = checkBoltExecutableDeclaration boltText
      errors = headerErrors ++ routeErrors ++ exposedErrors ++ goErrors ++ optionErrors ++ cogErrors ++ boltErrors
  if null errors
    then return (Right (PackageCheck relativePath (packageBase packageFiles) headers boltOptions routeOptoutValues))
    else return (Left (map ((relativePath ++ ": ") ++) errors))

routeOptions :: Either [String] ([Routes.VerifiedRoute], [Routes.RouteOptout]) -> [String]
routeOptions result =
  case result of
    Right (routes, optouts) -> map Routes.routeOption routes ++ map Routes.routeOptoutOption optouts
    Left _ -> []

routeOptouts :: Either [String] ([Routes.VerifiedRoute], [Routes.RouteOptout]) -> [String]
routeOptouts result =
  case result of
    Right (_, optouts) -> map Routes.routeOptoutOption optouts
    Left _ -> []

checkCogTestSuiteDeclaration :: String -> [String]
checkCogTestSuiteDeclaration text =
  concat
    [ [".cog should not contain implementation precogs; keep them with the go routes" | sectionPresent "precogs:" text]
    , [".cog should not contain route optouts; keep them with the go routes" | sectionPresent "optout:" text]
    , [".cog missing generated test-suite field: test-suite" | parseField "test-suite:" text == Nothing]
    , [".cog missing generated test-suite field: type" | parseField "type:" text == Nothing]
    , [".cog missing generated test-suite field: main-is" | parseField "main-is:" text == Nothing]
    , [".cog missing generated test-suite section: source-dirs" | null (parseIndentedList "source-dirs:" text)]
    ]

checkBoltExecutableDeclaration :: String -> [String]
checkBoltExecutableDeclaration text =
  [".bolt should not contain go options; keep verified routes with the go implementation" | sectionPresent "options:" text]

findPackageFiles :: FilePath -> IO (Either [String] PackageFiles)
findPackageFiles dir = do
  nutFiles <- listExtension dir ".nut"
  boltFiles <- listExtension dir ".bolt"
  cogFiles <- listExtension dir ".cog"
  let errors =
        concat
          [ ["expected exactly one .nut file, found " ++ show (length nutFiles) | length nutFiles /= 1]
          , ["expected exactly one .bolt file, found " ++ show (length boltFiles) | length boltFiles /= 1]
          , ["expected exactly one .cog file, found " ++ show (length cogFiles) | length cogFiles /= 1]
          ]
  if null errors
    then do
      let nutFile = head nutFiles
          base = dropExtension (takeFileName nutFile)
      return (Right (PackageFiles dir base nutFile (head boltFiles) (head cogFiles)))
    else return (Left (map ((normalise dir ++ ": ") ++) errors))

findHsFiles :: FilePath -> IO [FilePath]
findHsFiles dir = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      fmap concat $
        forM entries $ \entry -> do
          let path = dir </> entry
          isDir <- doesDirectoryExist path
          isFile <- doesFileExist path
          if isDir
            then findHsFiles path
            else return [path | isFile && takeExtension path == ".hs"]

libraryHsSourceDirs :: PackageFiles -> IO [FilePath]
libraryHsSourceDirs packageFiles = do
  cabalFiles <- listExtension (packageDir packageFiles) ".cabal"
  case cabalFiles of
    [] -> return ["lib"]
    cabalFile:_ -> do
      text <- readFile cabalFile
      let dirs = parseLibraryHsSourceDirs text
      return (if null dirs then ["lib"] else dirs)

parseLibraryHsSourceDirs :: String -> [FilePath]
parseLibraryHsSourceDirs text =
  let libraryLines =
        case dropWhile ((/= "library") . trim) (lines text) of
          [] -> []
          _:rest -> takeWhile (not . isCabalStanzaHeader) rest
  in case dropWhile (not . ("hs-source-dirs:" `isPrefixOf`) . trim) libraryLines of
       [] -> []
       line:rest ->
         parseCabalListValues
           (dropFieldValue line : takeWhile isCabalFieldContinuation rest)

isCabalStanzaHeader :: String -> Bool
isCabalStanzaHeader line =
  let value = trim line
  in not (null value)
       && safeHead line == safeHead value
       && any (`isPrefixOf` value) ["executable ", "test-suite ", "benchmark ", "foreign-library "]

isCabalFieldContinuation :: String -> Bool
isCabalFieldContinuation line =
  let value = trim line
  in not (null value)
       && ':' `notElem` value
       && (isSpace (safeHead line) || "," `isPrefixOf` value)

dropFieldValue :: String -> String
dropFieldValue line =
  case dropWhile (/= ':') line of
    ':':value -> value
    _ -> ""

parseCabalListValues :: [String] -> [String]
parseCabalListValues values =
  filter (not . null) (words (map commaToSpace (unwords (map trim values))))
  where
    commaToSpace char
      | char == ',' = ' '
      | otherwise = char

readHsHeader :: FilePath -> IO (Either [String] HsHeader)
readHsHeader path = do
  text <- readFile path
  return (parseHsHeader path text)

parseHsHeader :: FilePath -> String -> Either [String] HsHeader
parseHsHeader path text =
  let numbered = zip [1 :: Int ..] (lines text)
      languageErrors = concatMap checkLanguagePragma numbered
      -- Drop a leading Haddock block or initial line comments so that
      -- documentation headers like "Module: Foo" do not get misinterpreted
      -- as real `module` declarations by naive scanners.
      contentLines = dropLeadingHeader (lines text)
      numberedContent = zip [1 :: Int ..] contentLines
      moduleLines = [(n, trim line) | (n, line) <- numberedContent, "module " `isPrefixOf` trim line]
      importLines = [(n, trim line) | (n, line) <- numbered, "import " `isPrefixOf` trim line]
      moduleErrors = checkModuleLines moduleLines
      importErrors = concatMap checkImportLine importLines
      moduleName = case moduleLines of
        [(_, line)] -> parseModuleName line
        _ -> ""
      imports = map (parseImportModule . snd) importLines
      errors = languageErrors ++ moduleErrors ++ importErrors
  in if null errors
       then Right (HsHeader path moduleName imports text)
       else Left (map ((normalise path ++ ": ") ++) errors)

checkLanguagePragma :: (Int, String) -> [String]
checkLanguagePragma (lineNumber, line)
  | "{-# LANGUAGE" `isPrefixOf` trim line && "#-}" `notElem` words line =
      ["line " ++ show lineNumber ++ ": multiline LANGUAGE pragmas are not supported"]
  | otherwise = []

checkModuleLines :: [(Int, String)] -> [String]
checkModuleLines moduleLines =
  case moduleLines of
    [] -> ["missing module declaration"]
    [(_, line)]
      | null (parseModuleName line) -> ["module declaration is missing a module name"]
      | otherwise -> []
    _ -> ["multiple module declarations found"]

parseModuleName :: String -> String
parseModuleName line =
  takeWhile (\c -> isAlphaNum c || c == '.' || c == '_') (dropWhile isSpace (drop 6 line))

stripSuffixLocal :: String -> String -> Maybe String
stripSuffixLocal suffix value =
  let reversedSuffix = reverse suffix
      reversedValue = reverse value
  in case stripPrefix reversedSuffix reversedValue of
       Just rest -> Just (reverse rest)
       Nothing -> Nothing

checkImportLine :: (Int, String) -> [String]
checkImportLine _ =
  []

parseImportModule :: String -> String
parseImportModule line =
  let tokens = words line
      afterImport = drop 1 tokens
      afterQualified = case afterImport of
        "qualified":rest -> rest
        rest -> rest
  in case afterQualified of
       [] -> ""
       name:_ -> name

checkLocalImports :: [String] -> [HsHeader] -> [String]
checkLocalImports moduleNames headers =
  [ "import does not resolve locally: " ++ headerModule header ++ " imports " ++ imported
  | header <- headers
  , imported <- headerImports header
  , imported `notElem` moduleNames
  , not (isBaseImport imported)
  ]

isBaseImport :: String -> Bool
isBaseImport name =
  any (`isPrefixOf` name)
    [ "Control."
    , "Data."
    , "Folders."
    , "Gofur."
    , "Network."
    , "System."
    , "Prelude"
    ]

checkGoTarget :: PackageFiles -> [HsHeader] -> Maybe String -> [String]
checkGoTarget packageFiles headers goTarget =
  case goTarget of
    Nothing -> ["missing go-is in " ++ takeFileName (nutPath packageFiles)]
    Just target ->
      case splitGoTarget target of
        (moduleName, '.':functionName)
          | null moduleName || null functionName -> ["invalid go-is target: " ++ target]
          | otherwise ->
              let matching = filter ((== moduleName) . headerModule) headers
              in case matching of
                   [] -> ["go-is module missing from source: " ++ moduleName]
                   header:_ -> checkFunctionExists header functionName
        _ -> ["go-is must look like Module.function, got: " ++ target]

splitGoTarget :: String -> (String, String)
splitGoTarget target =
  let reversed = reverse target
  in case break (== '.') reversed of
       (_, []) -> (target, "")
       (functionName, '.':moduleName) -> (reverse moduleName, '.':reverse functionName)
       _ -> (target, "")

checkFunctionExists :: HsHeader -> String -> [String]
checkFunctionExists header functionName =
  let text = headerText header
      candidates = [functionName ++ " ::", functionName ++ " "]
  in if any (`isInfixOf` text) candidates
       then []
       else ["go-is function missing in " ++ normalise (headerFile header) ++ ": " ++ functionName]

checkOptions :: Either [String] ([Routes.VerifiedRoute], [Routes.RouteOptout]) -> [String]
checkOptions routeResult =
  case routeResult of
    Left _ -> []
    Right (routes, optouts) ->
      let routeNames = map Routes.routeOption routes
          optoutNames = map Routes.routeOptoutOption optouts
      in checkRouteNames routeNames optoutNames

checkRouteNames :: [String] -> [String] -> [String]
checkRouteNames routeNames optoutNames =
  concat
    [ ["route option cannot be both verified and opted out: " ++ option | option <- routeNames, option `elem` optoutNames]
    , ["duplicate verified route option: " ++ option | option <- duplicates routeNames]
    , ["duplicate route optout option: " ++ option | option <- duplicates optoutNames]
    ]

duplicates :: [String] -> [String]
duplicates values =
  nub [value | value <- values, length (filter (== value) values) > 1]

parseField :: String -> String -> Maybe String
parseField key text =
  case [trim (drop (length key) line) | line <- lines text, key `isPrefixOf` trim line] of
    value:_ | not (null value) -> Just value
    _ -> Nothing

parseIndentedList :: String -> String -> [String]
parseIndentedList key text =
  let ls = lines text
      rest = dropWhile (not . (key `isPrefixOf`) . trim) ls
  in case rest of
       [] -> []
       _:items -> map trimListItem (takeWhile isListItem items)

isListItem :: String -> Bool
isListItem line =
  let value = trim line
  in not (null value) && not (":" `isSuffixOf` value) && (isSpace (safeHead line) || "-" `isPrefixOf` value)

trimListItem :: String -> String
trimListItem line =
  let value = trim line
  in if "- " `isPrefixOf` value
       then trim (drop 2 value)
       else value

sectionPresent :: String -> String -> Bool
sectionPresent section text =
  any ((section `isPrefixOf`) . trim) (lines text)

sectionLines :: String -> String -> [String]
sectionLines section text =
  let rest = drop 1 (dropWhile (not . (section `isPrefixOf`) . trim) (lines text))
  in takeWhile (not . isSectionHeader) rest

isSectionHeader :: String -> Bool
isSectionHeader line =
  let value = trim line
  in not (null value) && ":" `isSuffixOf` value && not (isSpace (safeHead line))

stripTrailingColon :: String -> String
stripTrailingColon value =
  case reverse value of
    ':':rest -> reverse rest
    _ -> value

listExtension :: FilePath -> String -> IO [FilePath]
listExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      return [dir </> entry | entry <- entries, takeExtension entry == extension]

collectErrors :: Either [String] a -> [String]
collectErrors value =
  case value of
    Left errors -> errors
    Right _ -> []

collectPackages :: [Either [String] PackageCheck] -> [PackageCheck]
collectPackages values =
  [package | Right package <- values]

collectHeaders :: [Either [String] HsHeader] -> [HsHeader]
collectHeaders values =
  [header | Right header <- values]

safeHead :: String -> Char
safeHead value =
  case value of
    [] -> ' '
    c:_ -> c

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile isSpace

-- | Drop a leading Haddock block ("{-| ... -}") or initial line
-- comments so documentation headers don't confuse simple scanners
-- that look for lines beginning with "module ". This is intentionally
-- conservative and only affects the very start of the file.
dropLeadingHeader :: [String] -> [String]
dropLeadingHeader [] = []
dropLeadingHeader (l:ls)
  | "{-|" `isPrefixOf` trim l = dropAfterBlock ls
  | "--" `isPrefixOf` trim l = dropLeadingHeader ls
  | otherwise = l : ls
  where
    dropAfterBlock [] = []
    dropAfterBlock (x:xs)
      | "-}" `isInfixOf` x = xs
      | otherwise = dropAfterBlock xs
