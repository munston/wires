module Wires.GofurAdvance where

import System.Directory
import System.FilePath
import qualified Garrage
import qualified Garrage.Descriptor as Descriptor
import qualified Gofur.Install as GofurInstall
import qualified Gofur.Codegen as Codegen

advanceGofurPackageToWires :: FilePath -> FilePath -> IO String
advanceGofurPackageToWires root packageRelative = do
  let packageDir = root </> "projects" </> normalise packageRelative
      packageName = takeFileName packageDir
      garragePath = packageDir </> "package.garrage"
      nutPath = packageDir </> "package.nut"
      boltPath = packageDir </> "package.bolt"
      cogPath = packageDir </> "package.cog"
  exists <- doesDirectoryExist packageDir
  if not exists
    then return ("wires gofur advance skipped: package path missing: " ++ packageRelative)
    else do
        -- Delegate to stage-owned advances in order.
        _ <- Garrage.advanceToNut root packageRelative
        _ <- GofurInstall.advanceToBolt root packageRelative
        _ <- ensureBoltFromNut root packageRelative
        cogResult <- advanceToCog root packageRelative
        return (unlines ["wires gofur advance ok", "package: " ++ packageRelative, cogResult])

readOrCreateNut :: FilePath -> FilePath -> IO String
readOrCreateNut garragePath nutPath = do
  nutExists <- doesFileExist nutPath
  if nutExists
    then readFileStrict nutPath
    else do
      garrageExists <- doesFileExist garragePath
      if not garrageExists
        then fail ("missing package.nut and package.garrage beside " ++ nutPath)
        else do
          garrageText <- readFileStrict garragePath
          return (Garrage.garrageToNut garrageText)

readFileStrict :: FilePath -> IO String
readFileStrict path = do
  text <- readFile path
  length text `seq` return text

renderCog :: String -> String
renderCog packageName =
  unlines
    [ "test-suite: " ++ Descriptor.cabalPackageName packageName ++ "-cog"
    , "type: exitcode-stdio-1.0"
    , "main-is: CogMain.hs"
    , "source-dirs:"
    , "  cog"
    , "depends:"
    ]

renderBolt :: [String] -> String
renderBolt depends =
  unlines ("depends:" : map ("  " ++) depends)

ensureBoltFromNut :: FilePath -> FilePath -> IO String
ensureBoltFromNut root packageRelative = do
  let packageDir = root </> "projects" </> normalise packageRelative
      nutPath = packageDir </> "package.nut"
      boltPath = packageDir </> "package.bolt"
      exeDir = packageDir </> "exe"
      packageName = takeFileName packageDir
  boltExists <- doesFileExist boltPath
  if boltExists
    then return ("wires kept existing package.bolt for " ++ packageRelative)
    else do
      nutExists <- doesFileExist nutPath
      if not nutExists
        then return ("wires skipped bolt: no package.nut for " ++ packageRelative)
        else do
          nutText <- readFileStrict nutPath
          case Descriptor.parseField "go-is:" nutText of
            Nothing ->
              return ("wires skipped bolt: no go-is in package.nut for " ++ packageRelative)
            Just goTarget -> do
              let target = Descriptor.splitGoTarget goTarget
                  moduleName = Descriptor.goTargetModule target
              createDirectoryIfMissing True exeDir
              writeFile (exeDir </> "Main.hs") (Codegen.renderGoMain moduleName False)
              writeFile boltPath (renderBolt [packageName])
              return ("wires wrote package.bolt and exe/Main.hs for " ++ packageRelative)

advanceToCog :: FilePath -> FilePath -> IO String
advanceToCog root packageRelative = do
  let packageDir = root </> "projects" </> normalise packageRelative
      boltPath = packageDir </> "package.bolt"
      cogDir = packageDir </> "cog"
      cogMain = cogDir </> "CogMain.hs"
      packageName = takeFileName packageDir
      cogPath = packageDir </> "package.cog"
  boltExists <- doesFileExist boltPath
  if not boltExists
    then return ("wires skipped cog: no package.bolt for " ++ packageRelative)
    else do
      createDirectoryIfMissing True cogDir
      writeFile cogMain (Codegen.renderCogMain packageName [] [])
      writeFile cogPath (renderCog packageName)
      return (unlines ["nut/built to cog for: " ++ packageRelative, "cog: " ++ takeFileName cogPath, "cogMain: " ++ takeFileName cogMain])
