module Wires.Alive where

import Gofur.Alive
