module Wires.Extensions.Hs where

newtype HsFile = HsFile { hsText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".hs"

parseHs :: String -> Either String HsFile
parseHs = Right . HsFile

renderHs :: HsFile -> String
renderHs = hsText

validateHsHeader :: HsFile -> Either String ()
validateHsHeader _ = Right ()

