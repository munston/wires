{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE RecordWildCards #-}

module Wires.Extensions.GofurCompat where

-- Provide a `WiresRep` data-instance implementation for the
-- `Gofur` data families so `wires` can import `gofur` and present an
-- extended representation that captures wires-specific descriptors.

import GHC.Generics
import System.FilePath

import qualified Gofur.Object as G
import Wires.Object

-- Marker type for the Wires representation
data WiresRep

-- Instances of the Gofur families for Wires-style projects
instance G.Gofur WiresRep where
  data GofurObject WiresRep = GofurObjectW
    { gofurWRoot :: FilePath
    , gofurWMetadata :: G.GofurMetadata WiresRep
    , gofurWProject :: G.GofurProject WiresRep
    , gofurWPackages :: [G.GofurPackage WiresRep]
    } deriving (Eq, Read, Show, Generic)

  data GofurMetadata WiresRep = GofurMetadataW
    { gofurWMetadataFile :: FilePath
    , gofurWName :: String
    , gofurWAuthor :: Maybe String
    , gofurWProjectsFolder :: FilePath
    , gofurWBinFolder :: FilePath
    , gofurWEntry :: FilePath
    , gofurWVersionPolicy :: Maybe String
    , gofurWSnapshotPolicy :: Maybe String
    } deriving (Eq, Read, Show, Generic)

  data GofurProject WiresRep = GofurProjectW
    { gofurWProjectFile :: FilePath
    , gofurWProjectPackages :: [FilePath]
    , gofurWProjectBootstrapPackages :: [FilePath]
    } deriving (Eq, Read, Show, Generic)

  data GofurPackage WiresRep = GofurPackageW
    { gofurWPackagePath :: FilePath
    , gofurWPackageName :: String
    , gofurWPackageNut :: Nut
    , gofurWPackageBolt :: Bolt
    , gofurWPackageCog :: Cog
    , gofurWPackageModules :: [HsModule]
    } deriving (Eq, Read, Show, Generic)

  mkGofurObject root meta proj pkgs = GofurObjectW root meta proj pkgs
  mkGofurMetadata file name author projectsFolder binFolder entry versionPolicy snapshotPolicy =
    GofurMetadataW file name author projectsFolder binFolder entry versionPolicy snapshotPolicy
  mkGofurProject file pkgs bootstrap = GofurProjectW file pkgs bootstrap

-- Conversion helpers: map wires objects into the `Gofur` WiresRep
gofurFromWiresObject :: WiresObject -> G.GofurObject WiresRep
gofurFromWiresObject WiresObject{..} =
  GofurObjectW
    wiresRoot
    (gofurMetadataFromWire wiresMetadata)
    (gofurProjectFromWire wiresProject)
    (map gofurPackageFromWires wiresPackages)

gofurMetadataFromWire :: WireMetadata -> G.GofurMetadata WiresRep
gofurMetadataFromWire WireMetadata{..} =
  GofurMetadataW wireMetadataFile wireName wireAuthor wireProjectsFolder wireBinFolder wireEntry wireVersionPolicy wireSnapshotPolicy

gofurProjectFromWire :: WireProject -> G.GofurProject WiresRep
gofurProjectFromWire WireProject{..} =
  GofurProjectW wireProjectFile wireProjectPackages wireProjectBootstrapPackages

gofurPackageFromWires :: WiresPackage -> G.GofurPackage WiresRep
gofurPackageFromWires WiresPackage{..} =
  GofurPackageW wiresPackagePath wiresPackageName wiresPackageNut wiresPackageBolt wiresPackageCog wiresPackageModules
