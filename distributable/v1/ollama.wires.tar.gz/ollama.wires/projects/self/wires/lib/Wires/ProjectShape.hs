{-# LANGUAGE OverloadedStrings #-}

module Wires.ProjectShape
  ( DirTree(..)
  , PackageShape(..)
  , ProjectShape(..)
  , buildProjectShape
  , buildAllProjectShapes
  , buildNonProjectsTree
  , listAllFilesFromTree
  ) where

import System.Directory
  ( canonicalizePath
  , doesDirectoryExist
  , listDirectory
  )
import System.FilePath
  ( (</>)
  , takeExtension
  , takeDirectory
  , makeRelative
  , splitDirectories
  )
import Control.Monad
import Data.Char
import Data.List
import Data.Function

-- Simple directory tree representation (relative paths)
data DirTree = DirTree
  { dtName     :: FilePath
  , dtChildren :: [DirTree]
  , dtFiles    :: [FilePath]
  } deriving (Eq, Read, Show)

-- Compact package-level shape
data PackageShape = PackageShape
  { psPath    :: FilePath -- ^ package root relative to project
  , psCabal   :: Maybe FilePath
  , psNut     :: Maybe FilePath
  , psBolt    :: Maybe FilePath
  , psCog     :: Maybe FilePath
  , psButtons :: [FilePath]
  , psFiles   :: [FilePath]
  } deriving (Eq, Read, Show)

-- Full project shape
data ProjectShape = ProjectShape
  { prPath     :: FilePath -- ^ project root (absolute)
  , prTree     :: DirTree
  , prPackages :: [PackageShape]
  } deriving (Eq, Read, Show)

-- Excludes used while walking the repo
defaultExcludes :: [FilePath]
defaultExcludes = ["walks","external","dist-newstyle",".git","dist","tmp","build","node_modules","versions","saves"]

-- Recursively list files under a directory while skipping common irrelevant dirs.
listFilesRecursive :: [FilePath] -> FilePath -> IO [FilePath]
listFilesRecursive excludes top = do
  root <- canonicalizePath top
  go root
 where
  go dir = do
    entries <- listDirectory dir
    fmap concat $ forM entries $ \e -> do
      let path = dir </> e
      isDir <- doesDirectoryExist path
      if isDir
        then if (map toLower e) `elem` map (map toLower) excludes && map toLower e /= ".buttons"
               then return []
               else go path
        else return [path]

-- Build a trie-like DirTree from relative file paths
buildDirTreeFromRelPaths :: FilePath -> [FilePath] -> DirTree
buildDirTreeFromRelPaths rootName relPaths =
  let segsList = map splitDirectories relPaths
  in buildNode rootName segsList
  where
    buildNode name segs =
      let filesHere = [ head s | s <- segs, length s == 1 ]
          multis = [ s | s <- segs, length s > 1 ]
          grouped = groupBy ((==) `on` head) (sortOnHead multis)
          children = [ buildNode (head gHead) (map tail g) | g <- grouped, let gHead = head g ]
      in DirTree name children filesHere

    sortOnHead = sortBy (compare `on` head)

-- Helper: list all file paths from DirTree (prefix is relative root)
listAllFilesFromTree :: DirTree -> FilePath -> [FilePath]
listAllFilesFromTree (DirTree name children files) prefix =
  let curPrefix = if null prefix || prefix == "." then name else prefix </> name
      filePaths = [ if null curPrefix || curPrefix == "." then f else curPrefix </> f | f <- files ]
      childPaths = concatMap (\child -> listAllFilesFromTree child (if null curPrefix then "" else curPrefix)) children
  in filePaths ++ childPaths

-- Find package roots by looking for descriptor files under projectDir
findPackageRoots :: FilePath -> [FilePath] -> [FilePath]
findPackageRoots projectDir absFiles =
  let isDescriptor f = let e = map toLower (takeExtension f) in e `elem` [".cabal", ".nut", ".bolt", ".cog"]
      dirs = nub [ takeDirectory f | f <- absFiles, isDescriptor f ]
  in dirs

-- Build PackageShape for a given absolute package dir
buildPackageShape :: FilePath -> FilePath -> [FilePath] -> IO PackageShape
buildPackageShape projectDir pkgDir absFiles = do
  let rel = makeRelative projectDir pkgDir
      filesUnder = [ makeRelative projectDir f | f <- absFiles, let pd = takeDirectory f, pd == pkgDir || (pd \= pkgDir && isSubdirOf pkgDir f) ]
      findExt ext = case [ makeRelative projectDir f | f <- absFiles, map toLower (takeExtension f) == ext, takeDirectory f == pkgDir ] of
                    (x:_) -> Just x
                    _ -> Nothing
      findButtons = [ makeRelative projectDir f | f <- absFiles, ".buttons" `isInPath` f || ".button" `isSuffixOf` map toLower f ]
  return $ PackageShape rel (findExt ".cabal") (findExt ".nut") (findExt ".bolt") (findExt ".cog") findButtons filesUnder

-- Helpers
isSubdirOf :: FilePath -> FilePath -> Bool
isSubdirOf parent child = let rp = splitDirectories parent; rc = splitDirectories child in rp == take (length rp) rc

infix 4 \=
(\=) :: FilePath -> FilePath -> Bool
a \= b = a /= b

isInPath :: String -> FilePath -> Bool
isInPath token p = token `elem` map (map toLower) (splitDirectories p)

-- Build a ProjectShape for a given project directory (name under `projects`)
buildProjectShape :: FilePath -> FilePath -> IO ProjectShape
buildProjectShape repoRoot projectName = do
  repoAbs <- canonicalizePath repoRoot
  let projectDir = repoAbs </> "projects" </> projectName
  exists <- doesDirectoryExist projectDir
  if not exists
    then error $ "project not found: " ++ projectDir
    else do
      absFiles <- listFilesRecursive defaultExcludes projectDir
      let relFiles = map (makeRelative projectDir) absFiles
      let tree = buildDirTreeFromRelPaths "." relFiles
      let pkgDirs = findPackageRoots projectDir absFiles
      pkgShapes <- forM pkgDirs $ \pd -> buildPackageShape projectDir pd absFiles
      return $ ProjectShape projectDir tree pkgShapes

-- Build shapes for all projects under repoRoot/projects
buildAllProjectShapes :: FilePath -> IO [(FilePath, ProjectShape)]
buildAllProjectShapes repoRoot = do
  repoAbs <- canonicalizePath repoRoot
  let projectsRoot = repoAbs </> "projects"
  exists <- doesDirectoryExist projectsRoot
  if not exists then return [] else do
    entries <- listDirectory projectsRoot
    dirs <- filterM (doesDirectoryExist . (projectsRoot </>)) entries
    forM dirs $ \d -> do
      ps <- buildProjectShape repoRoot d
      return (d, ps)

-- Build a DirTree for everything not under `projects`
buildNonProjectsTree :: FilePath -> IO DirTree
buildNonProjectsTree repoRoot = do
  repoAbs <- canonicalizePath repoRoot
  allFiles <- listFilesRecursive defaultExcludes repoAbs
  let nonProjectFiles = [ f | f <- allFiles, let rel = makeRelative repoAbs f, case splitDirectories rel of { (x:_) -> map toLower x /= "projects"; _ -> True } ]
  let rel = map (makeRelative repoAbs) nonProjectFiles
  return $ buildDirTreeFromRelPaths "." rel
