{-# LANGUAGE DuplicateRecordFields #-}

module Wires.DiskShape where

-- Parsimonious disk-shaped datatypes copied from the web-agent
-- Field names intentionally mirror on-disk names and pairing forms.

type Path = FilePath
type Name = String

data WiresRoot =
  WiresRoot
    { root_path                     :: Path
    , dot_buttons                   :: DotButtons
    , dot_name_and_name_dot_bat     :: [DotNameAndNameDotBat]
    , buttons_dot_plan              :: Maybe Path
    , clean_dot_bat                 :: Maybe Path
    , status_dot_bat                :: Maybe Path
    , wire_dot_bat                  :: Maybe Path
    , dot_wires_hyphen_verification :: DotWiresHyphenVerification
    , bin                           :: Bin
    , projects                      :: Projects
    , proposals                     :: [Path]
    , snapshots                     :: [Path]
    , versions                      :: [Path]
    , walk                          :: Walk
    , tools                         :: Tools
    , notes                         :: Notes
    , docs_hyphen_txt               :: [Path]
    , doc_hyphen_index_dot_txt      :: Maybe Path
    , wires_dot_txt                 :: Maybe Path
    }
  deriving (Eq, Read, Show)


data DotNameAndNameDotBat =
  DotNameAndNameDotBat
    { name         :: Name
    , dot_name     :: DotButtons
    , name_dot_bat :: Maybe Path
    }
  deriving (Eq, Read, Show)


data DotButtons =
  DotButtons
    { dot_buttons_path          :: Path
    , files_dot_buttons         :: [Path]
    , files_dot_button          :: [Path]
    , files_dot_button_dot_skip :: [Path]
    , files_dot_bat             :: [Path]
    }
  deriving (Eq, Read, Show)


-- Minimal placeholders for referenced types; expand as needed.
data DotWiresHyphenVerification = DotWiresHyphenVerification { dwv_projects :: [(Name, [Path])] }
  deriving (Eq, Read, Show)

data Bin = Bin { bin_dot_alive :: [Path], bin_executables :: [Path] }
  deriving (Eq, Read, Show)

data Projects = Projects { projects_list :: [Path] }
  deriving (Eq, Read, Show)

data Walk = Walk { walk_sets :: [Path] }
  deriving (Eq, Read, Show)

data Tools = Tools { tools_files :: [Path] }
  deriving (Eq, Read, Show)

type Notes = [Path]
