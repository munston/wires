{-|
Module: Wires.Object

Purpose:
  Model and parse the workspace-level object model for Wires. This
  module provides types and parsing logic for the root `.wire`,
  `projects/wire.project`, and per-package `.nut`, `.bolt`, `.cog`
  descriptors. It also reads Haskell module headers to produce a
  lightweight representation consumed by other validation and
  generation modules.

Role in UI flow:
  - `Wires.Object` is the canonical source of truth for package
    metadata used by `Wires.Cast` and `Wires.Build` to render Cabal
    files and decide which modules to include in `other-modules`.
  - The object integrity check (`checkWiresObjectIntegrity`) verifies
    read/show roundtrips to detect malformed descriptors early.
-}
module Wires.Object where

import Control.Monad
import Data.Char
import Data.List
import Folders.Routes
import System.Directory
import System.FilePath

data WiresObject =
  WiresObject
    { wiresRoot :: FilePath
    , wiresMetadata :: WireMetadata
    , wiresProject :: WireProject
    , wiresPackages :: [WiresPackage]
    }
  deriving (Eq, Read, Show)

rootMetadataExtensions :: [String]
rootMetadataExtensions =
  [ ".garrage"
  , ".gofur"
  , ".wire"
  ]

data WireMetadata =
  WireMetadata
    { wireMetadataFile :: FilePath
    , wireName :: String
    , wireAuthor :: Maybe String
    , wireProjectsFolder :: FilePath
    , wireBinFolder :: FilePath
    , wireEntry :: FilePath
    , wireVersionPolicy :: Maybe String
    , wireSnapshotPolicy :: Maybe String
    , wireButtons :: [(String, FilePath)]
    }
  deriving (Eq, Read, Show)

data WireProject =
  WireProject
    { wireProjectFile :: FilePath
    , wireProjectPackages :: [FilePath]
    , wireProjectBootstrapPackages :: [FilePath]
    }
  deriving (Eq, Read, Show)

data WiresPackage =
  WiresPackage
    { wiresPackagePath :: FilePath
    , wiresPackageName :: String
    , wiresPackageNut :: Nut
    , wiresPackageBolt :: Bolt
    , wiresPackageCog :: Cog
    , wiresPackageRoutes :: [VerifiedRoute]
    , wiresPackageRouteOptouts :: [RouteOptout]
    , wiresPackageModules :: [HsModule]
    }
  deriving (Eq, Read, Show)

data Nut =
  Nut
    { nutFile :: FilePath
    , nutDepends :: [String]
    , nutExposes :: [String]
    , nutGoIs :: Maybe String
    }
  deriving (Eq, Read, Show)

data Bolt =
  Bolt
    { boltFile :: FilePath
    , boltDepends :: [String]
    , boltOptions :: [String]
    }
  deriving (Eq, Read, Show)

data Cog =
  Cog
    { cogFile :: FilePath
    , cogSuiteName :: Maybe String
    , cogSuiteType :: Maybe String
    , cogMainIs :: Maybe FilePath
    , cogSourceDirs :: [FilePath]
    , cogDepends :: [String]
    }
  deriving (Eq, Read, Show)

data HsModule =
  HsModule
    { hsModuleFile :: FilePath
    , hsModuleName :: String
    , hsModuleImports :: [String]
    }
  deriving (Eq, Read, Show)

readWiresObject :: FilePath -> IO (Either [String] WiresObject)
readWiresObject root = do
  absoluteRoot <- makeAbsolute root
  wireMetadataResult <- readWireMetadata absoluteRoot
  wireProjectResult <- readWireProject absoluteRoot
  case (wireMetadataResult, wireProjectResult) of
    (Right wireMetadata, Right wireProjectValue) -> do
      packageResults <- mapM (readWiresPackage absoluteRoot) (wireProjectPackages wireProjectValue)
      let errors = concatMap collectErrors packageResults
          packages = collectRights packageResults
      if null errors
        then return (Right (WiresObject absoluteRoot wireMetadata wireProjectValue packages))
        else return (Left errors)
    _ -> return (Left (collectErrors wireMetadataResult ++ collectErrors wireProjectResult))

checkWiresObjectIntegrity :: FilePath -> IO (Either [String] WiresObject)
checkWiresObjectIntegrity root = do
  objectResult <- readWiresObject root
  case objectResult of
    Left errors -> return (Left errors)
    Right object ->
      case reads (show object) of
        [(objectAgain, rest)] | all isSpace rest && objectAgain == object -> return (Right object)
        _ -> return (Left ["WiresObject failed Show/Read integrity round trip"])

formatObjectIntegrity :: Either [String] WiresObject -> String
formatObjectIntegrity result =
  case result of
    Left errors ->
      unlines ("wires object integrity failed:" : map ("- " ++) errors)
    Right object ->
      unlines
        [ "wires object integrity ok"
        , "root: " ++ wiresRoot object
        , "packages: " ++ show (length (wiresPackages object))
        , "modules: " ++ show (length (concatMap wiresPackageModules (wiresPackages object)))
        , "options: " ++ show (sum (map packageRouteCount (wiresPackages object)))
        ]

packageRouteCount :: WiresPackage -> Int
packageRouteCount package =
  length (wiresPackageRoutes package) + length (wiresPackageRouteOptouts package)

compareWiresObjects :: WiresObject -> WiresObject -> [String]
compareWiresObjects left right =
  if left == right
    then []
    else ["WiresObject values differ"]

readWireMetadata :: FilePath -> IO (Either [String] WireMetadata)
readWireMetadata root = do
  wireFiles <- fmap concat (mapM (listExtension root) rootMetadataExtensions)
  case wireFiles of
    [path] -> do
      text <- readFile path
      length text `seq` return ()
      return (buildWireMetadata path text)
    [] -> return (Left ["missing root stage file (.garrage, .gofur, or .wire)"])
    _ -> return (Left ["expected one root stage file (.garrage, .gofur, or .wire), found " ++ show (length wireFiles)])

buildWireMetadata :: FilePath -> String -> Either [String] WireMetadata
buildWireMetadata path text =
  let fields = parseTopLevelFields text
      buttons = parseNamedPairs "buttons:" text
      errors = validateWireMetadataFields fields
  in case errors of
       [] ->
         case (lookupField "name" fields, lookupField "projects-folder" fields, lookupField "bin-folder" fields, lookupField "wire-entry" fields) of
           (Just name, Just projectsFolder, Just binFolder, Just entry) ->
             Right
               (WireMetadata
                  path
                  name
                  (lookupField "author" fields)
                  projectsFolder
                  binFolder
                  entry
                  (lookupField "version-policy" fields)
                  (lookupField "snapshot-policy" fields)
                  buttons)
           _ -> Left (missingWireMetadataFields fields)
       _ -> Left errors

validateWireMetadataFields :: [(String, String)] -> [String]
validateWireMetadataFields fields =
  let allowed =
        [ "name"
        , "author"
        , "projects-folder"
        , "bin-folder"
        , "wire-entry"
        , "version-policy"
        , "snapshot-policy"
        ]
      forbidden =
        [ "packages"
        , "bootstrap-packages"
        , "projects"
        , "depends"
        , "options"
        , "precogs"
        , "optout"
        , "exposes"
        , "go-is"
        ]
      keys = map fst fields
  in concat
       [ ["root .wire contains project/package field that belongs in wire.project, .nut, .bolt, or .cog: " ++ key | key <- keys, key `elem` forbidden]
       , ["root .wire contains unknown metadata field: " ++ key | key <- keys, key `notElem` allowed, key `notElem` forbidden]
       ]

missingWireMetadataFields :: [(String, String)] -> [String]
missingWireMetadataFields fields =
  [ "root .wire missing required metadata field: " ++ key
  | key <- ["name", "projects-folder", "bin-folder", "wire-entry"]
  , lookupField key fields == Nothing
  ]

lookupField :: String -> [(String, String)] -> Maybe String
lookupField key fields =
  case [value | (fieldKey, value) <- fields, fieldKey == key, not (null value)] of
    value:_ -> Just value
    _ -> Nothing

readWireProject :: FilePath -> IO (Either [String] WireProject)
readWireProject root = do
  let path = root </> "projects" </> "wire.project"
  exists <- doesFileExist path
  if not exists
    then return (Left ["missing projects/wire.project"])
    else do
      text <- readFile path
      length text `seq` return ()
      let packages = parseIndentedList "packages:" text
          bootstrapPackages = parseIndentedList "bootstrap-packages:" text
      return (Right (WireProject path packages bootstrapPackages))

readWiresPackage :: FilePath -> FilePath -> IO (Either [String] WiresPackage)
readWiresPackage root relativePath = do
  let packageDir = root </> "projects" </> normalise relativePath
  exists <- doesDirectoryExist packageDir
  if not exists
    then return (Left ["package path does not exist: " ++ relativePath])
    else do
      nutResult <- readOneDescriptor packageDir ".nut" readNut
      boltResult <- readOneDescriptor packageDir ".bolt" readBolt
      cogResult <- readOneDescriptor packageDir ".cog" readCog
      modulesResult <- readHsModules packageDir
      routesResult <-
        case nutResult of
          Right nut -> readRoutesForNut packageDir nut
          Left _ -> return (Left [])
      let errors =
            collectErrors nutResult
            ++ collectErrors boltResult
            ++ collectErrors cogResult
            ++ collectErrors modulesResult
            ++ collectErrors routesResult
      case (nutResult, boltResult, cogResult, modulesResult, routesResult) of
        (Right nut, Right bolt, Right cog, Right modulesValue, Right (routes, optouts)) ->
          return (Right (WiresPackage relativePath (takeFileName packageDir) nut bolt cog routes optouts modulesValue))
        _ -> return (Left (map ((relativePath ++ ": ") ++) errors))

readOneDescriptor :: FilePath -> String -> (FilePath -> String -> a) -> IO (Either [String] a)
readOneDescriptor packageDir extension reader = do
  files <- listExtension packageDir extension
  case files of
    [path] -> do
      text <- readFile path
      length text `seq` return ()
      return (Right (reader path text))
    [] -> return (Left ["missing " ++ extension ++ " descriptor"])
    _ -> return (Left ["expected one " ++ extension ++ " descriptor, found " ++ show (length files)])

readNut :: FilePath -> String -> Nut
readNut path text =
  Nut path (parseIndentedList "depends:" text) (parseIndentedList "exposes:" text) (parseField "go-is:" text)

readBolt :: FilePath -> String -> Bolt
readBolt path text =
  Bolt path (parseIndentedList "depends:" text) (parseIndentedList "options:" text)

readCog :: FilePath -> String -> Cog
readCog path text =
  Cog
    path
    (parseField "test-suite:" text)
    (parseField "type:" text)
    (parseField "main-is:" text)
    (parseIndentedList "source-dirs:" text)
    (parseIndentedList "depends:" text)

readRoutesForNut :: FilePath -> Nut -> IO (Either [String] ([VerifiedRoute], [RouteOptout]))
readRoutesForNut packageDir nut =
  case nutGoIs nut of
    Nothing -> return (Left ["missing go-is, cannot read implementation routes"])
    Just target -> readRoutesForGoTarget packageDir target

readRoutesForGoTarget :: FilePath -> String -> IO (Either [String] ([VerifiedRoute], [RouteOptout]))
readRoutesForGoTarget packageDir target = do
  let moduleName = fst (splitGoTarget target)
      path = packageDir </> "lib" </> modulePath moduleName
  exists <- doesFileExist path
  if not exists
    then return (Left ["go-is module missing from source: " ++ moduleName])
    else do
      text <- readFile path
      length text `seq` return ()
      return (parseImplementationRoutes path text)

parseImplementationRoutes :: FilePath -> String -> Either [String] ([VerifiedRoute], [RouteOptout])
parseImplementationRoutes path text =
  let routeResults = map parseVerifiedRoute (filter routeLine (routeSectionLines "verifiedRoutes =" text))
      optoutResults = map parseRouteOptout (filter optoutLine (routeSectionLines "routeOptouts =" text))
      routes = collectRights routeResults
      optouts = collectRights optoutResults
      errors = concatMap collectErrors routeResults ++ concatMap collectErrors optoutResults
  in if null errors
       then Right (routes, optouts)
       else Left (map ((path ++ ": ") ++) errors)

routeSectionLines :: String -> String -> [String]
routeSectionLines key text =
  let rest = drop 1 (dropWhile (not . (key `isPrefixOf`) . trim) (lines text))
  in takeWhile routeSectionBody rest

routeSectionBody :: String -> Bool
routeSectionBody line =
  null (trim line) || isSpace (safeHead line)

routeLine :: String -> Bool
routeLine line =
  "VerifiedRoute " `isPrefixOf` trimRouteItem line

optoutLine :: String -> Bool
optoutLine line =
  "RouteOptout " `isPrefixOf` trimRouteItem line

parseVerifiedRoute :: String -> Either [String] VerifiedRoute
parseVerifiedRoute line =
  case reads (trimRouteItem line) of
    [(route, rest)] | all isSpace rest -> Right route
    _ -> Left ["invalid VerifiedRoute line: " ++ trim line]

parseRouteOptout :: String -> Either [String] RouteOptout
parseRouteOptout line =
  case reads (trimRouteItem line) of
    [(optout, rest)] | all isSpace rest -> Right optout
    _ -> Left ["invalid RouteOptout line: " ++ trim line]

trimRouteItem :: String -> String
trimRouteItem line =
  stripLeadingRouteMarker (stripTrailingComma (trimListItem line))

stripLeadingRouteMarker :: String -> String
stripLeadingRouteMarker value =
  case trim value of
    ',':rest -> trim rest
    '[':rest -> trim rest
    other -> other

stripTrailingComma :: String -> String
stripTrailingComma value =
  case reverse (trim value) of
    ',':rest -> trim (reverse rest)
    _ -> trim value

modulePath :: String -> FilePath
modulePath moduleName =
  foldr (</>) "" (splitOnDot moduleName) <.> "hs"

splitOnDot :: String -> [String]
splitOnDot value =
  case break (== '.') value of
    (left, []) -> [left]
    (left, _:right) -> left : splitOnDot right

splitGoTarget :: String -> (String, String)
splitGoTarget target =
  let reversed = reverse target
  in case break (== '.') reversed of
       (_, []) -> (target, "")
       (functionName, '.':moduleName) -> (reverse moduleName, reverse functionName)
       _ -> (target, "")

-- (reverted) comment-stripping helper removed; using raw source for header parsing

readHsModules :: FilePath -> IO (Either [String] [HsModule])
readHsModules packageDir = do
  files <- findHsFiles (packageDir </> "lib")
  results <- mapM readHsModule files
  let errors = concatMap collectErrors results
  if null errors
    then return (Right (collectRights results))
    else return (Left errors)

readHsModule :: FilePath -> IO (Either [String] HsModule)
readHsModule path = do
  text <- readFile path
  length text `seq` return ()
  let allLines = lines text
      moduleLines = [trim line | line <- allLines, case words (trim line) of { ("module":name:"where":[]) -> all moduleNameChar name; _ -> False }]
      importLines = [trim line | line <- allLines, "import " `isPrefixOf` trim line]
  case moduleLines of
    [moduleLine] ->
      let moduleName = case words (trim moduleLine) of
            ("module":name:"where":[]) -> name
            _ -> ""
          imports = map parseImportModule importLines
      in return (Right (HsModule path moduleName imports))
    [] -> return (Left [path ++ ": missing module declaration"])
    _ -> return (Left [path ++ ": multiple module declarations"])

findHsFiles :: FilePath -> IO [FilePath]
findHsFiles dir = do
  entries <- listDirectory dir
  fmap concat $
    forM entries $ \entry -> do
      let path = dir </> entry
      isDir <- doesDirectoryExist path
      isFile <- doesFileExist path
      if isDir
        then findHsFiles path
        else return [path | isFile && takeExtension path == ".hs"]

parseTopLevelFields :: String -> [(String, String)]
parseTopLevelFields text =
  [ (trim key, trim (drop 1 rest))
  | line <- lines text
  , not (isSpace (safeHead line))
  , let (key, rest) = break (== ':') line
  , not (null rest)
  , not (null (trim key))
  , not (null (trim (drop 1 rest)))
  ]

parseNamedPairs :: String -> String -> [(String, FilePath)]
parseNamedPairs section text =
  [ let pairText = trimListItem line
        (key, rest) = break (== ':') pairText
    in (trim key, trim (drop 1 rest))
  | line <- sectionLines section text
  , isListItem line
  , let candidate = trimListItem line
  , ":" `isInfixOf` candidate
  ]

parseField :: String -> String -> Maybe String
parseField key text =
  case [trim (drop (length key) line) | line <- lines text, key `isPrefixOf` trim line] of
    value:_ | not (null value) -> Just value
    _ -> Nothing

parseIndentedList :: String -> String -> [String]
parseIndentedList key text =
  let rest = dropWhile (not . (key `isPrefixOf`) . trim) (lines text)
  in case rest of
       [] -> []
       _:items -> map trimListItem (takeWhile isListItem items)

sectionLines :: String -> String -> [String]
sectionLines section text =
  let rest = drop 1 (dropWhile (not . (section `isPrefixOf`) . trim) (lines text))
  in takeWhile (not . isSectionHeader) rest

isSectionHeader :: String -> Bool
isSectionHeader line =
  let value = trim line
  in not (null value) && ":" `isSuffixOf` value && not (isSpace (safeHead line))

isListItem :: String -> Bool
isListItem line =
  let value = trim line
  in not (null value) && not (isSectionHeader line) && (isSpace (safeHead line) || "- " `isPrefixOf` value)

trimListItem :: String -> String
trimListItem line =
  let value = trim line
  in let raw = if "- " `isPrefixOf` value
                 then trim (drop 2 value)
                 else value
     in stripTrailingComma raw

parseImportModule :: String -> String
parseImportModule line =
  let tokens = words line
      afterImport = drop 1 tokens
      afterQualified = case afterImport of
        "qualified":rest -> rest
        rest -> rest
  in case afterQualified of
       [] -> ""
       name:_ -> name

listExtension :: FilePath -> String -> IO [FilePath]
listExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      return [dir </> entry | entry <- entries, takeExtension entry == extension]

collectErrors :: Either [String] a -> [String]
collectErrors value =
  case value of
    Left errors -> errors
    Right _ -> []

collectRights :: [Either [String] a] -> [a]
collectRights values =
  [value | Right value <- values]

moduleNameChar :: Char -> Bool
moduleNameChar char =
  isAlphaNum char || char == '.' || char == '_'

safeHead :: String -> Char
safeHead value =
  case value of
    [] -> ' '
    char:_ -> char

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile isSpace
