{-|
Module: Wires.Project

Purpose:
	High-level descriptors and helpers for multi-package "wire"
	projects. This module documents the semantics of `wire.project`
	entries and provides helpers used by the generator and buttons
	flow to enumerate and operate on project packages.

This module intentionally contains only documentation to explain the
project-level conventions; runtime helpers live in `Wires.Build` and
the object model is parsed via `Wires.Object`.
-}
module Wires.Project where

import qualified Folders.Project as FP

-- | Delegate project creation to the shared `folders` backend.
createHelloProject :: FilePath -> FilePath -> IO String
createHelloProject root projectName = FP.createHelloProject root projectName

