module Wires.Extensions.Alive where

newtype AliveFile = AliveFile { aliveText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".alive"

parseAlive :: String -> Either String AliveFile
parseAlive = Right . AliveFile

renderAlive :: AliveFile -> String
renderAlive = aliveText

validateAlive :: AliveFile -> Either String ()
validateAlive _ = Right ()

