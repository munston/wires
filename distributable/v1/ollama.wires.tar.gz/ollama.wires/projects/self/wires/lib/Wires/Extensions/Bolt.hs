module Wires.Extensions.Bolt where

newtype BoltFile = BoltFile { boltText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".bolt"

parseBolt :: String -> Either String BoltFile
parseBolt = Right . BoltFile

renderBolt :: BoltFile -> String
renderBolt = boltText

validateBolt :: BoltFile -> Either String ()
validateBolt _ = Right ()

