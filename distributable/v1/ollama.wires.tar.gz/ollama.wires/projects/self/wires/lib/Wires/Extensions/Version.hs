module Wires.Extensions.Version where

newtype VersionFile = VersionFile { versionText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".version"

parseVersion :: String -> Either String VersionFile
parseVersion = Right . VersionFile

renderVersion :: VersionFile -> String
renderVersion = versionText

validateVersion :: VersionFile -> Either String ()
validateVersion _ = Right ()

