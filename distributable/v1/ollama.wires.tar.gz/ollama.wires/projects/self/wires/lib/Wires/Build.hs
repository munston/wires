{-|
Module: Wires.Build

Purpose:
  Implement higher-level build and verification orchestration for the
  wires workspace. This module contains the operations invoked by the
  buttons flow (halt, clean, cabal-install/test, verification
  stamping) and utility functions used to discover packages and
  compute fingerprints for verification.

Role in UI flow:
  - Called from `install.bat` and per-package `.buttons` sequences to
    perform complex sequences that involve multiple packages and
    tools (Cabal, filesystem operations, and generated binaries).
  - Exposes concise status-returning functions designed to be
    printed to the console and parsed by the caller (e.g.
    "wires project verified: <pkg>").

Implementation notes:
  - Verification uses deterministic fingerprinting over selected
    descriptor and source files to determine whether a package needs to
    be rebuilt/verified.
  - The module prefers clear, short text results and throws an
    exception when an operation fails in a way that cannot be
    recovered by the buttons flow.
-}
module Wires.Build where

import Control.Concurrent
import Control.Exception
import Control.Monad
import Data.List
import Data.Maybe
import System.Directory
import System.Exit
import System.FilePath
import System.IO
import System.Info (os)
import System.Process
import qualified Wires.Check as Check
import qualified Wires.Object as Object
-- prefer invoking the system `robocopy` utility rather than depending
-- on the `robocop` library so this package stays lightweight
import Data.Time.Clock
import Data.Time.Format

-- | Halt (request termination of) any running project executables by
-- removing their alive marker files. Returns a short status string
-- with the number of alive files removed.
haltProjectBins :: FilePath -> IO String
haltProjectBins root = do
  projectBins <- discoverProjectBins root
  aliveFiles <- fmap concat (mapM discoverAliveFiles projectBins)
  mapM_ removeAlive aliveFiles
  waitForAliveFilesGone aliveFiles 20
  return ("halted project bin alive files: " ++ show (length aliveFiles))

-- | Halt executables for a single package (remove alive files in its
-- `bin` directory). Returns a status string noting how many markers
-- were present.
haltSingleProjectBin :: FilePath -> FilePath -> IO String
haltSingleProjectBin root packageRelative = do
  package <- findWiresPackageLocation root packageRelative
  aliveFiles <- discoverAliveFiles (packageDir package </> "bin")
  mapM_ removeAlive aliveFiles
  waitForAliveFilesGone aliveFiles 20
  return ("halted project bin alive files for " ++ packageRelative ++ ": " ++ show (length aliveFiles))

-- | Remove all `bin` directories for discovered packages and clear
-- the Cabal build cache. Returns a human readable summary on
-- success; throws on failure.
cleanProjectBins :: FilePath -> IO String
cleanProjectBins root = do
  projectBins <- discoverProjectBins root
  results <- mapM removeProjectBin projectBins
  cacheCleaned <- removeCabalBuildCache root
  let failed = [path | (path, False) <- results]
  if null failed
    then return ("cleaned project bins: " ++ show (length projectBins) ++ ", cabal cache cleaned: " ++ show cacheCleaned)
    else error ("failed to clean project bins: " ++ show failed)

-- | Clean a single package's `bin` directory.
cleanSingleProjectBin :: FilePath -> FilePath -> IO String
cleanSingleProjectBin root packageRelative = do
  package <- findWiresPackageLocation root packageRelative
  (_, ok) <- removeProjectBin (packageDir package </> "bin")
  if ok
    then return ("cleaned project bin for " ++ packageRelative)
    else error ("failed to clean project bin for " ++ packageRelative)

-- | Run `cabal v2-install` for every package that declares a
-- `.cabal` manifest. The function installs the executables into the
-- package `bin` directories so cogs can run them.
cabalInstallProjectBins :: FilePath -> IO String
cabalInstallProjectBins root = do
  packages <- discoverWiresPackages root
  results <- mapM (cabalInstallProject root) packages
  let failed = [path | (path, code) <- results, code /= ExitSuccess]
  if null failed
    then return ("cabal installed project bins: " ++ show (length packages))
    else error ("cabal install failed for: " ++ show failed)

-- | Run `cabal v2-test` for each package's cog test-suite.
cabalTestProjectBins :: FilePath -> IO String
cabalTestProjectBins root = do
  packages <- discoverWiresPackages root
  results <- mapM (cabalTestProject root) packages
  let failed = [path | (path, code) <- results, code /= ExitSuccess]
  if null failed
    then return ("cabal tested project bins: " ++ show (length packages))
    else error ("cabal test failed for: " ++ show failed)

-- | Compute and write a verification fingerprint for the entire
-- workspace. The stamp is used by `verificationStatus` to decide if a
-- verification run is up-to-date.
recordVerificationStamp :: FilePath -> IO String
recordVerificationStamp root = do
  fingerprint <- computeVerificationFingerprint root
  let stampFile = verificationStampFile root
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("wires verification stamp recorded\nfingerprint: " ++ fingerprint)

-- | Return a human-readable verification status string. If the
-- recorded stamp is missing or differs from the current fingerprint
-- the status will indicate stale state and an action to run the
-- verification flow.
verificationStatus :: FilePath -> IO String
verificationStatus root = do
  current <- computeVerificationFingerprint root
  let stampFile = verificationStampFile root
  exists <- doesFileExist stampFile
  if not exists
    then return (unlines ["wires verification stale", "reason: no verification stamp", "action: run clean.bat, then wire.bat"])
    else do
      recorded <- readStampLine stampFile
      if recorded == current
        then return (unlines ["wires verification current", "fingerprint: " ++ current])
        else return (unlines ["wires verification stale", "reason: Wires source fingerprint changed", "action: run clean.bat, then wire.bat", "recorded: " ++ recorded, "current: " ++ current])

-- | Like `verificationStatus` but for a single package. Useful for
-- per-package status buttons.
verificationStatusSingleProject :: FilePath -> FilePath -> IO String
verificationStatusSingleProject root packageRelative = do
  current <- computeProjectVerificationFingerprint root packageRelative
  let stampFile = verificationProjectStampFile root packageRelative
  exists <- doesFileExist stampFile
  if not exists
    then return (unlines ["wires project verification stale", "package: " ++ packageRelative, "reason: no verification stamp"])
    else do
      recorded <- readStampLine stampFile
      if recorded == current
        then return (unlines ["wires project verification current", "package: " ++ packageRelative, "fingerprint: " ++ current])
        else return (unlines ["wires project verification stale", "package: " ++ packageRelative, "reason: source fingerprint changed", "recorded: " ++ recorded, "current: " ++ current])

-- | Ensure a single package is verified. If verification is stale the
-- function runs a read-only-with-respect-to-source verification flow
-- including cleaning, checking, building and testing. Returns the
-- recorded stamp on success.
ensureProjectVerified :: FilePath -> FilePath -> IO String
ensureProjectVerified root packageRelative = do
  current <- isProjectVerificationCurrent root packageRelative
  if current
    then return ("wires project verification current: " ++ packageRelative)
    else do
      _ <- cleanProjectVerification root packageRelative
      checkResult <- Check.runCheck root
      case checkResult of
        Left errors -> error (unlines ("wires check failed:" : map ("- " ++) errors))
        Right _ -> return ()
      objectResult <- Object.checkWiresObjectIntegrity root
      case objectResult of
        Left errors -> error (unlines ("wires object integrity failed:" : map ("- " ++) errors))
        Right _ -> return ()
      _ <- haltSingleProjectBin root packageRelative
      _ <- cleanSingleProjectBin root packageRelative
      _ <- cabalInstallSingleProjectBin root packageRelative
      _ <- cabalTestSingleProject root packageRelative
      stamp <- recordVerificationSingleProject root packageRelative
      return ("wires project verified: " ++ packageRelative ++ "\n" ++ stamp)

-- | Prepare a project for verification by cleaning previous
-- verification artifacts if the verification is not current.
prepareProjectVerification :: FilePath -> FilePath -> IO String
prepareProjectVerification root packageRelative = do
  current <- isProjectVerificationCurrent root packageRelative
  if current
    then return ("wires project verification current: " ++ packageRelative)
    else cleanProjectVerification root packageRelative

-- | Clean per-package verification state: remove the cog stamp and
-- clear any `.skip` files which cause stages to be skipped during the
-- buttons flow.
cleanProjectVerification :: FilePath -> FilePath -> IO String
cleanProjectVerification root packageRelative = do
  package <- findWiresPackageLocation root packageRelative
  let verDir = root </> ".wires-verification" </> normalise packageRelative
  -- Remove all known stamp files
  let stampFiles = [ verificationProjectStampFile root packageRelative
                   , stageProjectStampFile root packageRelative "install.stamp"
                   , stageProjectStampFile root packageRelative "test.stamp"
                   , stageProjectStampFile root packageRelative "documentation.stamp"
                   , stageProjectStampFile root packageRelative "save.stamp"
                   , stageProjectStampFile root packageRelative "build.stamp"
                   ]
  forM_ stampFiles $ \stampFile -> do
    stampExists <- doesFileExist stampFile
    when stampExists (removeFile stampFile)

  -- Remove any leftover .skip markers in the package's buttons dir
  skipFiles <- findFilesByExtension (packageDir package </> ".buttons") ".skip"
  mapM_ removeFile skipFiles

  -- Best effort: remove the entire verification directory for this package
  verDirExists <- doesDirectoryExist verDir
  when verDirExists $
    void (try (removeDirectoryRecursive verDir) :: IO (Either SomeException ()))

  return ("cleaned project verification for " ++ packageRelative ++ ": removed skips " ++ show (length skipFiles))

-- | Exact-path verification cleanup that does **not** depend on the package
-- still being listed in wire.project.
--
-- This is the safe version to call during unregistration, because it does not
-- go through findWiresPackageLocation (which does 'error' if the package is
-- no longer registered).
cleanProjectVerificationExact :: FilePath -> FilePath -> IO String
cleanProjectVerificationExact root packageRelative = do
  let rel = normalise packageRelative
      verDir = root </> ".wires-verification" </> rel
      pkgButtonsDir = root </> "projects" </> rel </> ".buttons"

  -- Remove the entire verification subtree for this relative path (if present)
  verDirExists <- doesDirectoryExist verDir
  when verDirExists $
    void (try (removeDirectoryRecursive verDir) :: IO (Either SomeException ()))

  -- Best effort: clean any .skip files that still exist on disk under the package
  skipFiles <- do
    exists <- doesDirectoryExist pkgButtonsDir
    if exists
      then findFilesByExtension pkgButtonsDir ".skip"
      else return []
  mapM_ removeFile skipFiles

  -- Also remove the known stamp files directly under .wires-verification/<rel>
  let stampFiles = [ verificationProjectStampFile root packageRelative
                   , stageProjectStampFile root packageRelative "install.stamp"
                   , stageProjectStampFile root packageRelative "test.stamp"
                   , stageProjectStampFile root packageRelative "documentation.stamp"
                   , stageProjectStampFile root packageRelative "save.stamp"
                   , stageProjectStampFile root packageRelative "build.stamp"
                   ]
  forM_ stampFiles $ \stampFile -> do
    stampExists <- doesFileExist stampFile
    when stampExists (removeFile stampFile)

  return ("cleaned verification (exact) for " ++ packageRelative
          ++ ": removed " ++ show (length skipFiles) ++ " skip(s)"
          ++ if verDirExists then ", removed verification dir" else "")

discoverProjectBins :: FilePath -> IO [FilePath]
discoverProjectBins root = do
  projectDirs <- discoverWiresProjectDirs root
  return [dir </> "bin" | dir <- projectDirs]

discoverWiresProjectDirs :: FilePath -> IO [FilePath]
discoverWiresProjectDirs root = do
  packages <- discoverWiresPackages root
  return [packageDir package | package <- packages]

data WiresPackageLocation =
  WiresPackageLocation
    { packageRelativePath :: FilePath
    , packageDir :: FilePath
    , packageName :: String
    }

data PackageSelection =
  PackageSelection
    { includeRegularPackages :: Bool
    , includeBootstrapPackages :: Bool
    }

regularOnly :: PackageSelection
regularOnly = PackageSelection True False

allPackages :: PackageSelection
allPackages = PackageSelection True True

parsePackageSelection :: String -> Maybe PackageSelection
parsePackageSelection "--dont-exclude-bootstrap" = Just (PackageSelection True True)
parsePackageSelection "--bootstrap-only" = Just (PackageSelection False True)
parsePackageSelection _ = Nothing

selectPackages :: PackageSelection -> [FilePath] -> [FilePath] -> [FilePath]
selectPackages selection regularPackages bootstrapPackages =
  nub $
    (if includeRegularPackages selection then regularPackages else []) ++
    (if includeBootstrapPackages selection then bootstrapPackages else [])

discoverWiresPackages :: FilePath -> IO [WiresPackageLocation]
discoverWiresPackages =
  discoverWiresPackagesWithSelection regularOnly

discoverWiresPackagesWithMode :: FilePath -> String -> IO [WiresPackageLocation]
discoverWiresPackagesWithMode root mode =
  case parsePackageSelection mode of
    Just selection -> discoverWiresPackagesWithSelection selection root
    Nothing -> return []

discoverWiresPackagesWithSelection :: PackageSelection -> FilePath -> IO [WiresPackageLocation]
discoverWiresPackagesWithSelection selection root = do
  let wireProject = root </> "projects" </> "wire.project"
      cabalProject = root </> "projects" </> "cabal.project"
  wireExists <- doesFileExist wireProject
  if wireExists
    then do
      text <- readFile wireProject
      let regularPackages = parseIndentedList "packages:" text
          bootstrapPackages = parseIndentedList "bootstrap-packages:" text
          packagePathsRaw = selectPackages selection regularPackages bootstrapPackages
      packagePaths <- mapM (canonicalPackageRelative root) packagePathsRaw
      return
        [ WiresPackageLocation packagePath (root </> "projects" </> normalise packagePath) (takeFileName packagePath)
        | packagePath <- packagePaths
        ]
    else do
      -- Fallback: if `wire.project` is missing, try to read
      -- `projects/cabal.project` for package discovery. This allows
      -- treating `cabal.project` as the authoritative package list
      -- when migrating away from `wire.project`.
      cabalExists <- doesFileExist cabalProject
      if not cabalExists
        then return []
        else do
          text <- readFile cabalProject
          let regularPackages = parseIndentedList "packages:" text
              bootstrapPackages = parseIndentedList "bootstrap-packages:" text
              packagePathsRaw = selectPackages selection regularPackages bootstrapPackages
          packagePaths <- mapM (canonicalPackageRelative root) packagePathsRaw
          return
            [ WiresPackageLocation packagePath (root </> "projects" </> normalise packagePath) (takeFileName packagePath)
            | packagePath <- packagePaths
            ]

canonicalPackageRelative :: FilePath -> FilePath -> IO FilePath
canonicalPackageRelative root rawPath = do
  absoluteRoot <- makeAbsolute root
  canonical <- canonicaliseToProjects root rawPath
  let value = normalise canonical
      projectsRoot = absoluteRoot </> "projects"
  if isAbsolute value
    then do
      let relToRoot = normalise (makeRelative absoluteRoot value)
      return
        (case splitDirectories relToRoot of
           "projects":rest -> joinPath rest
           _ -> relToRoot)
    else return (stripProjectsPrefix value)

stripProjectsPrefix :: FilePath -> FilePath
stripProjectsPrefix path =
  case splitDirectories (normalise path) of
    "projects":rest -> joinPath rest
    _ -> normalise path


-- | Canonicalise incoming package paths to the `projects/...` form.
--
-- The function converts relative `..`-style or absolute paths that
-- point inside the workspace into a canonical `projects/<relative>`
-- path. If the provided path already appears to be under `projects/`
-- it is returned normalised.
canonicaliseToProjects :: FilePath -> FilePath -> IO FilePath
canonicaliseToProjects root rawPath = do
  absRoot <- makeAbsolute root
  let projAbs = normalise (absRoot </> "projects")
      p = normalise rawPath
  -- If the path already begins with "projects/" use it as-is
  if "projects" `isPrefixOf` takeDirectory p || "projects" `isPrefixOf` p
    then return (normalise p)
    else do
      absPath <- if isAbsolute p then makeAbsolute p else makeAbsolute (root </> p)
      let relToProj = makeRelative projAbs absPath
      if not (".." `isPrefixOf` relToProj)
        then return (normalise (joinPath ["projects", relToProj]))
        else return (normalise p)

findWiresPackageLocation :: FilePath -> FilePath -> IO WiresPackageLocation
findWiresPackageLocation root packageRelative = do
  packages <- discoverWiresPackagesWithSelection allPackages root
  case filter ((== normalise packageRelative) . normalise . packageRelativePath) packages of
    package:_ -> return package
    [] -> error ("package not found in wire.project: " ++ packageRelative)

verificationStampFile :: FilePath -> FilePath
verificationStampFile root =
  root </> ".wires-verification" </> "wires-cog.stamp"

verificationProjectStampFile :: FilePath -> FilePath -> FilePath
verificationProjectStampFile root packageRelative =
  root </> ".wires-verification" </> normalise packageRelative </> "cog.stamp"

computeVerificationFingerprint :: FilePath -> IO String
computeVerificationFingerprint root = do
  absoluteRoot <- makeAbsolute root
  files <- verificationInputFiles absoluteRoot
  chunks <- mapM (fingerprintChunk absoluteRoot) files
  return (show (hashText (concat chunks)))

computeProjectVerificationFingerprint :: FilePath -> FilePath -> IO String
computeProjectVerificationFingerprint root packageRelative = do
  package <- findWiresPackageLocation root packageRelative
  absolutePkgRoot <- canonicalizePath (packageDir package)
  packageFiles <- fmap sort (verificationPackageFiles package >>= mapM canonicalizePath)
  packageChunks <- mapM (fingerprintChunk absolutePkgRoot) packageFiles
  return (show (hashText (concat packageChunks)))

computeProjectStageFingerprint :: FilePath -> FilePath -> FilePath -> IO String
computeProjectStageFingerprint root packageRelative stampName = do
  package <- findWiresPackageLocation root packageRelative
  absolutePkgRoot <- canonicalizePath (packageDir package)
  packageFiles <- fmap sort (stagePackageFiles stampName package >>= mapM canonicalizePath)
  packageChunks <- mapM (fingerprintChunk absolutePkgRoot) packageFiles
  return (show (hashText (concat packageChunks)))

isProjectVerificationCurrent :: FilePath -> FilePath -> IO Bool
isProjectVerificationCurrent root packageRelative = do
  current <- computeProjectVerificationFingerprint root packageRelative
  let stampFile = verificationProjectStampFile root packageRelative
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- readStampLine stampFile
      return (recorded == current)

readStampLine :: FilePath -> IO String
readStampLine path = do
  -- A missing line, empty file, or otherwise unreadable stamp must not crash
  -- the build; treat it as "no recorded stamp" so the stage simply re-records.
  result <- try (withFile path ReadMode hGetLine) :: IO (Either SomeException String)
  return (either (const "") id result)

fingerprintChunk :: FilePath -> FilePath -> IO String
fingerprintChunk root path = do
  text <- readFileLatin1 path
  return (normalise (makeRelative root path) ++ "\n" ++ text ++ "\n")

-- | Read a file as raw bytes mapped 1:1 to characters (latin1), so binary
-- artefacts (e.g. produced .exe files included in save fingerprints) can be
-- read without the default UTF-8 decoder rejecting non-text bytes.
readFileLatin1 :: FilePath -> IO String
readFileLatin1 path = do
  h <- openFile path ReadMode
  hSetEncoding h latin1
  hGetContents h

verificationInputFiles :: FilePath -> IO [FilePath]
verificationInputFiles root = do
  wireFiles <- fmap concat (mapM (findImmediateFilesByExtension root) Object.rootMetadataExtensions)
  rootFiles <- filterM doesFileExist [root </> "wire.bat", root </> "clean.bat"]
  buttonFiles <- findFilesByExtensions (root </> ".buttons") [".button", ".buttons"]
  let wireProject = root </> "projects" </> "wire.project"
  projectFile <- filterM doesFileExist [wireProject]
  packages <- discoverWiresPackages root
  packageFiles <- fmap concat (mapM verificationPackageFiles packages)
  return (sort (wireFiles ++ rootFiles ++ buttonFiles ++ projectFile ++ packageFiles))

verificationPackageFiles :: WiresPackageLocation -> IO [FilePath]
verificationPackageFiles package = do
  descriptors <- fmap concat (mapM (findImmediateFilesByExtension (packageDir package)) [".nut", ".bolt", ".cog"])
  cabalFiles <- findImmediateFilesByExtension (packageDir package) ".cabal"
  modules <- findFilesByExtension (packageDir package </> "lib") ".hs"
  return (descriptors ++ cabalFiles ++ modules)

verificationSharedProjectFiles :: FilePath -> IO [FilePath]
verificationSharedProjectFiles root =
  filterM
    doesFileExist
    [ root </> "projects" </> "wire.project"
    , root </> "projects" </> "projects.wires"
    , root </> "buttons.plan"
    ]

stagePackageFiles :: FilePath -> WiresPackageLocation -> IO [FilePath]
stagePackageFiles stampName package = do
  let pkgDir = packageDir package
  cabalFiles <- findImmediateFilesByExtension pkgDir ".cabal"
  nutFiles <- findImmediateFilesByExtension pkgDir ".nut"
  garrageFiles <- findImmediateFilesByExtension pkgDir ".garrage"
  boltFiles <- findImmediateFilesByExtension pkgDir ".bolt"
  cogFiles <- findImmediateFilesByExtension pkgDir ".cog"
  libFiles <- sourceTreeFiles pkgDir ["lib", "src"] [".hs"]
  exeFiles <- sourceTreeFiles pkgDir ["exe", "app"] [".hs"]
  testFiles <- sourceTreeFiles pkgDir ["test", "cog"] [".hs"]
  let buildFiles = cabalFiles ++ nutFiles ++ garrageFiles ++ libFiles
      installFiles = buildFiles ++ boltFiles ++ exeFiles
      testStageFiles = buildFiles ++ cogFiles ++ testFiles
      documentationFiles = buildFiles
  return $
    case stampName of
      "build.stamp" -> buildFiles
      "install.stamp" -> installFiles
      "test.stamp" -> testStageFiles
      "documentation.stamp" -> documentationFiles
      _ -> cabalFiles ++ nutFiles ++ garrageFiles ++ boltFiles ++ cogFiles ++ libFiles ++ exeFiles ++ testFiles

sourceTreeFiles :: FilePath -> [FilePath] -> [String] -> IO [FilePath]
sourceTreeFiles pkgDir dirs extensions =
  fmap concat $
    forM dirs $ \dirName ->
      findFilesByExtensions (pkgDir </> dirName) extensions

hashText :: String -> Integer
hashText =
  foldl' hashStep 2166136261

hashStep :: Integer -> Char -> Integer
hashStep value char =
  ((value * 16777619) + toInteger (fromEnum char)) `mod` 1000000007

discoverAliveFiles :: FilePath -> IO [FilePath]
discoverAliveFiles binDir = do
  let aliveRoot = binDir </> ".alive"
  exists <- doesDirectoryExist aliveRoot
  if exists
    then findFilesByExtension aliveRoot ".alive"
    else return []

removeAlive :: FilePath -> IO ()
removeAlive path = do
  exists <- doesFileExist path
  if exists
    then removeFile path
    else return ()

waitForAliveFilesGone :: [FilePath] -> Int -> IO ()
waitForAliveFilesGone files attempts =
  if attempts <= 0
    then do
      remaining <- filterM doesFileExist files
      if null remaining
        then return ()
        else error ("alive files remain after halt: " ++ show remaining)
    else do
      remaining <- filterM doesFileExist files
      if null remaining
        then return ()
        else do
          threadDelay 250000
          waitForAliveFilesGone files (attempts - 1)

removeProjectBin :: FilePath -> IO (FilePath, Bool)
removeProjectBin binDir = do
  exists <- doesDirectoryExist binDir
  if not exists
    then return (binDir, True)
    else do
      result <- try (removeDirectoryRecursive binDir)
      case result of
        Right () -> return (binDir, True)
        Left exception -> do
          let _message = show (exception :: SomeException)
          return (binDir, False)

removeCabalBuildCache :: FilePath -> IO Bool
removeCabalBuildCache root = do
  let cache = root </> "projects" </> "dist-newstyle"
  exists <- doesDirectoryExist cache
  if exists
    then do
      removeDirectoryRecursive cache
      return True
    else return False

cabalInstallProject :: FilePath -> WiresPackageLocation -> IO (FilePath, ExitCode)
cabalInstallProject root package = do
  cabalFile <- findOneByExtension (packageDir package) ".cabal"
  case cabalFile of
    Nothing -> return (packageDir package, ExitFailure 1)
    Just _ -> do
      createDirectoryIfMissing True (packageDir package </> "bin")
      let args =
            [ "v2-install"
            , "exe:" ++ packageName package
            , "--install-method=copy"
            , "--installdir=" ++ packageRelativePath package </> "bin"
            , "--overwrite-policy=always"
            ]
      code <- withCreateProcess (proc "cabal" args) { cwd = Just (root </> "projects") } waitForCreatedProcess
      return (packageDir package, code)

cabalInstallSingleProjectBin :: FilePath -> FilePath -> IO String
cabalInstallSingleProjectBin root packageRelative = do
  pkgLocation <- findWiresPackageLocation root packageRelative
  (path, code) <- cabalInstallProject root pkgLocation
  case code of
    ExitSuccess -> return ("cabal installed project: " ++ path)
    _ -> error ("cabal install failed for: " ++ path)

cabalTestSingleProject :: FilePath -> FilePath -> IO String
cabalTestSingleProject root packageRelative = do
  pkgLocation <- findWiresPackageLocation root packageRelative
  (path, code) <- cabalTestProject root pkgLocation
  case code of
    ExitSuccess -> return ("cabal tested project: " ++ path)
    _ -> error ("cabal test failed for: " ++ path)

cabalHaddockSingleProject :: FilePath -> FilePath -> IO String
cabalHaddockSingleProject root packageRelative = do
  pkgLocation <- findWiresPackageLocation root packageRelative
  cabalFile <- findOneByExtension (packageDir pkgLocation) ".cabal"
  case cabalFile of
    Nothing -> return ("haddock skipped for project without cabal file: " ++ packageRelative)
    Just _ -> do
      skip <- shouldSkipDependencyHaddock pkgLocation
      if skip
        then return ("haddock skipped for dependency-heavy project: " ++ packageRelative)
        else do
          let args = ["v2-haddock", cabalPackageName (packageName pkgLocation)]
          code <- withCreateProcess (proc "cabal" args) { cwd = Just (root </> "projects") } waitForCreatedProcess
          case code of
            ExitSuccess -> return ("haddock generated for project: " ++ packageRelative)
            _ -> error ("haddock failed for project: " ++ packageRelative)

codfishSingleProject :: FilePath -> FilePath -> IO String
codfishSingleProject root packageRelative = do
  pkgLocation <- findWiresPackageLocation root packageRelative
  maybeHtmlDir <- findMaybeHaddockHtmlDir root (cabalPackageName (packageName pkgLocation))
  skip <- shouldSkipDependencyHaddock pkgLocation
  let candidate1 = root </> "tools" </> "codfish" </> toolExe "codfish"
      candidate2 = root </> "external" </> "tools" </> "codfish" </> toolExe "codfish"
      destDir = packageDir pkgLocation </> "docs-txt"
  case maybeHtmlDir of
    Nothing
      | skip -> return ("codfish skipped for dependency-heavy project without local haddock HTML: " ++ packageRelative)
      | otherwise -> error ("haddock HTML not found for package: " ++ cabalPackageName (packageName pkgLocation))
    Just htmlDir -> do
      existing <- filterM doesFileExist [candidate1, candidate2]
      case existing of
        [] -> return ("codfish skipped for project without external codfish executable: " ++ packageRelative)
        codfishExe:_ -> do
          removeIfExists destDir
          createDirectoryIfMissing True destDir
          code <- withCreateProcess (proc codfishExe [htmlDir, destDir]) waitForCreatedProcess
          case code of
            ExitSuccess -> return ("codfish generated docs for project: " ++ packageRelative)
            _ -> error ("codfish failed for project: " ++ packageRelative)

shouldSkipDependencyHaddock :: WiresPackageLocation -> IO Bool
shouldSkipDependencyHaddock package = do
  nutFile <- findOneByExtension (packageDir package) ".nut"
  case nutFile of
    Nothing -> return False
    Just path -> do
      text <- readFile path
      let deps = Check.parseIndentedList "depends:" text
          heavyDeps = ["http-client", "http-client-tls", "http-types", "nemotron"]
      return (packageName package `elem` ["nemotron"] || any (`elem` deps) heavyDeps)

recordVerificationSingleProject :: FilePath -> FilePath -> IO String
recordVerificationSingleProject root packageRelative = do
  fingerprint <- computeProjectVerificationFingerprint root packageRelative
  let stampFile = verificationProjectStampFile root packageRelative
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("wires verification stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ fingerprint)

recordInstallSingleProject :: FilePath -> FilePath -> IO String
recordInstallSingleProject =
  recordStageSingleProject "install" "install.stamp"

recordTestSingleProject :: FilePath -> FilePath -> IO String
recordTestSingleProject =
  recordStageSingleProject "test" "test.stamp"

recordSaveSingleProject :: FilePath -> FilePath -> IO String
recordSaveSingleProject root packageRelative = do
  -- Ensure the project has a current verification fingerprint
  -- (i.e., rebuild/reinstall/retest/redocument as necessary).
  currentOk <- isProjectVerificationCurrent root packageRelative
  when (not currentOk) $ do
    _ <- ensureProjectVerified root packageRelative
    return ()
  -- After verification is current, record a save stamp derived from
  -- the save fingerprint which includes verification inputs plus
  -- generated artifacts produced by tooling (cabal, nut/garrage,
  -- exe outputs, docs). This keeps save idempotent while reflecting
  -- produced outputs.
  fingerprint <- computeProjectSaveFingerprint root packageRelative
  let stampFile = stageProjectStampFile root packageRelative "save.stamp"
  -- If a save stamp already exists and matches the computed
  -- fingerprint, consider the save current and skip writing.
  exists <- doesFileExist stampFile
  when exists $ do
    recorded <- readStampLine stampFile
    when (recorded == fingerprint) $
      return ()
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (fingerprint ++ "\n")
  return ("wires save stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ fingerprint)

-- | Compute a save-specific fingerprint for a project. This starts
-- from the same inputs used for verification and extends them with
-- common produced artefacts so save records reflect generated state.
computeProjectSaveFingerprint :: FilePath -> FilePath -> IO String
computeProjectSaveFingerprint root packageRelative = do
  package <- findWiresPackageLocation root packageRelative
  absolutePkgRoot <- makeAbsolute (packageDir package)
  -- base verification inputs (descriptors + hs modules)
  baseFiles <- verificationPackageFiles package
  -- additional produced artefacts to include in save fingerprint
  extra1 <- findFilesByExtensions (packageDir package) [".cabal", ".nut", ".garrage", ".package", ".json", ".md", ".txt"]
  extra2 <- findFilesByExtension (packageDir package </> "exe") ".hs"
  extra3 <- findFilesByExtension (packageDir package </> "bin") ".exe"
  -- include docs if present
  docs <- findFilesByExtension (packageDir package </> "docs-txt") ".txt"
  let allFiles = nub (baseFiles ++ extra1 ++ extra2 ++ extra3 ++ docs)
  chunks <- mapM (fingerprintChunk absolutePkgRoot) allFiles
  return (show (hashText (concat chunks)))

recordDocumentationSingleProject :: FilePath -> FilePath -> IO String
recordDocumentationSingleProject =
  recordStageSingleProject "documentation" "documentation.stamp"

recordBuildSingleProject :: FilePath -> FilePath -> IO String
recordBuildSingleProject =
  recordStageSingleProject "build" "build.stamp"

recordStageSingleProject :: String -> FilePath -> FilePath -> FilePath -> IO String
recordStageSingleProject label stampName root packageRelative = do
  currentVerif <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = stageProjectStampFile root packageRelative stampName
  createDirectoryIfMissing True (takeDirectory stampFile)
  writeFile stampFile (currentVerif ++ "\n")
  return ("wires " ++ label ++ " stamp recorded for " ++ packageRelative ++ "\nfingerprint: " ++ currentVerif)

-- | Invoke the repository save script to create a `versions/<timestamp>/`
-- snapshot. Attempts to run the `scripts/save_wires.hs` script via
-- `runghc`. If the script is not present, returns an explanatory
-- message. Returns the captured stdout/stderr from the script.
saveRepoVersions :: FilePath -> Maybe String -> IO String
saveRepoVersions root mname = do
  -- Prefer calling the system `robocopy` command (available on Windows)
  -- to avoid adding `robocop` as a library dependency of `wires`.
  absoluteRoot <- makeAbsolute root
  let destParent = absoluteRoot </> "versions"
  createDirectoryIfMissing True destParent
  timestamp <- getCurrentTimeString
  let saveName = fromMaybe timestamp mname
      dest = destParent </> saveName
      args = [absoluteRoot, dest, "/E", "/XD", "dist-newstyle", ".wires-verification", "versions", "saves"]
  (exitCode, out, err) <- readCreateProcessWithExitCode (proc "robocopy" args) ""
  let code = case exitCode of
               ExitSuccess -> 0
               ExitFailure n -> n
      preview s = take 200 (filter (/= '\r') s)
      resStr = if code < 8 then ("robocopy:success:" ++ show code ++ "\n" ++ preview out) else ("robocopy:failure:" ++ show code ++ "\n" ++ preview err)
  return ("save repo snapshot: " ++ dest ++ "\n" ++ resStr)

-- | Return a compact ISO-like timestamp string safe for filenames.
getCurrentTimeString :: IO String
getCurrentTimeString = do
  t <- getCurrentTime
  -- Format as YYYYMMDDTHHMMSS for a compact, filesystem-safe timestamp.
  pure (formatTime defaultTimeLocale "%Y%m%dT%H%M%S" t)

generateWireButtons :: FilePath -> IO String
generateWireButtons root =
  generateWireButtonsFor regularOnly root

generateWireButtonsWithMode :: FilePath -> String -> IO String
generateWireButtonsWithMode root mode =
  case parsePackageSelection mode of
    Just selection -> generateWireButtonsFor selection root
    Nothing -> return ("unknown package selection: " ++ mode)

generateWireButtonsFor :: PackageSelection -> FilePath -> IO String
generateWireButtonsFor selection root = do
  absoluteRoot <- makeAbsolute root
  discovered <- discoverWiresPackagesWithSelection selection absoluteRoot
  packages <- filterM hasWiresOrGarrageDescriptor discovered
  let testButtonsDir = absoluteRoot </> ".test"
      testButtons = testButtonsDir </> "test.buttons"
  createDirectoryIfMissing True testButtonsDir
  cleanupInactivePhaseButtons absoluteRoot (map packageRelativePath packages) "test"
  _ <- mapM (writeProjectMakeButtons absoluteRoot) packages
  projectSequences <- mapM (writeProjectTestButtons absoluteRoot) packages
  writeGeneratedFile testButtons (unlines (map (normalise . makeRelative testButtonsDir) projectSequences))
  return ("generated wires test buttons\npackages: " ++ show (length packages))

hasWiresOrGarrageDescriptor :: WiresPackageLocation -> IO Bool
hasWiresOrGarrageDescriptor package = do
  let dir = packageDir package
  candidates <- mapM doesFileExist
    [ dir </> "package.garrage"
    , dir </> "package.nut"
    , dir </> "package.bolt"
    , dir </> "package.cog"
    ]
  return (or candidates)

writeProjectTestButtons :: FilePath -> WiresPackageLocation -> IO FilePath
writeProjectTestButtons root package = do
  let buttonsDir = packageDir package </> ".buttons"
      sequencePath = buttonsDir </> "test.buttons"
      wiresExe = root </> "bin" </> toolExe "wires"
      endpoint = normalise (makeRelative buttonsDir wiresExe)
      targetArgument option = unwords [option, "..", packageRelativePath package]
      writeButton fileName option =
        writeGeneratedFile (buttonsDir </> fileName) (show (endpoint, targetArgument option) ++ "\n")
      -- Verification must be read-only with respect to the source it verifies.
      -- Generation steps (--advance-gofur-wires, --compile-wires, --cast) write
      -- generated source and/or cabal manifests, so they are excluded from the
      -- routine test flow; run them as a deliberate codegen step when wires
      -- descriptors actually change. The routine flow only verifies and tests.
      structuralEntries =
        [ ("test-00-check.button", "--check")
        , ("test-01-object-check.button", "--object-check")
        ]
      cogEntries =
        [ ("test-02-cabal-test.button", "--test")
        , ("test-03-record-test.button", "--record-test")
        ]
  createDirectoryIfMissing True buttonsDir
  hasCog <- doesFileExist (packageDir package </> "package.cog")
  hasCogSuite <- packageDeclaresCogSuite package
  let entries = structuralEntries ++ if hasCog && hasCogSuite then cogEntries else []
  current <- isStageCurrent root (packageRelativePath package) "test.stamp"
  if current then return () else removeStageSkips buttonsDir "test"
  cleanupStalePhaseArtifacts buttonsDir "test" ("test.buttons" : map fst entries)
  forM_ entries (uncurry writeButton)
  writeGeneratedFile sequencePath (unlines (map fst entries))
  return sequencePath

packageDeclaresCogSuite :: WiresPackageLocation -> IO Bool
packageDeclaresCogSuite package = do
  cabalFiles <- findImmediateFilesByExtension (packageDir package) ".cabal"
  texts <- mapM readFile cabalFiles
  let suiteHeader = "test-suite " ++ cabalPackageName (packageName package) ++ "-cog"
  return (any (suiteHeader `isInfixOf`) texts)

isStageCurrent :: FilePath -> FilePath -> FilePath -> IO Bool
isStageCurrent root packageRelative stampName = do
  current <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = stageProjectStampFile root packageRelative stampName
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- readStampLine stampFile
      return (recorded == current)

stageStatus :: FilePath -> FilePath -> FilePath -> IO String
stageStatus root stampName packageRelative = do
  current <- computeProjectStageFingerprint root packageRelative stampName
  let stampFile = stageProjectStampFile root packageRelative stampName
  exists <- doesFileExist stampFile
  recorded <- if exists then readStampLine stampFile else return ""
  return $
    unlines
      [ "stage: " ++ stampName
      , "package: " ++ normalise packageRelative
      , "stamp: " ++ normalise stampFile
      , "recorded: " ++ recorded
      , "current: " ++ current
      , "current? " ++ show (exists && recorded == current)
      ]

removeStageSkips :: FilePath -> String -> IO ()
removeStageSkips buttonsDir prefix = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if (prefix `isPrefixOf` entry || entry == prefix ++ ".buttons.skip") && ".skip" `isSuffixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

cleanupInactivePhaseButtons :: FilePath -> [FilePath] -> String -> IO ()
cleanupInactivePhaseButtons root activePackages phase = do
  buttonsDirs <- discoverButtonsDirs (root </> "projects")
  let active = map normalise activePackages
  forM_ buttonsDirs $ \buttonsDir -> do
    let packageRelative = normalise (makeRelative (root </> "projects") (takeDirectory buttonsDir))
    if packageRelative `elem` active
      then return ()
      else removePhaseFiles buttonsDir phase

discoverButtonsDirs :: FilePath -> IO [FilePath]
discoverButtonsDirs projectsRoot = do
  exists <- doesDirectoryExist projectsRoot
  if not exists
    then return []
    else do
      projects <- listDirectory projectsRoot
      fmap concat $ forM projects $ \projectName -> do
        let srcRoot = projectsRoot </> projectName </> "src"
        srcExists <- doesDirectoryExist srcRoot
        if not srcExists
          then return []
          else do
            packages <- listDirectory srcRoot
            return [srcRoot </> packageName </> ".buttons" | packageName <- packages]

removePhaseFiles :: FilePath -> String -> IO ()
removePhaseFiles buttonsDir phase = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if phase `isPrefixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

data ProjectButtonPaths =
  ProjectButtonPaths
    { projectMakeButtons :: FilePath
    , projectInstallButtons :: Maybe FilePath
    , projectTestButtons :: Maybe FilePath
    , projectDocumentationButtons :: Maybe FilePath
    }
  deriving (Eq, Show)

writeProjectMakeButtons :: FilePath -> WiresPackageLocation -> IO ProjectButtonPaths
writeProjectMakeButtons root package = do
  plan <- loadButtonPlan root package
  let buttonsDir = packageDir package </> ".buttons"
      sequencePath = buttonsDir </> "make.buttons"
      wiresExe = root </> "bin" </> toolExe "wires"
      endpoint = normalise (makeRelative buttonsDir wiresExe)
      targetArgument option = unwords [option, "..", packageRelativePath package]
  createDirectoryIfMissing True buttonsDir
  cleanupStaleMakeArtifacts buttonsDir (currentButtonPlanFiles plan)
  forM_ (planSequences plan) $ \(sequenceName, entries) ->
    unless (sequenceName `elem` phaseOwnedButtonSequences) $
      writeGeneratedFile (buttonsDir </> sequenceName <.> "buttons") (unlines (map (renderButtonPlanEntry buttonsDir endpoint targetArgument) entries))
  forM_ (planButtons plan) $ \(fileName, option) ->
    writeGeneratedFile (buttonsDir </> fileName) (show (endpoint, targetArgument option) ++ "\n")
  writeGeneratedFile (buttonsDir </> "clean.bat") (renderProjectButtonsCleanBat root buttonsDir sequencePath)
  return
    ProjectButtonPaths
      { projectMakeButtons = sequencePath
      , projectInstallButtons = planSequencePath buttonsDir plan "install"
      , projectTestButtons = planSequencePath buttonsDir plan "test"
      , projectDocumentationButtons = planSequencePath buttonsDir plan "documentation"
      }

writeProjectButtons :: FilePath -> FilePath -> String -> WiresPackageLocation -> IO FilePath
writeProjectButtons root fileName option package = do
  let buttonsDir = packageDir package </> ".buttons"
      sequencePath = buttonsDir </> fileName
      wiresExe = root </> "bin" </> toolExe "wires"
      endpoint = normalise (makeRelative buttonsDir wiresExe)
      argument = unwords [option, "..", packageRelativePath package]
  createDirectoryIfMissing True buttonsDir
  writeGeneratedFile sequencePath (show (endpoint, argument) ++ "\n")
  return sequencePath

writeGeneratedFile :: FilePath -> String -> IO ()
writeGeneratedFile path body = do
  createDirectoryIfMissing True (takeDirectory path)
  exists <- doesFileExist path
  if exists
    then do
      current <- readFileStrict path
      if current == body
        then return ()
        else writeFile path body
    else writeFile path body

readFileStrict :: FilePath -> IO String
readFileStrict path =
  withFile path ReadMode $ \handle -> do
    text <- hGetContents handle
    length text `seq` return text

cleanupStalePhaseArtifacts :: FilePath -> String -> [FilePath] -> IO ()
cleanupStalePhaseArtifacts buttonsDir phase keep = do
  exists <- doesDirectoryExist buttonsDir
  when exists $ do
    entries <- listDirectory buttonsDir
    forM_ entries $ \entry ->
      when (phase `isPrefixOf` entry && entry `notElem` keep && takeExtension entry `elem` [".button", ".buttons"]) $ do
        fileExists <- doesFileExist (buttonsDir </> entry)
        when fileExists (removeFile (buttonsDir </> entry))

renderProjectButtonsCleanBat :: FilePath -> FilePath -> FilePath -> String
renderProjectButtonsCleanBat root buttonsDir sequencePath =
  let buttonsExe = normalise (makeRelative buttonsDir (root </> "bin" </> toolExe "buttons"))
      sequenceFile = takeFileName sequencePath
  in unlines
       [ "@echo off"
       , "setlocal"
       , "\"" ++ buttonsExe ++ "\" --clean \"" ++ sequenceFile ++ "\""
       , "exit /b %ERRORLEVEL%"
       ]

toolExe :: String -> FilePath
toolExe name =
  if os == "mingw32" then name <.> "exe" else name

renderRootPhaseButtons :: FilePath -> [ProjectButtonPaths] -> (ProjectButtonPaths -> Maybe FilePath) -> String
renderRootPhaseButtons phaseDir projects selectPath =
  unlines (map (normalise . makeRelative phaseDir) (mapMaybe selectPath projects))

renderRootPhaseBat :: String -> FilePath -> String
renderRootPhaseBat phase sequencePath =
  let wrapperLine = case phase of
        "build" -> "\"%ROOT%\\garrage.bat\" \"%ROOT%\""
        "install" -> "\"%ROOT%\\gofur.bat\" \"%ROOT%\""
        "test" -> "\"%ROOT%\\wire.bat\" \"%ROOT%\""
        "document" -> "\"%ROOT%\\document.bat\" \"%ROOT%\""
        _ -> "\"%ROOT%\\wire.bat\" \"%ROOT%\""
  in unlines
       [ "@echo off"
       , "setlocal"
       , "set \"ROOT=%~dp0.%\""
       , wrapperLine
       , "if errorlevel 1 exit /b %ERRORLEVEL%"
       , "\"%ROOT%\\bin\\buttons.exe\" \"%ROOT%\\" ++ sequencePath ++ "\""
       , "exit /b %ERRORLEVEL%"
       ]

data ButtonPlan =
  ButtonPlan
    { planSequences :: [(String, [ButtonPlanEntry])]
    }
  deriving (Eq, Show)

data ButtonPlanEntry =
    PlanButton FilePath String
  | PlanInclude String
  deriving (Eq, Show)

buttonPlanFileName :: FilePath
buttonPlanFileName = "buttons.plan"

loadButtonPlan :: FilePath -> WiresPackageLocation -> IO ButtonPlan
loadButtonPlan root package = do
  let candidates = [packageDir package </> buttonPlanFileName, root </> buttonPlanFileName]
  existing <- filterM doesFileExist candidates
  case existing of
    path:_ -> do
      text <- readFile path
      case parseButtonPlan text of
        Right plan -> return plan
        Left message -> error ("invalid button plan " ++ path ++ ": " ++ message)
    [] -> error ("missing button plan; expected " ++ buttonPlanFileName ++ " in " ++ packageDir package ++ " or " ++ root)

parseButtonPlan :: String -> Either String ButtonPlan
parseButtonPlan text = do
  (_, sequences, current) <- foldM parseLine (1 :: Int, [], Nothing) (lines text)
  finalSequences <- flush current sequences
  let plan = ButtonPlan finalSequences
  validateButtonPlan plan
  return plan
  where
    parseLine (lineNumber, done, active) rawLine =
      let value = trim rawLine
          next = lineNumber + 1
      in if null value || "#" `isPrefixOf` value
           then Right (next, done, active)
           else
             case words value of
               ["sequence", name] -> do
                 flushed <- flush active done
                 Right (next, flushed, Just (name, []))
               ["include", name] ->
                 case appendEntry lineNumber active (PlanInclude name) of
                   Right updated -> Right (next, done, updated)
                   Left message -> Left message
               ["button", fileName, option] ->
                 case appendEntry lineNumber active (PlanButton (ensureButtonExtension fileName) option) of
                   Right updated -> Right (next, done, updated)
                   Left message -> Left message
               _ ->
                 Left ("line " ++ show lineNumber ++ ": expected 'sequence <name>', 'include <name>', or 'button <file> <option>'")

    appendEntry lineNumber active entry =
      case active of
        Just (name, entries) -> Right (Just (name, entries ++ [entry]))
        Nothing -> Left ("line " ++ show lineNumber ++ ": entry appears before any sequence")

    flush active done =
      case active of
        Nothing -> Right done
        Just (name, entries) -> Right (done ++ [(name, entries)])

validateButtonPlan :: ButtonPlan -> Either String ()
validateButtonPlan (ButtonPlan sequences)
  | null sequences = Left "at least one sequence is required"
  | not ("make" `elem` sequenceNames) = Left "a 'make' sequence is required"
  | otherwise = mapM_ validateEntry allEntries
  where
    sequenceNames = map fst sequences
    allEntries = concatMap snd sequences
    validateEntry (PlanButton fileName option)
      | null fileName = Left "button file name must not be empty"
      | null option = Left ("button option must not be empty for " ++ fileName)
      | otherwise = Right ()
    validateEntry (PlanInclude name)
      | name `elem` sequenceNames = Right ()
      | otherwise = Left ("included sequence not found: " ++ name)

planSequencePath :: FilePath -> ButtonPlan -> String -> Maybe FilePath
planSequencePath buttonsDir (ButtonPlan sequences) name =
  if name `elem` map fst sequences
    then Just (buttonsDir </> name <.> "buttons")
    else Nothing

stageProjectStampFile :: FilePath -> FilePath -> FilePath -> FilePath
stageProjectStampFile root packageRelative stampName =
  root </> ".wires-verification" </> normalise packageRelative </> stampName

ensureButtonExtension :: FilePath -> FilePath
ensureButtonExtension path =
  if takeExtension path == ".button"
    then path
    else path <.> "button"

renderButtonPlanEntry :: FilePath -> FilePath -> (String -> String) -> ButtonPlanEntry -> FilePath
renderButtonPlanEntry _ _ _ (PlanButton fileName _) =
  normalise fileName
renderButtonPlanEntry _ _ _ (PlanInclude sequenceName) =
  normalise (sequenceName <.> "buttons")

planButtons :: ButtonPlan -> [(FilePath, String)]
planButtons (ButtonPlan sequences) =
  nub [(fileName, option) | (_, entries) <- sequences, PlanButton fileName option <- entries]

currentButtonPlanFiles :: ButtonPlan -> [FilePath]
currentButtonPlanFiles plan =
  nub $
    "make.buttons"
    : "clean.bat"
    : [sequenceName <.> "buttons" | (sequenceName, _) <- planSequences plan, sequenceName `notElem` phaseOwnedButtonSequences]
    ++ map fst (planButtons plan)

phaseOwnedButtonSequences :: [String]
phaseOwnedButtonSequences = ["build", "install", "test", "document", "documentation"]

cleanupStaleMakeArtifacts :: FilePath -> [FilePath] -> IO ()
cleanupStaleMakeArtifacts buttonsDir keep = do
  exists <- doesDirectoryExist buttonsDir
  when exists $ do
    entries <- listDirectory buttonsDir
    forM_ entries $ \entry ->
      when (entry `notElem` keep && isLegacyMakeArtifact entry) $ do
        fileExists <- doesFileExist (buttonsDir </> entry)
        when fileExists (removeFile (buttonsDir </> entry))

isLegacyMakeArtifact :: FilePath -> Bool
isLegacyMakeArtifact entry =
  entry `elem` ["make.buttons", "documentation.buttons"] ||
    (takeExtension entry == ".button" && hasNumericPrefix (takeBaseName entry))
  where
    hasNumericPrefix name =
      case break (== '-') name of
        (prefix, '-':_) -> not (null prefix) && all (`elem` ['0'..'9']) prefix
        _ -> False
 

cabalTestProject :: FilePath -> WiresPackageLocation -> IO (FilePath, ExitCode)
cabalTestProject root package = do
  cabalFile <- findOneByExtension (packageDir package) ".cabal"
  case cabalFile of
    Nothing -> return (packageDir package, ExitSuccess)
    Just _ -> do
      let args = ["v2-test", cabalPackageName (packageName package) ++ ":" ++ cabalPackageName (packageName package) ++ "-cog"]
      code <- withCreateProcess (proc "cabal" args) { cwd = Just (root </> "projects") } waitForCreatedProcess
      return (packageDir package, code)

findHaddockHtmlDir :: FilePath -> String -> IO FilePath
findHaddockHtmlDir root packageCabalName = do
  maybePath <- findMaybeHaddockHtmlDir root packageCabalName
  case maybePath of
    Just path -> return path
    Nothing -> error ("haddock HTML not found for package: " ++ packageCabalName)

findMaybeHaddockHtmlDir :: FilePath -> String -> IO (Maybe FilePath)
findMaybeHaddockHtmlDir root packageCabalName = do
  let buildRoot = root </> "projects" </> "dist-newstyle" </> "build"
  candidates <- findDirectoriesNamed buildRoot packageCabalName
  withIndex <- filterM (\dir -> doesFileExist (dir </> "index.html")) candidates
  case withIndex of
    path:_ -> return (Just path)
    [] -> return Nothing

findDirectoriesNamed :: FilePath -> String -> IO [FilePath]
findDirectoriesNamed root name = do
  exists <- doesDirectoryExist root
  if not exists
    then return []
    else do
      entries <- listDirectory root
      fmap concat $
        forM entries $ \entry -> do
          let path = root </> entry
          isDir <- doesDirectoryExist path
          if isDir
            then do
              nested <- findDirectoriesNamed path name
              return ([path | takeFileName path == name] ++ nested)
            else return []

removeIfExists :: FilePath -> IO ()
removeIfExists path = do
  fileExists <- doesFileExist path
  dirExists <- doesDirectoryExist path
  when fileExists (removeFile path)
  when dirExists (removeDirectoryRecursive path)

cabalPackageName :: String -> String
cabalPackageName =
  map replaceUnderscore

replaceUnderscore :: Char -> Char
replaceUnderscore char
  | char == '_' = '-'
  | otherwise = char

waitForCreatedProcess :: Maybe Handle -> Maybe Handle -> Maybe Handle -> ProcessHandle -> IO ExitCode
waitForCreatedProcess _ _ _ processHandle =
  waitForProcess processHandle

findOneByExtension :: FilePath -> String -> IO (Maybe FilePath)
findOneByExtension dir extension = do
  files <- findFilesByExtension dir extension
  case files of
    [] -> return Nothing
    path:_ -> return (Just path)

findImmediateFilesByExtension :: FilePath -> String -> IO [FilePath]
findImmediateFilesByExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      filterM doesFileExist [dir </> entry | entry <- entries, takeExtension entry == extension]

findFilesByExtension :: FilePath -> String -> IO [FilePath]
findFilesByExtension dir extension = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      fmap concat $
        forM entries $ \entry -> do
          let path = dir </> entry
          isDir <- doesDirectoryExist path
          isFile <- doesFileExist path
          if isDir
            then findFilesByExtension path extension
            else return [path | isFile && takeExtension path == extension]

findFilesByExtensions :: FilePath -> [String] -> IO [FilePath]
findFilesByExtensions dir extensions = do
  exists <- doesDirectoryExist dir
  if not exists
    then return []
    else do
      entries <- listDirectory dir
      fmap concat $
        forM entries $ \entry -> do
          let path = dir </> entry
          isDir <- doesDirectoryExist path
          isFile <- doesFileExist path
          if isDir
            then findFilesByExtensions path extensions
            else return [path | isFile && takeExtension path `elem` extensions]

parseIndentedList :: String -> String -> [String]
parseIndentedList key text =
  let rest = dropWhile (not . (key `isPrefixOf`) . trim) (lines text)
  in case rest of
       [] -> []
       _:items -> map trimListItem (takeWhile isListItem items)

isListItem :: String -> Bool
isListItem line =
  let value = trim line
  in not (null value) && not (":" `isSuffixOf` value) && (isSpaceChar (safeHead line) || "- " `isPrefixOf` value)

trimListItem :: String -> String
trimListItem line =
  let value = trim line
  in if "- " `isPrefixOf` value
       then trim (drop 2 value)
       else value

safeHead :: String -> Char
safeHead value =
  case value of
    [] -> ' '
    char:_ -> char

isSpaceChar :: Char -> Bool
isSpaceChar char =
  char == ' ' || char == '\t'

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile isSpaceChar
