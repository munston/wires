module Wires.Extensions.Cog where

newtype CogFile = CogFile { cogText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".cog"

parseCog :: String -> Either String CogFile
parseCog = Right . CogFile

renderCog :: CogFile -> String
renderCog = cogText

validateCog :: CogFile -> Either String ()
validateCog _ = Right ()

