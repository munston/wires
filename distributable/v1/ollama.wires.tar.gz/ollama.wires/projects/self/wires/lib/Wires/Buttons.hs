{-|
Module: Wires.Buttons

Purpose:
	High-level description for the "buttons" UI layer. This module
	documents the intent of the button-driven workflows used by the
	`install.bat` and per-package `.buttons` files. It intentionally
	contains no runtime code; the module is a single place to explain
	the mapping between UI buttons and underlying `Wires.*`
	implementation points.

Roles documented:
	- Which `Wires.Build` functions are invoked for common button
		actions (clean, halt, verify, install).
	- Expected stdout strings for success/failure so cogs can assert
		on them.

Usage:
	This module is read by maintainers and by generated companion
	`*.buttons` documentation; it is not required at runtime.
-}
module Wires.Buttons where


