module Wires.Extensions.Button where

data ButtonFile =
  ButtonFile
    { buttonEndpoint :: String
    , buttonArgument :: String
    }
  deriving (Eq, Show, Read)

extension :: String
extension = ".button"

parseButton :: String -> Either String ButtonFile
parseButton text =
  case reads text of
    [((endpoint, argument), rest)] | all (`elem` " \r\n\t") rest -> Right (ButtonFile endpoint argument)
    _ -> Left "Unable to parse .button as a Haskell (String, String) pair."

renderButton :: ButtonFile -> String
renderButton (ButtonFile endpoint argument) = show (endpoint, argument)

validateButton :: ButtonFile -> Either String ()
validateButton (ButtonFile endpoint argument)
  | null endpoint = Left ".button endpoint must not be empty."
  | null argument = Left ".button argument must not be empty."
  | otherwise = Right ()
