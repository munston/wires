{-# LANGUAGE ScopedTypeVariables #-}

module Wires.Unregister where

import System.FilePath
import qualified Folders.Project as FP
import qualified Wires.Cast as WC
import qualified Wires.Build as WB
import Control.Exception

-- | Force removal of exact registration lines only (no directory deletion,
-- no verification cleanup). This is the recovery command when normal
-- unregistration is blocked by file locks etc.
purgePackageRegistration :: FilePath -> FilePath -> IO String
purgePackageRegistration root packageRelative = do
  r <- FP.purgePackageRegistration root packageRelative
  _ <- WC.castWiresRoot root `catch` (\(_ :: SomeException) -> return "cast skipped due to error")
  return r

-- | Legacy project-name based removal (guessing old hello-style paths).
-- Prefer 'unregisterPackage' with the exact string from wire.project.
unregisterProject :: FilePath -> String -> IO String
unregisterProject root projectName = do
  r <- FP.removeProject root projectName
  _ <- WB.cleanProjectVerification root projectName
    `catch` (\(_ :: SomeException) -> return "verification clean skipped (legacy path)")
  _ <- WC.castWiresRoot root `catch` (\(_ :: SomeException) -> return "cast skipped due to error")
  return r

-- | Canonical exact-path unregistration.
--
-- Takes the precise 'packageRelative' string as it appears in projects/wire.project
-- (e.g. "aws-host/aws-host" or "stage_pipeline_demo/src/stage_pipeline_demo").
--
-- Critical ordering:
--   1. Clean verification *first* (while the entry is still in wire.project)
--   2. Then perform directory deletion + exact list cleanup via Folders
--   3. Finally re-cast
--
-- Uses cleanProjectVerificationExact so it remains safe even if the package
-- is no longer registered when cleanup runs.
unregisterPackage :: FilePath -> FilePath -> IO String
unregisterPackage root packageRelative = do
  _ <- WB.cleanProjectVerificationExact root packageRelative
         `catch` (\(_ :: SomeException) -> return "verification clean skipped")

  r <- FP.unregisterPackage root packageRelative

  _ <- WC.castWiresRoot root `catch` (\(_ :: SomeException) -> return "cast skipped due to error")

  return r

-- | Wires-level wrapper for removing an entire top-level project bucket.
removeTopLevelProject :: FilePath -> String -> IO String
removeTopLevelProject root topLevel = do
  r <- FP.removeTopLevelProject root topLevel
  -- Best effort: we don't have a perfect way to know every sub-package that lived under it,
  -- so we do a full re-cast after the directory is gone. Verification for the prefix
  -- is left to manual --clean-verification or a future bulk cleaner.
  _ <- WC.castWiresRoot root `catch` (\(_ :: SomeException) -> return "cast skipped due to error")
  return r
