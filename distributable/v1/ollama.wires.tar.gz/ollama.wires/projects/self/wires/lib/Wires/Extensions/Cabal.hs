module Wires.Extensions.Cabal where

newtype CabalFile = CabalFile { cabalText :: String }
  deriving (Eq, Show)

extension :: String
extension = ".cabal"

parseCabal :: String -> Either String CabalFile
parseCabal = Right . CabalFile

renderCabal :: CabalFile -> String
renderCabal = cabalText

validateGeneratedCabal :: CabalFile -> Either String ()
validateGeneratedCabal _ = Right ()

