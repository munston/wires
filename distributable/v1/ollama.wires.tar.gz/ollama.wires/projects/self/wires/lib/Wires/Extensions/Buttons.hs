module Wires.Extensions.Buttons where

newtype ButtonsFile = ButtonsFile { buttonEntries :: [FilePath] }
  deriving (Eq, Show)

extension :: String
extension = ".buttons"

parseButtons :: String -> Either String ButtonsFile
parseButtons =
  Right . ButtonsFile . filter (not . ignored) . map trim . lines

renderButtons :: ButtonsFile -> String
renderButtons = unlines . buttonEntries

validateButtons :: ButtonsFile -> Either String ()
validateButtons (ButtonsFile entries)
  | null entries = Left ".buttons must contain at least one .button entry."
  | all hasButtonExtension entries = Right ()
  | otherwise = Left ".buttons entries must reference .button files."

hasButtonExtension :: FilePath -> Bool
hasButtonExtension path = reverse (take 7 (reverse path)) == ".button"

ignored :: String -> Bool
ignored value = null value || take 1 value == "#"

trim :: String -> String
trim = f . f
  where
    f = reverse . dropWhile (`elem` " \r\n\t")

