{-# LANGUAGE OverloadedStrings #-}

module Wires.Load
  ( FileKind(..)
  , FileEntry(..)
  , loadWiresRoot
  , loadWiresSummary
  , listFilesRecursive
  ) where

import System.Directory
  ( listDirectory
  , doesDirectoryExist
  , canonicalizePath
  )
import System.FilePath
  ( (</>)
  , takeExtension
  , takeFileName
  , splitDirectories
  )
import Control.Monad
import Data.Text
import qualified Data.Text.IO as T
import Control.Exception
import Data.Char
import Data.List
import qualified Data.Map.Strict as M
import Data.Foldable

-- | Concrete file kinds we care about when loading the wires tree
data FileKind
  = Hs
  | Cabal
  | CabalProject
  | WireProject
  | ButtonsMeta
  | Button
  | ButtonSkip
  | Plan
  | Bat
  | Txt
  | Md
  | Json
  | Other
  deriving (Show, Eq, Ord)

-- | A loaded textual file with its kind and contents
data FileEntry = FileEntry
  { fePath :: FilePath
  , feKind :: FileKind
  , feContents :: Text
  } deriving (Show)

-- Default directory names to skip while walking the tree
defaultExcludes :: [String]
defaultExcludes = ["walks", "external", "dist-newstyle", ".git", "dist", "tmp", "build", "node_modules"]

-- | Recursively list files under a directory while skipping common irrelevant dirs.
-- Directories named ".buttons" are NOT skipped so their contents are included.
listFilesRecursive :: [FilePath] -> FilePath -> IO [FilePath]
listFilesRecursive excludes top = do
  root <- canonicalizePath top
  go root
 where
  go dir = do
    entries <- listDirectory dir
    fmap concat $ forM entries $ \e -> do
      let path = dir </> e
      isDir <- doesDirectoryExist path
      if isDir
        then if (map toLower e) `elem` map (map toLower) excludes && map toLower e /= ".buttons"
               then return []
               else go path
        else return [path]

-- | Classify a filepath into one of the FileKind categories
classifyFile :: FilePath -> FileKind
classifyFile fp =
  let fname = map toLower (takeFileName fp)
      ext = map toLower (takeExtension fp)
      comps = map (map toLower) (splitDirectories fp)
      inButtons = ".buttons" `elem` comps
  in if fname == "wire.project" then WireProject
     else if fname == "cabal.project" then CabalProject
     else if ".button.skip" `isSuffixOf` fname then ButtonSkip
     else if ".button" `isSuffixOf` fname then Button
     else if ext == ".buttons" then ButtonsMeta
     else if ext == ".cabal" then Cabal
     else if ext == ".hs" || ext == ".lhs" then Hs
     else if ext == ".plan" || fname == "buttons.plan" then Plan
     else if ext == ".bat" then Bat
     else if ext == ".txt" then Txt
     else if ext == ".md" then Md
     else if ext == ".json" then Json
     else Other

-- | Decide whether to include a file in the loader's output
shouldIncludeFile :: FilePath -> Bool
shouldIncludeFile fp =
  case classifyFile fp of
    Other -> False
    _     -> True

-- | Read a text file safely, returning Nothing on read errors
readTextFileSafe :: FilePath -> IO (Maybe Text)
readTextFileSafe fp = do
  r <- try (T.readFile fp) :: IO (Either SomeException Text)
  case r of
    Left _ -> return Nothing
    Right t -> return (Just t)

-- | Load the wires root: return all textual FileEntry values matching our filters
loadWiresRoot :: FilePath -> IO [FileEntry]
loadWiresRoot root = do
  files <- listFilesRecursive defaultExcludes root
  let filtered = filter shouldIncludeFile files
  fmap concat $ forM filtered $ \fp -> do
    mtxt <- readTextFileSafe fp
    case mtxt of
      Nothing -> return []
      Just txt -> return [FileEntry fp (classifyFile fp) txt]

-- | Print a simple summary of loaded files by kind
loadWiresSummary :: FilePath -> IO ()
loadWiresSummary root = do
  entries <- loadWiresRoot root
  let counts = foldl' (\m e -> M.insertWith (+) (feKind e) 1 m) M.empty entries
  putStrLn "Loaded file counts by kind:"
  mapM_ (\(k,v) -> putStrLn $ show k ++ ": " ++ show v) (M.toList counts)
