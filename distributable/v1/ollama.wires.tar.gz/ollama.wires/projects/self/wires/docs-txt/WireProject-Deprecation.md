Wire.project deprecation and fallback
====================================

Summary
-------
This change begins a cautious migration away from `projects/wire.project` as
the sole source of package discovery. `wire.project` remains the preferred
metadata source, but when it is absent Wires will now fall back to
`projects/cabal.project` for the `packages:` and `bootstrap-packages:` lists.

Why
---
- `cabal.project` already contains the authoritative Cabal package list used
  by Cabal itself. Maintaining two independent package lists (`wire.project`
  and `cabal.project`) has led to duplication and occasional drift.
- This fallback allows you to deprecate `wire.project` without breaking the
  Buttons/onepush build flow.

Behavior
--------
- When `projects/wire.project` exists, Wires continues to use it for discovery
  and for the richer workspace metadata it contains.
- When `projects/wire.project` is missing, Wires will read
  `projects/cabal.project` and extract the indented `packages:` and
  `bootstrap-packages:` lists to discover packages.
- `Wires.Cast.writeCabalProject` will no longer overwrite an existing
  `projects/cabal.project` unless that file contains the marker
  `-- generated-by: wires cast`. If the existing file appears to be
  manually-managed, the generated content will be written to
  `projects/cabal.project.wires.generated` instead.

Migration steps
---------------
1. If you intend to stop using `wire.project`, ensure that
   `projects/cabal.project` contains a complete `packages:` list matching the
   intended workspace layout.
2. Remove `projects/wire.project` when ready. Wires will then pick up
   `projects/cabal.project` automatically.
3. Review any `projects/cabal.project.wires.generated` files and replace
   `projects/cabal.project` with the generated content if appropriate.

Notes and next steps
--------------------
- This is a conservative, low-risk change intended to preserve existing
  behavior while enabling migration. A full deprecation (migrating all
  `wire.project` metadata into other files) is possible but requires more
  careful planning; this patch intentionally focuses only on package
  discovery and avoiding accidental file clobbering.

Files changed
-------------
- `projects/self/wires/lib/Wires/Build.hs`: added fallback discovery to
  `projects/cabal.project` when `wire.project` is absent.
- `projects/self/wires/lib/Wires/Cast.hs`: avoid overwriting non-generated
  `projects/cabal.project` (writes `.wires.generated` instead).
