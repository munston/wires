WireProject → Cabal.project Migration Notes
==========================================

Goal
----
Make the `wire.project` ↔ `projects/cabal.project` transform bijective and
identity-preserving except for normalising package paths so that any
"../"-style or non-canonical paths are represented as `projects/<path>` in
the canonical form. No other metadata should be introduced or retained in
`wire.project` beyond the package lists; per-package descriptors (`.nut`,
`.bolt`, `.cog`) remain unchanged and outside this transform.

Design constraints (explicit)
- Discovery may be performed from either representation (`wire.project` or
  `projects/cabal.project`).
- There must be a lossless round-trip: casting from `wire` → `cabal` and back
  yields the original logical workspace modulo the canonical path normalisation.
- Do not add new metadata fields to `wire.project`. `name`/`author` are not
  required; package identity is the final path suffix.
- `projects/` is the canonical top-level package folder; any paths that used
  `../` must be rewritten to `projects/<normalized-path>`.
- `Wires.Cast` MUST overwrite `projects/cabal.project` (this is the swap).
- Buttons and build resolution operate from the repo root and use the
  canonical `projects/*` paths.

Summary of responsibilities (who is authoritative for what)
- packages discovery: `projects/cabal.project` or `projects/wire.project`
- layout: always `projects/<path>` (no extra descriptor required)
- go / cog: per-package descriptors (`.nut` / `.cog`) and generated sources
- verification / snapshots: no extra root metadata required (confirm by
  checking for `version-policy` uses before full migration)

Canonical normalisation rule
- For any package path encountered during cast or parse:
  1. If the path begins with `..` or is an absolute path that points
     inside the workspace, convert it to a relative path under `projects/`.
  2. Produce the canonical package path form: `projects/<relative-path>`
  3. When rendering `wire.project` from `projects/cabal.project`, write the
     normalized `projects/<relative-path>` lines, one per package.

Patch Notes (exact edits for implementer)
----------------------------------------
1) Parser / Renderer (bidirectional)
   - File: `projects/self/wires/lib/Wires/Object.hs` / `Wires/Build.hs`
     - Add helpers:
       - `canonicaliseToProjects :: FilePath -> FilePath -> FilePath`
         - Converts an incoming path (possibly `..`-prefixed) to
           `projects/<normalized-path>` relative to the workspace root.
       - `parsePackagesFromCabalProject :: FilePath -> IO [FilePath]`
         - Read `projects/cabal.project`, parse indented `packages:` and
           `bootstrap-packages:` lists using existing `parseIndentedList`.
         - Apply `canonicaliseToProjects` to each entry.
     - Update discovery to prefer `wire.project` when present; otherwise
       call `parsePackagesFromCabalProject` and construct the
       `WiresPackageLocation` list.

2) Cast (overwrite semantics)
   - File: `projects/self/wires/lib/Wires/Cast.hs`
     - Modify `writeCabalProject` to *always overwrite* `projects/cabal.project`
       with the canonical package list produced from the `WiresObject`.
     - Implement `writeWireProjectFromCabal :: FilePath -> IO ()` which reads
       `projects/cabal.project` and emits `projects/wire.project` using the
       canonical paths (this is the inverse morphism used by
       `wires migrate --to-wire`).

3) CLI migration helpers
   - Add CLI commands (bin/exe or existing buttons hooks):
     - `wires migrate --to-cabal`:
         - Read `projects/wire.project` (or per-package descriptors),
           canonicalise paths, and call the cast routine to overwrite
           `projects/cabal.project`.
         - Create a timestamped backup of `projects/wire.project` before
           overwriting `projects/cabal.project`.
     - `wires migrate --to-wire`:
         - Read `projects/cabal.project` and render `projects/wire.project`
           (canonical paths). Backup existing `projects/wire.project`.

4) Tests
   - Add unit tests under the existing test harness (preferred location:
     `projects/self/wires/test/`) covering:
     - Round-trip `wire -> cabal -> wire` identity (modulo canonical paths).
     - Canonicalisation behaviour for `../relative/path` → `projects/...`.
     - `onepush`/buttons smoke test using generated `projects/cabal.project`.

5) Verification check
   - Before removing any metadata, grep the codebase (Wires and scripts)
     for uses of `version-policy`, `snapshot-policy`, `bin-folder`,
     `wire-entry`, `buttons:` etc. If any of those are used to drive
     behaviour, note them and decide relocation; otherwise no action needed.

Notes on rollout
----------------
- This patch set is a behavioural change: `Wires.Cast` will overwrite the
  authoritative `projects/cabal.project`. Communicate this to the team and
  ensure backups are created automatically by the `migrate` helpers.
- Begin with Option: implement parser/renderers & `wires migrate` commands,
  run tests and `onepush` locally, then flip `wire.project` → deprecated.

Manual verification steps (recommended after applying patch)
----------------------------------------------------------
1. Run: `wires migrate --to-cabal` (creates backup of `projects/wire.project`).
2. Inspect `projects/cabal.project` — confirm `packages:` lines are canonical.
3. Run: `cabal build --project-file=projects/cabal.project` from repo root
   (sanity) or `.
   onepush.bat` (the actual `onepush.bat` flow) and confirm the build step
   no longer emits Cabal-7136 for canonicalised packages.
4. Run: `wires migrate --to-wire` and confirm the generated `projects/wire.project`
   matches expectations (paths are canonical under `projects/`).

Rollback
--------
- The `migrate` commands should create backups. To rollback, restore the
  backed-up file(s) and re-run the appropriate `wires` command or revert the
  Git commit that introduced the migration patch.

Appendix: Example canonicalisation
---------------------------------
Input in `wire.project` or old layout:

  packages:
    ../projects/hello_world/src/hello_world

Canonical `projects/cabal.project` produced:

  packages:
    projects/hello_world/src/hello_world

This is the only allowed semantic change; everything else must remain
bijective.
