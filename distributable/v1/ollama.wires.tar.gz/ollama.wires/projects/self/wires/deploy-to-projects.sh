#!/usr/bin/env sh
set -eu

rm -rf bin
cabal install all:exes --project-file=cabal.project --installdir=bin --install-method=copy --overwrite-policy=always
mkdir -p ../../bin
cp -f bin/wires ../../bin/wires
