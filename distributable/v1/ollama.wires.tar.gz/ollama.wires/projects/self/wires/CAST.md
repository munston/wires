Wires.Cast — Companion metadata
================================

Summary
-------

`Wires.Cast` is the generator backend that turns an in-memory
`WiresObject` (parsed from `wire.project`) into concrete, on-disk
Haskell packaging artefacts: a top-level `cabal.project`, per-package
`<pkg>.cabal` manifests, and small generated sources (`exe/Main.hs`,
`cog/CogMain.hs`). This file complements the Haddock comments in the
module by explaining how each exported function maps to the user
interface (install/buttons) and how to reason about failures.

High-level flow
---------------

- `install.bat` (or the `buttons` flow) invokes `wires --cast` or
  similar. `Wires.Cast` performs the translation step that makes the
  project visible to Cabal. After `cast` completes, Cabal can build
  packages and run tests.

- The distinction between `compile` and `cast` in the UI:
  - `compile` writes generated source code (Main/CogMain) that is
    needed for quick development iteration and verification.
  - `cast` writes Cabal manifests and the `cabal.project` file so the
    package manager can build/pack the project.

Key entrypoints and UI mapping
------------------------------

- `compileWiresRoot root` — used by the `compile` button in the
  canonical install flow. It regenerates the package sources for all
  packages and returns a short status string: `"wires compile ok\npackages: N"`.

- `compileWiresProject root packageRelative` — used for focused
  re-generation when only one package changed. Returns `"wires compile ok\npackage: <path>"`.

- `castWiresRoot root` — the full cast that generates `cabal.project`
  and all package `.cabal` files. Called when transitioning from the
  generator model to a build-ready layout.

- `castWiresProject root packageRelative` — cast just one package and
  the top-level `cabal.project`. Helpful for iterative development of
  a single package.

Implementation details & notes
------------------------------

- Idempotence: generated directories are reset by `resetGeneratedDir`
  and old `.cabal` files are removed by `removeGeneratedCabalFiles` to
  avoid stale state.

- Module exposure: `renderCabalPackage` computes `exposed-modules`
  from the `nut` metadata and places remaining modules in
  `other-modules`. This is the mechanism used to ensure helper modules
  (e.g. `RobocopCompat`) are included in the package manifest.

- Generated `Main.hs`: the generated executable entry-point normalises
  command-line arguments and delegates to the package `go` dispatcher
  (`<GoModule>.go`). This is the bridging point between the
  runtime behaviour coded inside a package and the outside world that
  exercises it via textual CLI options (used by cogs).

Debugging & common failure modes
--------------------------------

- If `cast` fails with "package not found in wire.project" — check
  that the path used by the buttons is the normalized `wiresPackagePath`.

- If a helper module is missing during build (e.g. "Could not find
  module X"), confirm that `nutExposes` in the package `.nut` metadata
  includes the module or that `renderCabalPackage` computed
  `other-modules` correctly. Regenerating with `wires --cast` will
  overwrite the `.cabal` and reflect current `nut` data.

Where to look next
------------------

- Review `Wires.Object` and the `.nut` metadata format to see how
  `wiresPackageModules`, `wiresPackageNut`, and `wiresPackageCog` are
  populated — these are the inputs `Wires.Cast` relies on.

- The cog generation logic is in `renderCogMain` — understanding how
  `VerifiedRoute` entries map into generated `runCase` calls will
  clarify how runtime behaviours are asserted by the verification
  harness.

Examples
--------

From the wires root:

```powershell
.\install.bat
```

Or to iterate locally on a single package:

```powershell
wires.exe --compile-wires
wires.exe --cast --package hello_world
```

If you want, I will now proceed to `Wires.Check` and add the same
style of Haddock comments and a companion metadata file describing its
runtime and UI behaviour.
