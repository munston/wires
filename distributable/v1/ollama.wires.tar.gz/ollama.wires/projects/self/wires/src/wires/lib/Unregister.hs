module Wires.Unregister where

import System.FilePath
import qualified Folders.Project as FP
import qualified Wires.Cast as WC
import qualified Wires.Build as WB
import Control.Exception

-- | Wires-level unregister wrapper: remove via `Folders`, clean
-- verification stamps and .skip files for the project, then re-cast
-- so generated cabal files no longer reference the removed project.
--
-- This is the most complete removal currently available.
unregisterProject :: FilePath -> String -> IO String
unregisterProject root projectName = do
  -- 1. Perform the actual filesystem removal + best-effort list cleanup
  r <- FP.removeProject root projectName

  -- 2. Best-effort: clean verification data and any leftover .skip markers
  --    Note: we use the projectName as a heuristic for the packageRelative.
  --    For full reliability, future callers should pass the exact registered path.
  _ <- WB.cleanProjectVerification root projectName
    `catch` (\(_ :: IOException) -> return "verification clean skipped")

  -- 3. Re-cast to remove the package from generated cabal.project and manifests
  _ <- WC.castWiresRoot root `catch` (\(_ :: IOException) -> return ())

  return r
