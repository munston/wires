#!/usr/bin/env sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

(cd "$DIR/buttons" && sh ./deploy-to-projects.sh)
sh "$DIR/deploy-to-projects.sh"
