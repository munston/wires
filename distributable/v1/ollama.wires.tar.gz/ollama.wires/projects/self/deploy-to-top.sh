#!/usr/bin/env sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

(cd "$DIR/buttons" && sh ./deploy-to-top.sh)
(cd "$DIR/garrage" && sh ./deploy-to-top.sh)
(cd "$DIR/gofur" && sh ./deploy-to-top.sh)
(cd "$DIR/codfish" && sh ./deploy-to-top.sh)
(cd "$DIR/wires" && sh ./deploy-to-top.sh)
