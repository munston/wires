name: codfish
depends:
  wires
exposes:
  Codfish
go-is: Codfish.go
