module Codfish where

import Control.Monad
import Data.List
import Folders.Routes
import System.Directory
import System.FilePath
import System.IO
import Wires.Build

-- Codfish links Wires.Build directly, so documentation-stage behavior and
-- fingerprints are refreshed by reinstalling this executable through onepush.
verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--list\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts =
  [ RouteOptout { routeOptoutOption = "--generate-buttons", routeOptoutReason = "generates documentation-stage buttons before the buttonized phase runs" }
  , RouteOptout { routeOptoutOption = "--haddock", routeOptoutReason = "external Haddock documentation generation is verified by the document phase" }
  , RouteOptout { routeOptoutOption = "--codfish", routeOptoutReason = "external Codfish documentation extraction is verified by the document phase" }
  , RouteOptout { routeOptoutOption = "--record-documentation", routeOptoutReason = "records the documentation-stage fingerprint after the document sub-batch passes" }
  ]

go :: String -> [String] -> IO String
go "--list" [] = pure (show ["--list", "--generate-buttons", "--haddock", "--codfish", "--record-documentation"])
go "--list" _ = pure "--list expects no arguments"
go "--generate-buttons" [root] = generateCodfishButtons root
go "--generate-buttons" [root, mode] = generateCodfishButtonsWithMode root mode
go "--generate-buttons" _ = pure "usage: codfish.exe --generate-buttons <root> [--dont-exclude-bootstrap|--bootstrap-only]"
go "--haddock" [root, packageRelative] = cabalHaddockSingleProject root packageRelative
go "--haddock" _ = pure "usage: codfish.exe --haddock <root> <packageRelative>"
go "--codfish" [root, packageRelative] = codfishSingleProject root packageRelative
go "--codfish" _ = pure "usage: codfish.exe --codfish <root> <packageRelative>"
go "--record-documentation" [root, packageRelative] = recordDocumentationSingleProject root packageRelative
go "--record-documentation" _ = pure "usage: codfish.exe --record-documentation <root> <packageRelative>"
go option _ = pure ("unknown codfish option: " ++ option)

generateCodfishButtons :: FilePath -> IO String
generateCodfishButtons root =
  generateCodfishButtonsFor regularOnly root

generateCodfishButtonsWithMode :: FilePath -> String -> IO String
generateCodfishButtonsWithMode root mode =
  case parsePackageSelection mode of
    Just selection -> generateCodfishButtonsFor selection root
    Nothing -> return ("unknown package selection: " ++ mode)

generateCodfishButtonsFor :: PackageSelection -> FilePath -> IO String
generateCodfishButtonsFor selection root = do
  absoluteRoot <- makeAbsolute root
  packages <- discoverWiresPackagesWithSelection selection absoluteRoot
  let documentDir = absoluteRoot </> ".document"
      documentButtons = documentDir </> "document.buttons"
  createDirectoryIfMissing True documentDir
  cleanupInactiveDocumentButtons absoluteRoot (map packageRelativePath packages)
  projectSequences <- forM packages $ \package -> do
    let packageRel = packageArgument absoluteRoot (packageRelativePath package)
        buttonsDir = packageRoot absoluteRoot (packageRelativePath package) </> ".buttons"
        sequencePath = buttonsDir </> "document.buttons"
        endpoint = normalise (makeRelative buttonsDir (absoluteRoot </> "bin" </> toolExe "codfish"))
        targetArgument option = unwords [option, "..", packageRel]
        writeButton fileName option =
          writeGeneratedFile (buttonsDir </> fileName) (show (endpoint, targetArgument option) ++ "\n")
        entries =
          [ ("document-00-haddock.button", "--haddock")
          , ("document-01-codfish.button", "--codfish")
          , ("document-02-record-documentation.button", "--record-documentation")
          ]
    createDirectoryIfMissing True buttonsDir
    current <- isDocumentationCurrent absoluteRoot (packageRelativePath package)
    if current then return () else removeDocumentSkips buttonsDir
    cleanupStaleDocumentArtifacts buttonsDir ("document.buttons" : map fst entries)
    forM_ entries (uncurry writeButton)
    writeGeneratedFile sequencePath (unlines (map fst entries))
    return sequencePath
  writeGeneratedFile documentButtons (unlines (map (normalise . makeRelative documentDir) projectSequences))
  return ("generated codfish documentation buttons\npackages: " ++ show (length packages))

packageRoot :: FilePath -> FilePath -> FilePath
packageRoot root relative =
  let value = normalise relative
  in if isAbsolute value
       then
         case splitDirectories (normalise (makeRelative root value)) of
           "projects":_ -> value
           rest -> root </> "projects" </> joinPath rest
       else
         case splitDirectories value of
           "projects":rest -> root </> "projects" </> joinPath rest
           _ -> root </> "projects" </> value

packageArgument :: FilePath -> FilePath -> FilePath
packageArgument root relative =
  normalise (makeRelative (root </> "projects") (packageRoot root relative))

isDocumentationCurrent :: FilePath -> FilePath -> IO Bool
isDocumentationCurrent root packageRelative = do
  current <- computeProjectStageFingerprint root packageRelative "documentation.stamp"
  let stampFile = stageProjectStampFile root packageRelative "documentation.stamp"
  exists <- doesFileExist stampFile
  if not exists
    then return False
    else do
      recorded <- withFile stampFile ReadMode hGetLine
      return (recorded == current)

removeDocumentSkips :: FilePath -> IO ()
removeDocumentSkips buttonsDir = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if ("document" `isPrefixOf` entry || entry == "document.buttons.skip") && ".skip" `isSuffixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

cleanupInactiveDocumentButtons :: FilePath -> [FilePath] -> IO ()
cleanupInactiveDocumentButtons root activePackages = do
  buttonsDirs <- discoverCodfishButtonsDirs (root </> "projects")
  let active = map normalise activePackages
  forM_ buttonsDirs $ \buttonsDir -> do
    let packageRelative = normalise (makeRelative (root </> "projects") (takeDirectory buttonsDir))
    if packageRelative `elem` active
      then removeOldDocumentationAlias buttonsDir
      else removeDocumentPhaseFiles buttonsDir

discoverCodfishButtonsDirs :: FilePath -> IO [FilePath]
discoverCodfishButtonsDirs projectsRoot = do
  exists <- doesDirectoryExist projectsRoot
  if not exists
    then return []
    else do
      projects <- listDirectory projectsRoot
      fmap concat $ forM projects $ \projectName -> do
        let srcRoot = projectsRoot </> projectName </> "src"
        srcExists <- doesDirectoryExist srcRoot
        if not srcExists
          then return []
          else do
            packages <- listDirectory srcRoot
            return [srcRoot </> packageName </> ".buttons" | packageName <- packages]

removeDocumentPhaseFiles :: FilePath -> IO ()
removeDocumentPhaseFiles buttonsDir = do
  exists <- doesDirectoryExist buttonsDir
  if not exists
    then return ()
    else do
      entries <- listDirectory buttonsDir
      forM_ entries $ \entry ->
        if "document" `isPrefixOf` entry || "documentation" `isPrefixOf` entry
          then removeFile (buttonsDir </> entry)
          else return ()

removeOldDocumentationAlias :: FilePath -> IO ()
removeOldDocumentationAlias buttonsDir = do
  let oldPath = buttonsDir </> "documentation.buttons"
  exists <- doesFileExist oldPath
  if exists then removeFile oldPath else return ()

cleanupStaleDocumentArtifacts :: FilePath -> [FilePath] -> IO ()
cleanupStaleDocumentArtifacts buttonsDir keep = do
  exists <- doesDirectoryExist buttonsDir
  when exists $ do
    entries <- listDirectory buttonsDir
    forM_ entries $ \entry ->
      when ((("document" `isPrefixOf` entry) || ("documentation" `isPrefixOf` entry)) && entry `notElem` keep && takeExtension entry `elem` [".button", ".buttons"]) $ do
        fileExists <- doesFileExist (buttonsDir </> entry)
        when fileExists (removeFile (buttonsDir </> entry))
