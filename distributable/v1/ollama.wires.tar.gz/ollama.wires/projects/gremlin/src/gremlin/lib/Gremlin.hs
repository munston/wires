module Gremlin where

import Gremlin.Header (buildFixPrompt)
import Data.List (isInfixOf)
import qualified Nvidia.NIM as NIM
import qualified NemotronLib as NemotronLib
import qualified Data.Text as T
import System.Environment (lookupEnv)

data VerifiedRoute =
  VerifiedRoute
    { routeOption :: String
    , routeArgs :: [String]
    , routePrecog :: String
    }
  deriving (Eq, Read, Show)

data RouteOptout =
  RouteOptout
    { routeOptoutOption :: String
    , routeOptoutReason :: String
    }
  deriving (Eq, Read, Show)

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--fix-compile\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--help", routeArgs = [], routePrecog = "\\s -> \"compile fixer\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--fix-compile", routeArgs = ["avocado compile error"], routePrecog = "\\s -> \"Compilation failed\" `isInfixOf` s && \"avocado compile error\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--submit-diff", routeArgs = ["src/Foo.hs", "--- a/src/Foo.hs\n+++ b/src/Foo.hs"], routePrecog = "\\s -> \"diff review\" `isInfixOf` s && \"src/Foo.hs\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts = []

-- | Entry point for the gremlin worker (LLM-orchestrated compile/fix + diff submission).
-- Uses the real Nemotron LLM from the nvidia project via chat.
go :: String -> [String] -> IO String
go "--list" [] = pure (show (["--list", "--help", "--fix-compile", "--submit-diff"] :: [String]))
go "--list" _ = pure "--list expects no arguments"
go "--help" _ = pure "gremlin: LLM-driven compile fixer and diff submitter for wires + starship projects. Use --fix-compile <error> or --submit-diff <file> <diff>."
go "--fix-compile" [err] = do
  live <- liveGremlinEnabled
  if live
    then askNemotronFix err
    else pure (T.unpack (buildFixPrompt (T.pack err) []))
go "--fix-compile" _ = pure "Usage: --fix-compile \"<error description or log>\""
go "--submit-diff" [file, diff] = do
  live <- liveGremlinEnabled
  if live
    then askNemotronDiff file diff
    else pure ("gremlin diff review prepared for " ++ file ++ "\n" ++ take 400 diff)
go "--submit-diff" _ = pure "Usage: --submit-diff <file> <diff-content>"
go option args = pure ("unknown gremlin option: " ++ option ++ " " ++ show args)

liveGremlinEnabled :: IO Bool
liveGremlinEnabled = do
  value <- lookupEnv "GREMLIN_LIVE_COG"
  pure (value == Just "1")

askNemotronFix :: String -> IO String
askNemotronFix err = do
  keyStr <- NemotronLib.loadNvidiaApiKey
  let key = T.pack keyStr
  let base = NIM.defaultBaseUrl
  let mdl = NIM.defaultModel
  let msgs = [ NIM.Message NIM.System (T.pack "You are Gremlin, an expert at fixing Haskell compile errors for wires and starship projects. Analyze the error and return a minimal unified diff patch to fix it, or a clear report if you cannot fix it.")
           , NIM.Message NIM.User (T.pack err) ]
  result <- NIM.chat key base mdl msgs
  case result of
    Left e -> pure $ "Error calling LLM: " ++ e
    Right resp -> pure $ T.unpack resp

askNemotronDiff :: FilePath -> String -> IO String
askNemotronDiff file diff = do
  keyStr <- NemotronLib.loadNvidiaApiKey
  let key = T.pack keyStr
  let base = NIM.defaultBaseUrl
  let mdl = NIM.defaultModel
  let prompt = "Review this diff for file " ++ file ++ " and provide a report on whether it is suitable for submission to a wires or starship project, any issues found, and a summary of the change.\n" ++ diff
  let msgs = [ NIM.Message NIM.System (T.pack "You are a code review assistant for Haskell changes in wires and starship projects. Provide clear reports.")
             , NIM.Message NIM.User (T.pack prompt) ]
  result <- NIM.chat key base mdl msgs
  case result of
    Left e -> pure $ "Error calling LLM: " ++ e
    Right resp -> pure $ T.unpack resp
