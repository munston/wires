-- generated-by: gofur codegen 0.1
module Main where

import Data.List
import System.Exit
import qualified Gremlin

main :: IO ()
main = do
  runCase "--list" [] (\s -> "--fix-compile" `isInfixOf` s)
  runCase "--help" [] (\s -> "compile fixer" `isInfixOf` s)
  runCase "--fix-compile" ["avocado compile error"] (\s -> "Compilation failed" `isInfixOf` s && "avocado compile error" `isInfixOf` s)
  runCase "--submit-diff" ["src/Foo.hs","--- a/src/Foo.hs\n+++ b/src/Foo.hs"] (\s -> "diff review" `isInfixOf` s && "src/Foo.hs" `isInfixOf` s)
  return ()

runCase :: String -> [String] -> (String -> Bool) -> IO ()
runCase option args predicate = do
  value <- Gremlin.go option args
  if predicate value
    then return ()
    else do
      putStrLn ("cog failed for " ++ option ++ ": " ++ value)
      exitFailure
