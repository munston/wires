name: gremlin
depends:
  text
  nemotron
exposes:
  Gremlin
go-is: Gremlin.go
