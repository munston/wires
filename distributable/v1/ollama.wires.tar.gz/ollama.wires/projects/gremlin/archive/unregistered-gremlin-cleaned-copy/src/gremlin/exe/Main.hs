-- generated-by: gofur codegen 0.1
module Main where

import System.Environment
import qualified Gremlin

main :: IO ()
main = getArgs >>= dispatch . normalizeArgs

normalizeArgs :: [String] -> [String]
normalizeArgs [single] = words single
normalizeArgs args = args

dispatch :: [String] -> IO ()
dispatch (option : args) = Gremlin.go option args >>= print >> return ()
dispatch [] = fail "missing gofur option"
