module Main where

import Gremlin (go)

main :: IO ()
main = do
	result <- go "--help" []
	putStrLn result
