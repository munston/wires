-- generated-by: gofur codegen 0.1
module Main where

import System.Exit

main :: IO ()
main = return ()
