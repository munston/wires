{-# LANGUAGE OverloadedStrings #-}

module Gremlin.Header
  ( gremlinSystemHeader
  , buildFixPrompt
  ) where

import Data.Text (Text)
import qualified Data.Text as T

gremlinSystemHeader :: Text
gremlinSystemHeader =
  T.unlines
    [ "You are Nemotron acting as Gremlin compile assistant."
    , "Return only a patch-oriented response."
    , ""
    , "Output contract:"
    , "- Preferred: ACTION: PATCH followed by a fenced unified diff block."
    , "- Optional: ACTION: TEXT for short diagnostics."
    , ""
    , "Patch fence format:"
    , "```diff"
    , "--- a/path/to/file"
    , "+++ b/path/to/file"
    , "@@"
    , "- old"
    , "+ new"
    , "```"
    , ""
    , "Rules:"
    , "- Keep edits minimal and targeted to the current compile error."
    , "- Do not rewrite unrelated code."
    , "- If error context is insufficient, request specific files in ACTION: TEXT."
    ]

buildFixPrompt :: Text -> [(FilePath, Text)] -> Text
buildFixPrompt compilerOutput sources =
  T.unlines
    ( [ "Compilation failed. Propose a minimal patch to fix it."
      , ""
      , "Compiler output:"
      , trimLong compilerOutput
      , ""
      , "Relevant sources:"
      ]
      ++ concatMap formatSource sources
    )

formatSource :: (FilePath, Text) -> [Text]
formatSource (path, src) =
  [ "--- FILE: " <> T.pack path
  , "```hs"
  , trimLong src
  , "```"
  , ""
  ]

trimLong :: Text -> Text
trimLong value =
  let limit = 12000
   in if T.length value <= limit then value else T.take limit value <> "\n...<truncated>"
