{-# LANGUAGE OverloadedStrings #-}

module Gremlin.CompileLoop
  ( GremlinConfig(..)
  , AttemptRecord(..)
  , GremlinReport(..)
  , runGremlinLoop
  , renderReport
  ) where

import Gremlin.Header (buildFixPrompt, gremlinSystemHeader)
import Gremlin.Nemotron (chatNemotron)
import Control.Exception (SomeException, try)
import Data.List (nub)
import Data.Maybe (mapMaybe)
import Data.Text (Text)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.Directory (doesFileExist, getTemporaryDirectory, removeFile)
import System.Exit (ExitCode(..))
import System.FilePath ((</>), isAbsolute)
import System.IO (hClose, openTempFile)
import System.Process (CreateProcess(cwd), readCreateProcessWithExitCode, shell)

data GremlinConfig = GremlinConfig
  { gcApiKey :: Text
  , gcBaseUrl :: Text
  , gcModel :: Text
  , gcWorkspaceRoot :: FilePath
  , gcCompileCommand :: String
  , gcMaxAttempts :: Int
  }

data AttemptRecord = AttemptRecord
  { arAttempt :: Int
  , arCompileExit :: ExitCode
  , arCompileOutput :: Text
  , arModelOutput :: Text
  , arPatchApplied :: Bool
  , arPatchApplyOutput :: Text
  }

data GremlinReport = GremlinReport
  { grSucceeded :: Bool
  , grAttempts :: [AttemptRecord]
  }

runGremlinLoop :: GremlinConfig -> IO GremlinReport
runGremlinLoop cfg = go 1 []
  where
    go n acc
      | n > gcMaxAttempts cfg = pure (GremlinReport False (reverse acc))
      | otherwise = do
          (compileExit, outText, errText) <- runCompile cfg
          let combined = outText <> "\n" <> errText
          case compileExit of
            ExitSuccess ->
              pure
                ( GremlinReport
                    True
                    ( reverse
                        ( AttemptRecord n compileExit combined "<compile success>" False "" : acc
                        )
                    )
                )
            ExitFailure _ -> do
              sources <- collectRelevantSources (gcWorkspaceRoot cfg) combined
              let prompt = buildFixPrompt combined sources
              modelResult <- chatNemotron (gcApiKey cfg) (gcBaseUrl cfg) (gcModel cfg) gremlinSystemHeader prompt
              case modelResult of
                Left modelErr ->
                  go
                    (n + 1)
                    ( AttemptRecord n compileExit combined (T.pack modelErr) False "model call failed"
                        : acc
                    )
                Right modelOut -> do
                  let mPatch = extractPatch modelOut
                  case mPatch of
                    Nothing ->
                      go
                        (n + 1)
                        ( AttemptRecord n compileExit combined modelOut False "no patch detected"
                            : acc
                        )
                    Just patchText -> do
                      (applied, applyOutput) <- applyPatch (gcWorkspaceRoot cfg) patchText
                      go
                        (n + 1)
                        ( AttemptRecord n compileExit combined modelOut applied applyOutput
                            : acc
                        )

runCompile :: GremlinConfig -> IO (ExitCode, Text, Text)
runCompile cfg = do
  (exitCode, outText, errText) <-
    readCreateProcessWithExitCode ((shell (gcCompileCommand cfg)) {cwd = Just (gcWorkspaceRoot cfg)}) ""
  pure (exitCode, T.pack outText, T.pack errText)

collectRelevantSources :: FilePath -> Text -> IO [(FilePath, Text)]
collectRelevantSources root compileOutput = do
  let candidatePaths = nub (mapMaybe (candidatePath root) (T.lines compileOutput))
  files <- mapM readMaybeFile (take 6 candidatePaths)
  pure (mapMaybe id files)

candidatePath :: FilePath -> Text -> Maybe FilePath
candidatePath root line =
  let rawPath = T.unpack (T.takeWhile (/= ':') line)
      hasSeparator = any (`elem` ['/', '\\']) rawPath
   in if null rawPath || not hasSeparator
        then Nothing
        else if isAbsolute rawPath
          then Just rawPath
          else Just (root </> rawPath)

readMaybeFile :: FilePath -> IO (Maybe (FilePath, Text))
readMaybeFile path = do
  exists <- doesFileExist path
  if not exists
    then pure Nothing
    else do
      eres <- try (TIO.readFile path) :: IO (Either SomeException Text)
      case eres of
        Left _ -> pure Nothing
        Right content -> pure (Just (path, content))

extractPatch :: Text -> Maybe Text
extractPatch raw =
  case dropWhile (not . isDiffFence) (T.lines raw) of
    [] -> fallbackRawDiff raw
    _fence : rest ->
      let body = takeWhile (/= "```") rest
       in if null body then fallbackRawDiff raw else Just (T.unlines body)

fallbackRawDiff :: Text -> Maybe Text
fallbackRawDiff raw
  | any (T.isPrefixOf "--- ") ls && any (T.isPrefixOf "+++ ") ls = Just raw
  | otherwise = Nothing
  where
    ls = T.lines raw

isDiffFence :: Text -> Bool
isDiffFence line = line == "```diff" || line == "```patch"

applyPatch :: FilePath -> Text -> IO (Bool, Text)
applyPatch workspaceRoot patchText = do
  tempDir <- getTemporaryDirectory
  (tempPath, handle) <- openTempFile tempDir "gremlin.patch"
  TIO.hPutStr handle patchText
  hClose handle
  (exitCode, outText, errText) <-
    readCreateProcessWithExitCode
      ((shell ("git apply --whitespace=nowarn --recount \"" ++ tempPath ++ "\"")) {cwd = Just workspaceRoot})
      ""
  _ <- try (removeFile tempPath) :: IO (Either SomeException ())
  let combined = T.pack outText <> T.pack errText
  pure (exitCode == ExitSuccess, combined)

renderReport :: GremlinReport -> Text
renderReport report =
  T.unlines
    ( [ "Gremlin compile report"
      , "Succeeded: " <> (if grSucceeded report then "yes" else "no")
      , "Attempts: " <> T.pack (show (length (grAttempts report)))
      , ""
      ]
      ++ concatMap renderAttempt (grAttempts report)
    )

renderAttempt :: AttemptRecord -> [Text]
renderAttempt attempt =
  [ "Attempt " <> T.pack (show (arAttempt attempt))
  , "Compile exit: " <> T.pack (show (arCompileExit attempt))
  , "Patch applied: " <> (if arPatchApplied attempt then "yes" else "no")
  , "Compile output (truncated):"
  , truncateText (arCompileOutput attempt)
  , "Model output (truncated):"
  , truncateText (arModelOutput attempt)
  , "Patch apply output (truncated):"
  , truncateText (arPatchApplyOutput attempt)
  , ""
  ]

truncateText :: Text -> Text
truncateText value =
  let limit = 3000
   in if T.length value <= limit then value else T.take limit value <> "\n...<truncated>"
