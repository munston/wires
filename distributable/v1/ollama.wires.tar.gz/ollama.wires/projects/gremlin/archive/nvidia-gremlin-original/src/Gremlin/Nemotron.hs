{-# LANGUAGE OverloadedStrings #-}

module Gremlin.Nemotron
  ( chatNemotron
  ) where

import Data.Aeson
import Data.Text (Text)
import qualified Data.ByteString.Char8 as BS
import qualified Data.ByteString.Lazy as LBS
import qualified Data.Text as T
import Network.HTTP.Client
import Network.HTTP.Client.TLS
import Network.HTTP.Types.Header
import Network.HTTP.Types.Status

data Role = System | User deriving (Eq, Show)

data Message = Message Role Text deriving (Eq, Show)

data ChatRequest = ChatRequest Text [Message] Int Double Double deriving (Eq, Show)

newtype ChatResponse = ChatResponse Text deriving (Eq, Show)

roleText :: Role -> Text
roleText System = "system"
roleText User = "user"

trimRightSlash :: Text -> Text
trimRightSlash = T.dropWhileEnd (== '/')

instance ToJSON Message where
  toJSON (Message role content) =
    object
      [ "role" .= roleText role
      , "content" .= content
      ]

instance ToJSON ChatRequest where
  toJSON (ChatRequest model messages maxTokens temperature topP) =
    object
      [ "model" .= model
      , "messages" .= messages
      , "max_tokens" .= maxTokens
      , "temperature" .= temperature
      , "top_p" .= topP
      , "stream" .= False
      ]

instance FromJSON ChatResponse where
  parseJSON = withObject "ChatResponse" $ \o -> do
    choices <- o .: "choices"
    case choices of
      [] -> fail "response contained no choices"
      choice:_ -> do
        message <- choice .: "message"
        content <- message .: "content"
        pure (ChatResponse content)

chatNemotron :: Text -> Text -> Text -> Text -> Text -> IO (Either String Text)
chatNemotron apiKey baseUrl model systemHeader prompt = do
  manager <- newManager tlsManagerSettings
  initial <- parseRequest (T.unpack (trimRightSlash baseUrl <> "/chat/completions"))
  let body = encode (ChatRequest model [Message System systemHeader, Message User prompt] 1024 0.2 0.95)
  let request =
        initial
          { method = "POST"
          , requestHeaders =
              [ (hAuthorization, BS.pack ("Bearer " <> T.unpack apiKey))
              , (hContentType, "application/json")
              ]
          , responseTimeout = responseTimeoutMicro (5 * 60 * 1000000)
          , requestBody = RequestBodyLBS body
          }
  response <- httpLbs request manager
  let responseBodyBytes = responseBody response
  let code = statusCode (responseStatus response)
  if code >= 300
    then pure (Left ("HTTP " <> show code <> "\n" <> take 5000 (showLazy responseBodyBytes)))
    else case eitherDecode responseBodyBytes of
      Left err -> pure (Left ("JSON decode failed: " <> err <> "\n" <> take 5000 (showLazy responseBodyBytes)))
      Right (ChatResponse content) -> pure (Right content)

showLazy :: LBS.ByteString -> String
showLazy = BS.unpack . LBS.toStrict
