{-# LANGUAGE OverloadedStrings #-}

module Main where

import Gremlin.CompileLoop
  ( GremlinConfig(..)
  , renderReport
  , runGremlinLoop
  )
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import System.Environment (getArgs)
import System.Exit (exitFailure)
import Text.Read (readMaybe)

main :: IO ()
main = do
  args <- getArgs
  case args of
    apiKey : workspaceRoot : rawMaxAttempts : compileCommandParts ->
      case readMaybe rawMaxAttempts of
        Nothing -> usage
        Just maxAttempts
          | maxAttempts <= 0 -> usage
          | null compileCommandParts -> usage
          | otherwise -> do
              let config =
                    GremlinConfig
                      { gcApiKey = T.pack apiKey
                      , gcBaseUrl = "https://integrate.api.nvidia.com/v1"
                      , gcModel = "nvidia/nemotron-3-super-120b-a12b"
                      , gcWorkspaceRoot = workspaceRoot
                      , gcCompileCommand = unwords compileCommandParts
                      , gcMaxAttempts = maxAttempts
                      }
              report <- runGremlinLoop config
              TIO.putStrLn (renderReport report)
    _ -> usage

usage :: IO ()
usage = do
  putStrLn "Usage: gremlin <api-key> <workspace-root> <max-attempts> <compile-command...>"
  putStrLn "Example: gremlin nvapi-... C:\\repo 5 .\\install.bat"
  exitFailure
