{-# LANGUAGE OverloadedStrings #-}

module Nvidia.Codegen.Output
  ( CodegenOutput(..)
  , parseCodegenOutput
  ) where

import Data.Text (Text)
import qualified Data.Text as T

data CodegenOutput
  = ButtonAction Text
  | RunAction Text
  | PatchAction Text
  | FreeText Text
  deriving (Eq, Show)

parseCodegenOutput :: Text -> CodegenOutput
parseCodegenOutput raw
  | Just button <- parsePrefixedAction "ACTION: BUTTON " raw = ButtonAction button
  | Just command <- parsePrefixedAction "ACTION: RUN " raw = RunAction command
  | isPatchAction raw
  , Just patch <- extractDiffBlock raw = PatchAction patch
  | Just text <- parsePrefixedAction "ACTION: TEXT " raw = FreeText text
  | Just patch <- extractDiffBlock raw = PatchAction patch
  | otherwise = FreeText raw

parsePrefixedAction :: Text -> Text -> Maybe Text
parsePrefixedAction prefix raw =
  case T.lines raw of
    [] -> Nothing
    firstLine : _
      | prefix `T.isPrefixOf` firstLine -> Just (T.strip (T.drop (T.length prefix) firstLine))
      | otherwise -> Nothing

isPatchAction :: Text -> Bool
isPatchAction raw =
  case T.lines raw of
    [] -> False
    firstLine : _ ->
      let stripped = T.strip firstLine
       in stripped == "ACTION: PATCH" || "ACTION: PATCH " `T.isPrefixOf` stripped

extractDiffBlock :: Text -> Maybe Text
extractDiffBlock raw =
  case dropWhile (not . isDiffFence) (T.lines raw) of
    [] -> Nothing
    _fence : rest ->
      let body = takeWhile (not . isFenceClose) rest
       in if null body then Nothing else Just (T.unlines body)

isDiffFence :: Text -> Bool
isDiffFence line = line == "```diff" || line == "```patch" || line == "```"

isFenceClose :: Text -> Bool
isFenceClose = (== "```")