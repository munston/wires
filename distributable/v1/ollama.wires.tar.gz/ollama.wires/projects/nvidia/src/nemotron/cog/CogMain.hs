-- generated-by: gofur codegen 0.1
module Main where

import Data.List
import System.Exit
import qualified Nemotron

main :: IO ()
main = do
  runCase "--list" [] (\s -> "--self-test" `isInfixOf` s)
  runCase "--self-test" [] (\s -> "nemotron self-test pass" `isInfixOf` s)
  runCase "--chat" ["avocado"] (\s -> "avocado" `isInfixOf` s)
  return ()

runCase :: String -> [String] -> (String -> Bool) -> IO ()
runCase option args predicate = do
  value <- Nemotron.go option args
  if predicate value
    then return ()
    else do
      putStrLn ("cog failed for " ++ option ++ ": " ++ value)
      exitFailure
