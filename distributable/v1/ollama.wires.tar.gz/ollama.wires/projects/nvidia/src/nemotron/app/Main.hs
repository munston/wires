{-# LANGUAGE OverloadedStrings #-}

module Main where

import Nvidia.Codegen.Header (systemPrompt)
import Nvidia.Codegen.Output (CodegenOutput(..), parseCodegenOutput)
import qualified Data.Text as T
import qualified Data.Text.IO as TIO
import Nvidia.Config
import Nvidia.NIM
import Data.Maybe (mapMaybe)
import System.Exit (ExitCode(..), exitFailure)
import System.Environment
import System.Process (readCreateProcessWithExitCode, shell)

main :: IO ()
main = do
	args <- getArgs
	prompt <- promptFromArgsOrStdin args
	key <- loadApiKey
	result <- chat key baseUrl model [Message System systemPrompt, Message User prompt]
	case result of
		Left err -> do
			putStrLn err
			exitFailure
		Right answer ->
			case parseCodegenOutput answer of
				ButtonAction buttonName -> runRequestedCommand buttonName
				PatchAction patchText -> TIO.putStrLn patchText
				RunAction commandText -> runRequestedCommand commandText
				FreeText freeText ->
					case inferSoftCommand freeText of
						Just commandText -> runRequestedCommand commandText
						Nothing -> TIO.putStrLn (sanitize freeText)

runRequestedCommand :: T.Text -> IO ()
runRequestedCommand requested =
	case normalizeSafeCommand requested of
		Nothing ->
			TIO.putStrLn
				( T.concat
					[ "HARNESS: rejected unsafe command request: "
					, sanitize requested
					]
				)
		Just cmd -> do
			TIO.putStrLn (T.concat ["HARNESS: running safe command: ", cmd])
			(exitCode, outText, errText) <- readCreateProcessWithExitCode (shell (T.unpack cmd)) ""
			if not (null outText)
				then TIO.putStrLn (sanitize (T.pack outText))
				else pure ()
			if not (null errText)
				then TIO.putStrLn (sanitize (T.pack errText))
				else pure ()
			case exitCode of
				ExitSuccess -> pure ()
				ExitFailure code ->
					TIO.putStrLn (T.pack ("HARNESS: command exited with code " ++ show code))

inferSoftCommand :: T.Text -> Maybe T.Text
inferSoftCommand raw =
	case mapMaybe normalizeSafeCommand candidates of
		firstMatch : _ -> Just firstMatch
		[] -> Nothing
	where
		candidates = raw : T.lines raw

normalizeSafeCommand :: T.Text -> Maybe T.Text
normalizeSafeCommand input =
	lookupSafe (stripNoise (T.toLower input))

stripNoise :: T.Text -> T.Text
stripNoise = dropTrailingPunctuation . stripWrappers . dropPrefixes . T.strip

dropPrefixes :: T.Text -> T.Text
dropPrefixes value =
	let prefixes =
			[ "please run "
			, "run "
			, "cmd:"
			, "cmd>"
			, "command:"
			, "action: run "
			, "action: button "
			]
	 in foldl dropOne value prefixes

dropOne :: T.Text -> T.Text -> T.Text
dropOne value prefix
	| prefix `T.isPrefixOf` T.stripStart value = T.strip (T.drop (T.length prefix) (T.stripStart value))
	| otherwise = value

stripWrappers :: T.Text -> T.Text
stripWrappers value =
	let trimmed = T.strip value
	 in if T.length trimmed >= 2
			&& ((T.head trimmed == '`' && T.last trimmed == '`') || (T.head trimmed == '"' && T.last trimmed == '"'))
			then T.strip (T.init (T.tail trimmed))
			else trimmed

dropTrailingPunctuation :: T.Text -> T.Text
dropTrailingPunctuation = T.dropWhileEnd (`elem` (".!,;:" :: String))

lookupSafe :: T.Text -> Maybe T.Text
lookupSafe candidate
	| candidate `elem` ["install.bat", ".\\install.bat", "call install.bat", "call .\\install.bat"] = Just ".\\install.bat"
	| otherwise = Nothing

sanitize :: T.Text -> T.Text
sanitize = T.filter (`elem` workingAlphabet)

workingAlphabet :: [Char]
workingAlphabet =
  ['A' .. 'Z']
    ++ ['a' .. 'z']
    ++ ['0' .. '9']
    ++ " \n\r\t"
    ++ ".,!?;:-_()[]{}<>/\\'\"@#$%^&*+=~`|"

promptFromArgsOrStdin :: [String] -> IO T.Text
promptFromArgsOrStdin args =
	case args of
		[] -> TIO.getContents
		_ -> pure (T.pack (unwords args))
