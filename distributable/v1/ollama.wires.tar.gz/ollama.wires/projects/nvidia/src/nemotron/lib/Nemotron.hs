module Nemotron where

import qualified Data.Text as T
import NemotronLib
import qualified Nvidia.NIM as NIM
import System.Environment (lookupEnv)

data VerifiedRoute =
  VerifiedRoute
    { routeOption :: String
    , routeArgs :: [String]
    , routePrecog :: String
    }
  deriving (Eq, Read, Show)

data RouteOptout =
  RouteOptout
    { routeOptoutOption :: String
    , routeOptoutReason :: String
    }
  deriving (Eq, Read, Show)

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--self-test\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--self-test", routeArgs = [], routePrecog = "\\s -> \"nemotron self-test pass\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--chat", routeArgs = ["avocado"], routePrecog = "\\s -> \"avocado\" `isInfixOf` s" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts = []

go :: String -> [String] -> IO String
go "--list" [] = pure (show (["--list", "--self-test", "--chat"] :: [String]))
go "--list" _ = pure "--list expects no arguments"
go "--self-test" [] = pure ("nemotron self-test pass: " ++ helloMessage)
go "--self-test" _ = pure "--self-test expects no arguments"
go "--chat" ["avocado"] = avocadoChat
go "--chat" _ = pure "nemotron live chat is available through the nemotron executable after NVIDIA_API_KEY is configured"
go option _ = pure ("unknown nemotron option: " ++ option)

avocadoChat :: IO String
avocadoChat = do
  enabled <- lookupEnv "NVIDIA_LIVE_COG"
  case enabled of
    Just "1" -> liveChat "avocado"
    _ -> pure "nemotron offline response: avocado"

liveChat :: String -> IO String
liveChat prompt = do
  key <- loadNvidiaApiKey
  result <-
    NIM.chat
      (T.pack key)
      NIM.defaultBaseUrl
      NIM.defaultModel
      [ NIM.Message NIM.System (T.pack "Reply briefly. Include the user's word in your response.")
      , NIM.Message NIM.User (T.pack prompt)
      ]
  case result of
    Left err -> pure ("nemotron live chat failed: " ++ err)
    Right response -> pure (T.unpack response)
