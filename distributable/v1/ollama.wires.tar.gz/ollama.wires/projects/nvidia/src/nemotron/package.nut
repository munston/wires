# Wires-facing safe dispatcher for the NVIDIA/Nemotron package.
name: nemotron
depends:
  aeson
  bytestring
  directory
  http-client
  http-client-tls
  http-types
  process
  text
exposes:
  Nemotron
go-is: Nemotron.go
