{-# LANGUAGE OverloadedStrings #-}

module Nvidia.Config
  ( loadApiKey
  , baseUrl
  , model
  ) where

import Data.Text (Text)
import qualified Data.Text as T
import NemotronLib (loadNvidiaApiKey)

loadApiKey :: IO Text
loadApiKey = T.pack <$> loadNvidiaApiKey

baseUrl :: Text
baseUrl = "https://integrate.api.nvidia.com/v1"

model :: Text
model = "nvidia/nemotron-3-super-120b-a12b"
