module NemotronLib (helloMessage, loadNvidiaApiKey) where

import Data.Char (isSpace)
import System.Directory (doesFileExist)
import System.Environment (lookupEnv)

helloMessage :: String
helloMessage = "Hello from NemotronLib"

loadNvidiaApiKey :: IO String
loadNvidiaApiKey = do
  maybeKey <- lookupEnv "NVIDIA_API_KEY"
  case validSecret maybeKey of
    Just key -> pure key
    Nothing -> do
      maybePath <- lookupEnv "NVIDIA_API_KEY_FILE"
      let candidates =
            maybe [] (:[]) maybePath
              ++ [ "nvidia-api-key.local.txt"
                 , "nvidia-api-key.txt"
                 ]
      loadFirstKeyFile candidates

loadFirstKeyFile :: [FilePath] -> IO String
loadFirstKeyFile [] =
  fail "Missing NVIDIA_API_KEY. Set NVIDIA_API_KEY or NVIDIA_API_KEY_FILE before running live NVIDIA/NIM commands."
loadFirstKeyFile (path:rest) = do
  exists <- doesFileExist path
  if exists
    then do
      contents <- readFile path
      case validSecret (Just contents) of
        Just key -> pure key
        Nothing -> fail ("Empty NVIDIA API key file: " ++ path)
    else loadFirstKeyFile rest

validSecret :: Maybe String -> Maybe String
validSecret Nothing = Nothing
validSecret (Just raw) =
  let value = trim raw
   in if null value then Nothing else Just value

trim :: String -> String
trim = dropWhileEnd isSpace . dropWhile isSpace

dropWhileEnd :: (a -> Bool) -> [a] -> [a]
dropWhileEnd predicate = reverse . dropWhile predicate . reverse
