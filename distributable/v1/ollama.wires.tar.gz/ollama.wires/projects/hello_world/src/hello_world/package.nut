name: hello_world
depends:
exposes:
  HelloWorld
go-is: HelloWorld.go
