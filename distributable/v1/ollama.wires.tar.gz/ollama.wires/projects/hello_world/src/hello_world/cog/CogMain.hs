-- generated-by: gofur codegen 0.1
module Main where

import Data.List
import System.Exit
import qualified HelloWorld

main :: IO ()
main = do
  runCase "--list" [] (\s -> "--hello" `isInfixOf` s)
  runCase "--hello" [] (\s -> s == "hello world")
  return ()

runCase :: String -> [String] -> (String -> Bool) -> IO ()
runCase option args predicate = do
  value <- HelloWorld.go option args
  if predicate value
    then return ()
    else do
      putStrLn ("cog failed for " ++ option ++ ": " ++ value)
      exitFailure
