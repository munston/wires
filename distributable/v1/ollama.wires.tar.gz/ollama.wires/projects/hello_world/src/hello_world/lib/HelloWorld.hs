module HelloWorld where

data VerifiedRoute =
  VerifiedRoute
    { routeOption :: String
    , routeArgs :: [String]
    , routePrecog :: String
    }
  deriving (Eq, Read, Show)

data RouteOptout =
  RouteOptout
    { routeOptoutOption :: String
    , routeOptoutReason :: String
    }
  deriving (Eq, Read, Show)

verifiedRoutes :: [VerifiedRoute]
verifiedRoutes =
  [ VerifiedRoute { routeOption = "--list", routeArgs = [], routePrecog = "\\s -> \"--hello\" `isInfixOf` s" }
  , VerifiedRoute { routeOption = "--hello", routeArgs = [], routePrecog = "\\s -> s == \"hello world\"" }
  ]

routeOptouts :: [RouteOptout]
routeOptouts = []

message :: String
message = "hello world"

go :: String -> [String] -> IO String
go "--list" [] = pure (show (["--list", "--hello"] :: [String]))
go "--list" _ = pure "--list expects no arguments"
go "--hello" [] = pure message
go "--hello" _ = pure "--hello expects no arguments"
go option _ = pure ("unknown hello_world option: " ++ option)
